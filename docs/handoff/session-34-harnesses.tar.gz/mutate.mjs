import fs from 'node:fs';
import { spawnSync } from 'node:child_process';
const SC = '/tmp/claude-0/-home-user-PACE-All-in-one-recruting-tool/2683caef-a9ba-5eed-bb57-5c335d09589a/scratchpad';
const real = fs.readFileSync('/home/user/PACE_All-in-one-recruting-tool/routes/apply.js', 'utf8');
const SEL = "if (failed) { noteFailure('job lookup', failed); return null; }";
const M = [
 ['M1  THE ORIGINAL BUG: select/read owner_id again', [["'bd_manager_id,created_by')", "'owner_id,created_by')"], ['job.bd_manager_id || job.created_by', 'job.owner_id || job.created_by']]],
 ['M2  a failed lookup is not recorded', [[SEL, "if (failed) { return null; }"]]],
 ['M3  the token is not scrubbed from the record', [[".replace(TOKEN_SHAPED, '[token]').replace(/\\s+/g, ' ')", ".replace(/\\s+/g, ' ')"]]],
 ['M4  a failure becomes distinguishable (throws)', [[SEL, "if (failed) { noteFailure('job lookup', failed); throw new Error('lookup failed'); }"]]],
 ['M5  the recorder is AWAITED by the request', [["      withTimeout(supabase.from('app_settings').upsert({", "      return withTimeout(supabase.from('app_settings').upsert({"], [SEL, "if (failed) { await noteFailure('job lookup', failed); return null; }"]]],
 ['M6  a rejected upload counts as success again', [['const upFailed = queryFailure(up, 8000);', "const upFailed = up === undefined ? { code: 'timeout', message: 'x' } : (up && up.error) || null;"]]],
 ['M7  apply_count not selected (badge writes 1)', [["apply_enabled,apply_token,apply_count,' +", "apply_enabled,apply_token,' +"]]],
 ['M8  owner precedence reversed', [['job.bd_manager_id || job.created_by', 'job.created_by || job.bd_manager_id']]],
 ['M9  no in-flight guard (write per failing request)', [['if (recording) return;', '/* no guard */']]],
 ['M10 a CLEAN MISS is recorded (false alarm)', [["    const job = r.data;\n    if (!job) return null;", "    const job = r.data;\n    if (!job) { noteFailure('job lookup', { code: 'miss' }); return null; }"]]],
 ['M11 insert failure not recorded', [["        noteFailure('application insert', insFailed);\n", ""]]],
 ['M12 counter failure not recorded', [["if (bumpFailed) noteFailure('apply_count update', bumpFailed);", "/* not recorded */"]]],
 ['M13 upload failure not recorded', [["        noteFailure('resume upload', upFailed);\n", ""]]],
 ['M14 POST unexpected exception not recorded', [["noteFailure('POST /apply/:token', err);", ""]]],
 ['M15 GET render exception not recorded', [["noteFailure('GET /apply/:token', err);", ""]]],
 ['M16 details (row echo) stored in message', [["message: clean(e.message, 300),", "message: clean(e.message + ' ' + (e.details || ''), 300),"]]],
 ['M17 clip BEFORE scrub (token half survives)', [[".replace(TOKEN_SHAPED, '[token]').replace(/\\s+/g, ' ').trim().slice(0, n);", ".slice(0, n).replace(TOKEN_SHAPED, '[token]').replace(/\\s+/g, ' ').trim();"]]],
 ['M18 queryFailure ignores a rejected (null) result', [["if (r === null) return { code: 'rejected', message: 'the query threw instead of answering' };", "if (r === null) return null;"]]],
];
let survived = 0;
for (const [name, edits] of M) {
  let src = real, applied = true;
  for (const [from, to] of edits) { if (!src.includes(from)) { applied = false; break; } src = src.replace(from, () => to); }
  if (!applied) { console.log(`${name}\n     !!! MUTATION DID NOT APPLY (would be vacuous) — fix the runner`); survived++; continue; }
  fs.writeFileSync(SC + '/mut/routes/apply.js', src);
  const r = spawnSync('node', [SC + '/repro-r076.mjs'], { env: { ...process.env, ROUTE_FILE: SC + '/mut/routes/apply.js', QUICK: '1' }, encoding: 'utf8', timeout: 90000 });
  const out = (r.stdout || '') + (r.stderr || '');
  const bad = out.split('\n').filter(l => l.startsWith('✗')).map(l => l.slice(2).split('  — ')[0].slice(0, 78));
  const tot = (out.match(/(\d+)\/(\d+) passed/) || [])[0] || ('CRASH: ' + out.split('\n').slice(0, 2).join(' ').slice(0, 120));
  const verdict = bad.length || /CRASH/.test(tot) ? 'CAUGHT' : '*** SURVIVED ***';
  if (verdict !== 'CAUGHT') survived++;
  console.log(`${name}\n     ${verdict} (${tot})${bad.length ? '\n       - ' + bad.slice(0, 4).join('\n       - ') + (bad.length > 4 ? `\n       - … +${bad.length - 4} more` : '') : ''}`);
}
console.log(`\nSURVIVORS / NOT-APPLIED: ${survived} of ${M.length}`);
