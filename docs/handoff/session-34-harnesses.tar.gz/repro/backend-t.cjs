// A local PACE backend for reproduction: the REAL route handlers for reminders,
// next-actions, job-orders (incl. the apply-link publish/unpublish) and the public
// apply page, over the in-memory fake db. Only index.js's /emails/reminder-send is
// re-stated (index.js cannot be mounted alone); it copies lines 944-952 exactly:
// queue an email row, then update the reminder to status 'sent' (no updated_at).
const path = require('path');
const express = require('express');
const REPO = process.env.PACE_REPO || '/home/user/PACE_All-in-one-recruting-tool';
const { makeFakeSupabase } = require('./fake-supabase.cjs');
const { createDb } = require(REPO + '/models/index.js');

function startBackend({ user, tables, strictColumns, applyModule }) {
  const fake = makeFakeSupabase(tables, strictColumns);
  const db = createDb(fake);
  const calls = [];
  const app = express();
  app.use(express.json({ limit: '5mb' }));
  app.use((req, res, next) => {
    res.set('Access-Control-Allow-Origin', '*');
    res.set('Access-Control-Allow-Headers', 'Authorization, Content-Type');
    res.set('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
    if (req.method === 'OPTIONS') return res.status(204).end();
    if (!/\.(js|css|html)$/.test(req.path) && req.path !== '/') calls.push(req.method + ' ' + req.originalUrl);
    next();
  });
  app.use(express.static(path.join(REPO, 'public')));
  const auth = (req, res, next) => { req.user = Object.assign({}, user); req.orgId = user.org_id; next(); };
  const orgIdFor = (req) => (req && req.user && req.user.org_id) || null;
  const withOrg = (q, req) => { const o = orgIdFor(req); return o ? q.eq('org_id', o) : q; };
  const orgStamp = (req) => { const o = orgIdFor(req); return o ? { org_id: o } : {}; };
  const today = () => new Date().toISOString().split('T')[0];
  const hasRole = (req, ...roles) => roles.includes(req.user.role) || (req.user.roles || []).some(r => roles.includes(r));

  // ── REAL: routes/reminders.js
  app.use(require(REPO + '/routes/reminders.js')({ db, auth, today, canTouchJob: async () => true, reportingChainIds: async (id) => [id] }));
  // ── REAL: routes/next-actions.js
  app.use(require(REPO + '/routes/next-actions.js')({ supabase: fake, auth, orgIdFor, withOrg, today }));
  // ── REAL: routes/recruiting/job-orders.js (registers on app directly)
  require(REPO + '/routes/recruiting/job-orders.js')(app, {
    supabase: fake, db, auth, hasRole, today, orgIdFor, orgStamp, withOrg,
    hasRequirementColumns: async () => false, applyDerivedJobFields: async () => ({}),
    persistScores: async () => {}, invalidateJobScores: async () => {},
    STAGES: [], STAGE_ALIASES: {}, normalizeStage: s => s, BDM_GATED_STAGE: 'Submitted to Client',
    isBDM: (req) => hasRole(req, 'admin', 'bd', 'bd_lead'), isRecruiter: (req) => hasRole(req, 'recruiter'),
    assignedJobOrderIds: async () => [], recruiterCanTouchJob: async () => true,
    reportingChainIds: async (id) => [id], nextId: async () => 'JO-X', logSubmissionActivity: async () => {},
    JOB_ORDER_SELECT: '*', JOB_FIELDS: ['status'], JOB_DATE_FIELDS: [], pickJobFields: (b) => (b.status ? { status: b.status } : {}),
  });
  // ── REAL: routes/apply.js (public page)
  app.use((applyModule || require(REPO + '/routes/apply.js'))({ supabase: fake, applyLimiter: null }));

  // ── RE-STATED from index.js:944-952 (POST /emails/reminder-send, success path only)
  app.post('/emails/reminder-send', auth, async (req, res) => {
    const { reminder_id, contact_id, job_id, to_email, subject, body } = req.body;
    const { data: row } = await db.forRequest(req).from('emails').insert({ contact_id: contact_id || null, job_id, to_email, subject, body, sent_by: req.user.id, status: 'pending', followup_type: 'reminder' }).select().single();
    if (reminder_id) await db.forRequest(req).from('reminders').update({ status: 'sent' }).eq('id', reminder_id).eq('user_id', req.user.id);
    res.status(201).json({ success: true, email_id: row && row.id });
  });

  // ── everything else the shell asks for: empty but well-formed
  const OBJ = new Set(['/app-settings', '/outreach-plan', '/distribute/pool-stats', '/distribute/today-summary', '/me/preferences', '/recruiting-dashboard', '/reports/recruiting', '/progress', '/email-progress', '/client-digest', '/mailboxes/alerts']);
  app.get('/users', auth, (req, res) => res.json([Object.assign({ is_active: true }, user)]));
  app.get('/ai/morning-briefing', auth, (req, res) => res.json({ summary: 'Morning.', engine: 'rules' }));
  app.use((req, res) => {
    if (req.method !== 'GET') return res.json({ success: true });
    if (OBJ.has(req.path)) return res.json({});
    res.json([]);
  });
  return new Promise(r => { const srv = app.listen(0, '127.0.0.1', () => r({ port: srv.address().port, srv, fake, calls })); });
}
module.exports = { startBackend };
