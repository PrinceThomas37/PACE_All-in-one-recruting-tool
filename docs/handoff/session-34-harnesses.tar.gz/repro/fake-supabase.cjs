// Minimal in-memory stand-in for the supabase-js query builder, enough for the
// real route handlers under test. Rows are returned WHOLE (no projection) and
// embedded objects (job:jobs(...), contact:contacts(...)) are stored on the row
// the way PostgREST would return them. Every write is logged.
const crypto = require('crypto');
function clone(x) { return x == null ? x : JSON.parse(JSON.stringify(x)); }
function norm(v) { return v instanceof Date ? v.toISOString() : v; }
function makeFakeSupabase(tables, strictColumns) {
  const writes = [];
  function from(table) {
    if (!tables[table]) tables[table] = [];
    const st = { op: 'select', filters: [], patch: null, rows: null, limit: null, selectAfter: false, upsert: null };
    const ok = (r) => st.filters.every(f => f(r));
    const b = {
      select(cols) {
        if (st.op !== 'select') st.selectAfter = true;
        // Behave like PostgREST when a schema is supplied: a plain column that the
        // table does not have fails the whole request with 42703.
        const known = strictColumns && strictColumns[table];
        if (known && typeof cols === 'string' && cols.trim() !== '*') {
          const top = []; let depth = 0, cur = '';
          for (const ch of cols) { if (ch === '(') depth++; if (ch === ')') depth--; if (ch === ',' && depth === 0) { top.push(cur); cur = ''; } else cur += ch; }
          top.push(cur);
          const bad = top.map(x => x.trim()).filter(x => x && x !== '*' && !x.includes('(') && !x.includes(':') && !known.has(x));
          if (bad.length) st.fail = { code: '42703', message: 'column ' + table + '.' + bad[0] + ' does not exist' };
        }
        return b;
      },
      eq(k, v) { st.filters.push(r => String(r[k]) === String(v)); return b; },
      neq(k, v) { st.filters.push(r => String(r[k]) !== String(v)); return b; },
      in(k, arr) { const s = new Set((arr || []).map(String)); st.filters.push(r => s.has(String(r[k]))); return b; },
      is(k, v) { st.filters.push(r => (v === null ? r[k] == null : r[k] === v)); return b; },
      gte(k, v) { st.filters.push(r => r[k] >= v); return b; },
      lte(k, v) { st.filters.push(r => r[k] <= v); return b; },
      gt(k, v) { st.filters.push(r => r[k] > v); return b; },
      lt(k, v) { st.filters.push(r => r[k] < v); return b; },
      not() { return b; }, or() { return b; }, ilike() { return b; }, filter() { return b; },
      order() { return b; }, range() { return b; },
      limit(n) { st.limit = n; return b; },
      update(patch) { st.op = 'update'; st.patch = patch; return b; },
      insert(rows) { st.op = 'insert'; st.rows = [].concat(rows); return b; },
      upsert(rows, opts) { st.op = 'upsert'; st.rows = [].concat(rows); st.upsert = opts || {}; return b; },
      delete() { st.op = 'delete'; return b; },
      maybeSingle() { st.one = 'maybe'; return run(); },
      single() { st.one = 'single'; return run(); },
      then(res, rej) { return run().then(res, rej); },
    };
    async function run() {
      if (st.fail) return { data: null, error: st.fail };
      const T = tables[table];
      let out = null;
      if (st.op === 'select') {
        out = T.filter(ok).map(clone);
        if (st.limit != null) out = out.slice(0, st.limit);
      } else if (st.op === 'update') {
        const hit = T.filter(ok);
        const patch = {}; Object.keys(st.patch).forEach(k => { patch[k] = norm(st.patch[k]); });
        hit.forEach(r => Object.assign(r, patch));
        writes.push({ table, op: 'update', patch, ids: hit.map(r => r.id) });
        out = st.selectAfter ? hit.map(clone) : null;
      } else if (st.op === 'insert') {
        const added = st.rows.map(r => Object.assign({ id: crypto.randomUUID(), created_at: new Date().toISOString() }, r));
        added.forEach(r => T.push(r));
        writes.push({ table, op: 'insert', rows: clone(added) });
        out = st.selectAfter ? added.map(clone) : null;
      } else if (st.op === 'upsert') {
        const key = (st.upsert.onConflict || 'id');
        st.rows.forEach(r => {
          const ex = T.find(x => String(x[key]) === String(r[key]));
          if (ex) Object.assign(ex, r); else T.push(Object.assign({ id: crypto.randomUUID() }, r));
        });
        writes.push({ table, op: 'upsert', rows: clone(st.rows) });
        out = st.selectAfter ? st.rows.map(clone) : null;
      } else if (st.op === 'delete') {
        const keep = T.filter(r => !ok(r)); const gone = T.length - keep.length;
        tables[table] = keep; writes.push({ table, op: 'delete', count: gone });
        out = null;
      }
      if (st.one) {
        const arr = Array.isArray(out) ? out : (out ? [out] : []);
        if (st.one === 'single' && arr.length !== 1) return { data: null, error: { message: 'JSON object requested, multiple (or no) rows returned' } };
        return { data: arr[0] || null, error: null };
      }
      return { data: out, error: null };
    }
    return b;
  }
  return { from, writes, tables, rpc: async () => ({ data: null, error: { message: 'no rpc' } }), storage: { from: () => ({}) } };
}
module.exports = { makeFakeSupabase };
