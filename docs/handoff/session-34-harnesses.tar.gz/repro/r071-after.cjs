// R-071 AFTER the fix — dispatch's harness (real frontend, real /reminders + /next-actions
// handlers, fake db), one scenario per way of closing a reminder. For each: what request
// the action sent, the server row, BOTH Dashboard cards right after, again after the
// 3-minute background re-read (clock fast-forwarded), and after reopening the app.
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const { startBackend } = require(process.env.BACKEND || './backend.cjs');
const fx = require('./r071-fixture.cjs');
const API = 'https://fute-lms-backend.onrender.com';
const OWNER = { id: 'u-owner', name: 'Prince Thomas', email: 'prince@fute.test', role: 'admin', roles: ['admin'], org_id: 'org-1' };
const OUT = process.env.SHOTS || '';
let failures = 0;
const check = (ok, msg) => { if (!ok) failures++; console.log('   ' + (ok ? 'PASS' : 'FAIL') + '  ' + msg); };

async function open(browser, be, useClock) {
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  await ctx.addInitScript((u) => { sessionStorage.setItem('fg_token', 'harness'); sessionStorage.setItem('fg_user', JSON.stringify(u)); window.__opened = []; window.open = function (x) { window.__opened.push(String(x)); return null; }; }, OWNER);
  const local = 'http://127.0.0.1:' + be.port;
  await ctx.route('**', async (r) => { try { const u = r.request().url(); if (u.startsWith(local)) return await r.continue(); if (u.startsWith(API)) { const resp = await r.fetch({ url: local + u.slice(API.length) }); return await r.fulfill({ response: resp }); } return await r.abort(); } catch (e) { /* context closed mid-flight */ } });
  const page = await ctx.newPage();
  page.on('pageerror', e => { failures++; console.log('   [pageerror]', String(e).slice(0, 200)); });
  if (useClock) await page.clock.install();
  await page.goto(local + '/', { waitUntil: 'domcontentloaded' });
  if (useClock) await page.clock.runFor(2000);
  await page.waitForFunction(() => window.STATE && STATE.page === 'dashboard' && !STATE.loading && STATE.nextActions && STATE.nextActions.items, null, { timeout: 15000 });
  if (useClock) await page.clock.runFor(600); else await page.waitForTimeout(500);
  return { ctx, page };
}
const cards = (page) => page.evaluate(() => {
  const all = Array.from(document.querySelectorAll('#content .card'));
  const na = all.find(c => /Needs you today|Nothing waiting on you/.test(c.innerText));
  const rw = all.find(c => /^\s*Reminders/.test(c.innerText) && /View all|No reminders set/.test(c.innerText));
  const t = (c) => c ? c.innerText.replace(/\s+/g, ' ').trim() : '(card not found)';
  return { na: t(na), rem: t(rw) };
});
const flush = async (page, ms) => { await page.clock.runFor(ms || 800); await page.waitForTimeout(250); await page.clock.runFor(400); };

async function scenario(browser, name, opts) {
  const be = await startBackend({ user: OWNER, tables: fx() });
  console.log('\n=== ' + name + ' ===');
  let { ctx, page } = await open(browser, be, true);
  const target = opts.target || 'r1', person = opts.person || 'Dana Reyes';
  const before = await cards(page);
  check(before.na.includes(person) || before.rem.includes(person), 'precondition: ' + person + ' is on a Dashboard card before the action');
  be.calls.length = 0;
  await opts.act(page, flush);
  await flush(page, 1000);
  const writes = be.calls.filter(c => !/^GET /.test(c));
  console.log('   requests sent: ' + (writes.join(' | ') || 'NONE'));
  check(opts.expect.every(rx => writes.some(w => rx.test(w))), 'the action made the server request ' + opts.expect.map(String).join(' + '));
  const row = be.fake.tables.reminders.find(x => x.id === target);
  check(row.status === 'sent', 'server row ' + target + ' is now "' + row.status + '"');
  await page.evaluate(() => goPage('dashboard')); await flush(page, 900);
  const now = await cards(page);
  if (OUT) await page.screenshot({ path: OUT + '/' + name.replace(/\W+/g, '_') + '_after.png' });
  check(!now.na.includes(person), 'Needs you today: ' + person + ' gone right after  →  ' + now.na.slice(0, 90));
  check(!now.rem.includes(person) && !(target === 'r2' && now.rem.includes('Omar Hale')), 'Reminders card: gone right after  →  ' + now.rem.slice(0, 110));
  await flush(page, 181000);
  const t3 = await cards(page);
  check(!t3.na.includes(person) && !t3.rem.includes(person) && !(target === 'r2' && t3.rem.includes('Omar Hale')), 'both cards still clear after the 3-minute re-read');
  await ctx.unrouteAll({ behavior: 'ignoreErrors' }); await ctx.close();
  ({ ctx, page } = await open(browser, be, false));
  const re = await cards(page);
  check(!re.na.includes(person) && !re.rem.includes(person) && !(target === 'r2' && re.rem.includes('Omar Hale')), 'both cards still clear after reopening the app');
  check(!(await page.evaluate(() => window.__opened.length)), 'no web Gmail/Outlook tab was opened');
  await ctx.unrouteAll({ behavior: 'ignoreErrors' }); await ctx.close(); be.srv.close();
}

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  try {
    await scenario(browser, 'A Needs-you-today Done', { expect: [/POST \/next-actions\/r1\/done/],
      act: async (page, flush) => { await page.locator('#content button.na-act', { hasText: 'Done' }).first().click(); } });
    await scenario(browser, 'B Dashboard card Compose email then Send', { expect: [/POST \/emails\/reminder-send/],
      act: async (page, flush) => {
        const btn = page.locator('#content .dash-rem button', { hasText: 'Compose email' }).first();
        check(await btn.count() === 1, 'the Dashboard card offers "Compose email" (and no "Send all due")');
        check(await page.locator('#content button', { hasText: /Send all due/ }).count() === 0, 'no "Send all due" button anywhere');
        await btn.click(); await flush(page, 700);
        check(await page.evaluate(() => STATE.page === 'email' && STATE.composeContext === 'reminder'), 'the composer opened with the reminder as its context');
        await page.evaluate(() => applyReminderTemplate(0)); await flush(page, 300);
        await page.evaluate(() => sendReminderViaEngine());
      } });
    await scenario(browser, 'C Reminders page Dismiss', { expect: [/PATCH \/reminders\/r1/],
      act: async (page, flush) => { await page.evaluate(() => goPage('reminders')); await flush(page, 600); await page.locator('#content .rem-card button', { hasText: 'Dismiss' }).first().click(); } });
    await scenario(browser, 'D Reminders page Compose email then Send', { expect: [/POST \/emails\/reminder-send/],
      act: async (page, flush) => {
        await page.evaluate(() => goPage('reminders')); await flush(page, 600);
        await page.locator('#content .rem-card button', { hasText: 'Compose email' }).first().click(); await flush(page, 600);
        await page.evaluate(() => applyReminderTemplate(0)); await flush(page, 300);
        await page.evaluate(() => sendReminderViaEngine());
      } });
    await scenario(browser, 'E Reminders page Remove upcoming', { target: 'r2', person: 'Omar Hale', expect: [/PATCH \/reminders\/r2/],
      act: async (page, flush) => { await page.evaluate(() => goPage('reminders')); await flush(page, 600); await page.locator('#content tr button', { hasText: 'Remove' }).first().click(); } });
    await scenario(browser, 'F Email page out-of-office card Dismiss', { expect: [/PATCH \/reminders\/r1/],
      act: async (page, flush) => { await page.evaluate(() => goPage('email')); await flush(page, 800); const n = await page.locator('#content button', { hasText: 'Dismiss' }).count(); check(n >= 1, 'the Email page shows the "has returned from OOO" card with Dismiss'); await page.locator('#content button', { hasText: 'Dismiss' }).first().click(); } });

    // G — a read of "Needs you today" is already in flight when a reminder is closed: its (stale) answer
    // must not put the closed row back. The first /next-actions answer is held for 1.2s in the browser.
    {
      const be = await startBackend({ user: OWNER, tables: fx() });
      console.log('\n=== G a close lands while a read of "Needs you today" is in flight ===');
      const { ctx, page } = await open(browser, be, false);
      let held = false;
      await ctx.route('**/next-actions', async (r) => { try { if (!held && r.request().method() === 'GET') { held = true; const u = r.request().url(); const resp = await r.fetch({ url: 'http://127.0.0.1:' + be.port + u.slice(API.length) }); await new Promise(z => setTimeout(z, 1200)); return await r.fulfill({ response: resp }); } return await r.fallback(); } catch (e) {} });
      await page.locator('#content button', { hasText: 'Refresh' }).first().click();      // starts the (held) read
      await page.waitForTimeout(150);
      await page.evaluate(() => dismissReminder('r1'));                                   // the close arrives meanwhile
      await page.waitForTimeout(2600);
      const c = await cards(page);
      check(held, 'precondition: a read of Needs you today really was held in flight');
      check(!c.na.includes('Dana Reyes'), 'the stale in-flight answer did not bring Dana Reyes back  →  ' + c.na.slice(0, 80));
      await ctx.unrouteAll({ behavior: 'ignoreErrors' }); await ctx.close(); be.srv.close();
    }
    // H — the server says a send would be refused (a follow-up already went today): the Dashboard card must SAY so
    // and must not offer a button that ends in a refusal.
    {
      const t = fx(); const today = new Date().toISOString().slice(0, 10);
      t.emails.push({ id: 'e1', org_id: 'org-1', contact_id: 'k1', job_id: 'j1', status: 'sent', sent_at: today, followup_type: 'fu2' });
      const be = await startBackend({ user: OWNER, tables: t });
      console.log('\n=== H a send the server would refuse is not offered ===');
      const { ctx, page } = await open(browser, be, false);
      const row = await page.evaluate(() => { const r = Array.from(document.querySelectorAll('#content .dash-rem')).find(x => /Dana Reyes/.test(x.innerText)); return r ? { text: r.innerText.replace(/\s+/g, ' '), btn: !!r.querySelector('button') } : null; });
      check(!!row && !row.btn, 'Dana Reyes has NO Compose button when compose.can_send is false');
      check(!!row && /already went to this contact today|already queued|waiting in the send queue/.test(row.text), 'and the row states the server\'s reason  →  ' + (row ? row.text.slice(0, 150) : 'row missing'));
      await ctx.unrouteAll({ behavior: 'ignoreErrors' }); await ctx.close(); be.srv.close();
    }
  } finally { await browser.close(); }
  console.log('\nRESULT: ' + (failures ? failures + ' FAILED' : 'ALL PASS'));
  process.exit(failures ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
