// R-076, "next time": turn the link off in one session, reopen PACE, turn it on.
// Plus the status variant (job put On Hold, then back to Active), and a phone width.
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const { startBackend } = require('./backend.cjs');
const API = 'https://fute-lms-backend.onrender.com';
const OWNER = { id: 'u-owner', name: 'Prince Thomas', email: 'prince@fute.test', role: 'admin', roles: ['admin'], org_id: 'org-1' };
const TOKEN = 'a1b2c3d4e5f60718293a4b5c6d7e8f90';
const fixture = () => ({
  users: [{ ...OWNER, deleted_at: null }], organizations: [{ id: 'org-1', name: 'Fute Global' }],
  job_orders: [{ id: 'jo-1', org_id: 'org-1', job_code: 'JO-1001', job_title: 'HVAC Technician', client: 'Northwind', status: 'Active',
    city: 'Hartford', state: 'CT', job_type: 'Full-time', job_description: 'Service and repair commercial HVAC systems.',
    bd_manager_id: 'u-owner', created_by: 'u-owner', owner_id: 'u-owner', created_at: '2026-09-20T10:00:00Z', deleted_at: null,
    apply_token: TOKEN, apply_enabled: true, apply_published_at: '2026-09-28T17:27:38Z', apply_count: 0,
    bd_manager: { id: 'u-owner', name: 'Prince Thomas' }, recruiters: [] }],
});
async function session(browser, be, width) {
  const local = 'http://127.0.0.1:' + be.port;
  const ctx = await browser.newContext({ viewport: { width, height: 900 } });
  await ctx.addInitScript((u) => { sessionStorage.setItem('fg_token', 'harness'); sessionStorage.setItem('fg_user', JSON.stringify(u)); window.__copied = []; try { Object.defineProperty(navigator, 'clipboard', { value: { writeText: (t) => { window.__copied.push(t); return Promise.resolve(); } } }); } catch (e) {} }, OWNER);
  await ctx.route('**', async (r) => { const u = r.request().url(); if (u.startsWith(local)) return r.continue(); if (u.startsWith(API)) { const resp = await r.fetch({ url: local + u.slice(API.length) }); return r.fulfill({ response: resp }); } return r.abort(); });
  const page = await ctx.newPage(); page.on('pageerror', e => console.log('   [pageerror]', String(e).slice(0, 200)));
  await page.goto(local + '/', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => STATE.page === 'dashboard' && !STATE.loading, null, { timeout: 15000 });
  return { ctx, page, local };
}
const pub = async (ctx, local) => { const p = await ctx.newPage(); const r = await p.goto(local + '/apply/' + TOKEN); const h = await p.evaluate(() => (document.querySelector('h1') || {}).innerText); await p.close(); return 'HTTP ' + r.status() + ' "' + h + '"'; };
const jobBlock = (page) => page.evaluate(() => { const el = Array.from(document.querySelectorAll('#content div')).find(d => /^Apply link/.test((d.innerText || '').trim()) && d.querySelector('button,input,div')); return el ? el.innerText.replace(/\s+/g, ' ').slice(0, 60) : '(no apply block)'; });
const panel = (page) => page.evaluate(() => { const p = document.querySelector('#content tr.row-exp'); if (!p) return '(no panel)'; const m = p.innerText.match(/apply page\s*([^\n]*)/i); return m ? m[1].trim() : '?'; });
(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  for (const width of [1440, 390]) {
    for (const where of ['job page', 'row panel']) {
      const be = await startBackend({ user: OWNER, tables: fixture() });
      let s = await session(browser, be, width);
      await s.page.evaluate(() => goPage('bd_joborders')); await s.page.waitForTimeout(700);
      await s.page.evaluate(() => bdOpenJobOrder('jo-1')); await s.page.waitForTimeout(800);
      await s.page.locator('#content button', { hasText: 'Turn off' }).click(); await s.page.waitForTimeout(600);
      const off = await pub(s.ctx, s.local); await s.ctx.close();
      s = await session(browser, be, width);                      // "next time"
      await s.page.evaluate(() => goPage('bd_joborders')); await s.page.waitForTimeout(800);
      let shown;
      if (where === 'job page') {
        await s.page.evaluate(() => bdOpenJobOrder('jo-1')); await s.page.waitForTimeout(800);
        const before = await jobBlock(s.page);
        await s.page.locator('#content button', { hasText: 'Publish apply page' }).click(); await s.page.waitForTimeout(700);
        shown = before + '  ==>  ' + await jobBlock(s.page);
      } else {
        await s.page.locator('#content tr[data-row-id="jo-1"]').click(); await s.page.waitForTimeout(600);
        const before = await panel(s.page);
        await s.page.locator('#content tr.row-exp button', { hasText: 'Publish' }).click(); await s.page.waitForTimeout(700);
        shown = before + '  ==>  ' + await panel(s.page);
      }
      const j = be.fake.tables.job_orders[0];
      console.log(`${width}px ${where.padEnd(9)} | off: ${off} | next session, turn on: ${shown} | db enabled=${j.apply_enabled} same token=${j.apply_token === TOKEN} | public: ${await pub(s.ctx, s.local)}`);
      await s.ctx.close(); be.srv.close();
    }
  }
  // Status variant: the JOB put On Hold (link still "on"), then back to Active.
  const be = await startBackend({ user: OWNER, tables: fixture() });
  const s = await session(browser, be, 1440);
  await s.page.evaluate(() => goPage('bd_joborders')); await s.page.waitForTimeout(700);
  await s.page.locator('#content tr[data-row-id="jo-1"]').click(); await s.page.waitForTimeout(500);
  await s.page.selectOption('#content tr.row-exp select.lx-sel', 'On Hold'); await s.page.waitForTimeout(700);
  console.log(`status On Hold  | row panel apply line: ${await panel(s.page)} | public: ${await pub(s.ctx, s.local)}`);
  await s.page.evaluate(() => bdOpenJobOrder('jo-1')); await s.page.waitForTimeout(700);
  console.log(`status On Hold  | job page apply block: ${await jobBlock(s.page)}`);
  await s.page.evaluate(() => goPage('bd_joborders')); await s.page.waitForTimeout(700);
  await s.page.locator('#content tr[data-row-id="jo-1"]').click(); await s.page.waitForTimeout(500);
  await s.page.selectOption('#content tr.row-exp select.lx-sel', 'Active'); await s.page.waitForTimeout(700);
  console.log(`back to Active  | row panel apply line: ${await panel(s.page)} | public: ${await pub(s.ctx, s.local)}`);
  await s.ctx.close(); be.srv.close(); await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
