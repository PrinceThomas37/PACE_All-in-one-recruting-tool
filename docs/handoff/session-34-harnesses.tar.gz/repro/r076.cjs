// R-076 — "Once the job link is turned off, next time we turn it on the link do not get activated."
// Real frontend; real POST/DELETE /job-orders/:id/apply-link (routes/recruiting/job-orders.js);
// real public page GET /apply/:token (routes/apply.js); fake db shaped like the live row.
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const { startBackend } = require('./backend.cjs');
const OUT = __dirname + '/shots/'; require('fs').mkdirSync(OUT, { recursive: true });
const API = 'https://fute-lms-backend.onrender.com';
const OWNER = { id: 'u-owner', name: 'Prince Thomas', email: 'prince@fute.test', role: 'admin', roles: ['admin'], org_id: 'org-1' };
const TOKEN = 'a1b2c3d4e5f60718293a4b5c6d7e8f90';
const fixture = () => ({
  users: [{ ...OWNER, deleted_at: null }],
  organizations: [{ id: 'org-1', name: 'Fute Global' }],
  job_orders: [{ id: 'jo-1', org_id: 'org-1', job_code: 'JO-1001', job_title: 'HVAC Technician', client: 'Northwind', status: 'Active',
    city: 'Hartford', state: 'CT', job_type: 'Full-time', job_description: 'Service and repair commercial HVAC systems.',
    bd_manager_id: 'u-owner', created_by: 'u-owner', owner_id: 'u-owner', created_at: '2026-09-20T10:00:00Z', deleted_at: null,
    apply_token: TOKEN, apply_enabled: true, apply_published_at: '2026-09-28T17:27:38Z', apply_count: 0,
    bd_manager: { id: 'u-owner', name: 'Prince Thomas' }, recruiters: [] }],
});

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const be = await startBackend({ user: OWNER, tables: fixture() });
  const local = 'http://127.0.0.1:' + be.port;
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  await ctx.addInitScript((u) => {
    sessionStorage.setItem('fg_token', 'harness'); sessionStorage.setItem('fg_user', JSON.stringify(u));
    window.__copied = [];
    try { Object.defineProperty(navigator, 'clipboard', { value: { writeText: (t) => { window.__copied.push(t); return Promise.resolve(); } } }); } catch (e) {}
  }, OWNER);
  await ctx.route('**', async (r) => { const u = r.request().url(); if (u.startsWith(local)) return r.continue(); if (u.startsWith(API)) { const resp = await r.fetch({ url: local + u.slice(API.length) }); return r.fulfill({ response: resp }); } return r.abort(); });
  const page = await ctx.newPage();
  page.on('pageerror', e => console.log('   [pageerror]', String(e).slice(0, 200)));
  await page.goto(local + '/', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => STATE.page === 'dashboard' && !STATE.loading, null, { timeout: 15000 });

  const row = () => { const j = be.fake.tables.job_orders[0]; return `db: apply_enabled=${j.apply_enabled} token=${String(j.apply_token).slice(0, 8)}… status=${j.status}`; };
  const publicPage = async (url) => {
    const p2 = await ctx.newPage(); const resp = await p2.goto(url, { waitUntil: 'domcontentloaded' });
    const h1 = await p2.evaluate(() => (document.querySelector('h1') || {}).innerText || document.title);
    await p2.close(); return `public page ${url.replace(local, '')} -> HTTP ${resp.status()} "${h1}"`;
  };
  const jobBlock = () => page.evaluate(() => {
    const el = Array.from(document.querySelectorAll('#content div')).find(d => /^Apply link/.test((d.innerText || '').trim()) && d.querySelector('button,input,div'));
    const box = document.getElementById('bd-apply-url');
    return { text: el ? el.innerText.replace(/\s+/g, ' ').slice(0, 120) : '(no apply block)', url: box ? box.value : null };
  });
  const rowPanel = () => page.evaluate(() => { const p = document.querySelector('#content tr.row-exp'); if (!p) return '(no panel open)'; const m = p.innerText.match(/Apply page\s*([\s\S]{0,60})/); return m ? m[1].replace(/\s+/g, ' ').trim() : p.innerText.slice(0, 80); });
  const log = (s) => console.log(' ' + s);

  console.log('\n=== 1. JOB PAGE: live -> Turn off -> Publish apply page ===');
  await page.evaluate(() => goPage('bd_joborders')); await page.waitForTimeout(700);
  await page.evaluate(() => bdOpenJobOrder('jo-1')); await page.waitForTimeout(900);
  let b = await jobBlock(); log('screen: ' + JSON.stringify(b)); log(row()); log(await publicPage(b.url || local + '/apply/' + TOKEN));
  await page.locator('#content button', { hasText: 'Turn off' }).click(); await page.waitForTimeout(700);
  b = await jobBlock(); log('after Turn off  screen: ' + JSON.stringify(b)); log(row()); log(await publicPage(local + '/apply/' + TOKEN));
  await page.locator('#content button', { hasText: 'Publish apply page' }).click(); await page.waitForTimeout(700);
  b = await jobBlock(); log('after Publish   screen: ' + JSON.stringify(b)); log(row()); log(await publicPage(b.url || (local + '/apply/' + TOKEN)));
  await page.locator('#content button', { hasText: 'Copy link' }).click(); await page.waitForTimeout(300);
  log('Copy link put on the clipboard: ' + JSON.stringify(await page.evaluate(() => window.__copied)));
  await page.screenshot({ path: OUT + 'r076_jobpage_after_republish.png' });

  console.log('\n=== 2. JOBS LIST ROW PANEL: (off on the job page) -> row -> Publish ===');
  await page.locator('#content button', { hasText: 'Turn off' }).click(); await page.waitForTimeout(600); log('turned off on job page; ' + row());
  await page.evaluate(() => goPage('bd_joborders')); await page.waitForTimeout(900);
  await page.locator('#content tr[data-row-id="jo-1"]').click(); await page.waitForTimeout(600);
  log('row panel says: ' + await rowPanel());
  await page.locator('#content tr.row-exp button', { hasText: 'Publish' }).click(); await page.waitForTimeout(800);
  log('after Publish, row panel says: ' + await rowPanel()); log(row());
  await page.locator('#content tr.row-exp button', { hasText: 'Copy link' }).click().catch(() => log('(no Copy link button in panel)')); await page.waitForTimeout(300);
  const copied = await page.evaluate(() => window.__copied.slice(-1)[0]);
  log('row panel Copy link gave: ' + copied); if (copied) log(await publicPage(copied));
  await page.screenshot({ path: OUT + 'r076_rowpanel_after_publish.png' });

  console.log('\n=== 3. JOB PAGE again after the row-panel publish ===');
  await page.evaluate(() => bdOpenJobOrder('jo-1')); await page.waitForTimeout(900);
  b = await jobBlock(); log('screen: ' + JSON.stringify(b));
  console.log('\n all writes seen by the server:', JSON.stringify(be.fake.writes.map(w => w.table + ':' + w.op + ':' + JSON.stringify(w.patch || ''))));
  console.log(' requests:', be.calls.filter(c => /apply/.test(c)).join(' | '));
  await browser.close(); be.srv.close();
})().catch(e => { console.error(e); process.exit(1); });
