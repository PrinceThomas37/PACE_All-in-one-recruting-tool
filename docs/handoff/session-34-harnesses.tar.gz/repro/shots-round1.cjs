// Round-1 screenshots, light theme: (1) manager Dashboard without the "Your team" card, 1440 + 390;
// (2) the Reminders card + "Needs you today" right after completing a reminder, 1440 + 390;
// (3) the apply-link label for an On Hold job (job page + Jobs row panel), 1440.
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const { startBackend } = require('./backend.cjs');
const fx = require('./r071-fixture.cjs');
const OUT = '/tmp/claude-0/-home-user-PACE-All-in-one-recruting-tool/2683caef-a9ba-5eed-bb57-5c335d09589a/scratchpad/shots-round1/';
const API = 'https://fute-lms-backend.onrender.com';
const OWNER = { id: 'u-owner', name: 'Prince Thomas', email: 'prince@fute.test', role: 'admin', roles: ['admin'], org_id: 'org-1' };
const TOKEN = 'a1b2c3d4e5f60718293a4b5c6d7e8f90';

function tables() {
  const t = fx();
  // a second due reminder (today) so the card is not empty once the first is done
  const today = new Date(Date.now() + 5.5 * 3600e3).toISOString().slice(0, 10);
  t.jobs.push({ id: 'j4', org_id: 'org-1', position: 'Site Safety Lead', location: 'Austin, TX', industry: 'Construction', stage: 'Connected', company_id: 'c-j4', assigned_to_bd: 'u-owner', created_by: 'u-owner', assigned_to: null, company: { org_id: 'org-1', name: 'Delta Constructors', industry: 'Construction', location: 'Austin, TX' } });
  t.contacts.push({ id: 'k4', org_id: 'org-1', job_id: 'j4', first_name: 'Priya', last_name: 'Nair', email: 'priya@example.test', designation: 'HR Director', linkedin: null, phone: null, email_status: 'valid' });
  t.reminders.unshift({ id: 'r0', org_id: 'org-1', user_id: 'u-owner', job_id: 'j4', contact_id: 'k4', contact_name: 'Priya Nair', company_name: 'Delta Constructors', email: 'priya@example.test',
    return_date: today, reminder_time: '09:00', note: 'Check in on the safety-lead search.', status: 'pending', reminder_type: 'manual', created_at: '2026-09-25T10:00:00Z', updated_at: '2026-09-25T10:00:00Z',
    job: t.jobs[3], contact: t.contacts[3] });
  t.job_orders = [{ id: 'jo-1', org_id: 'org-1', job_code: 'JO-1001', job_title: 'HVAC Technician', client: 'Northwind', status: 'On Hold',
    city: 'Hartford', state: 'CT', job_type: 'Full-time', job_description: 'Service and repair commercial HVAC systems.', priority: 'Normal', positions: 1,
    bd_manager_id: 'u-owner', created_by: 'u-owner', created_at: '2026-09-20T10:00:00Z', deleted_at: null,
    apply_token: TOKEN, apply_enabled: true, apply_published_at: '2026-09-28T17:27:38Z', apply_count: 0,
    bd_manager: { id: 'u-owner', name: 'Prince Thomas' }, recruiters: [] }];
  return t;
}
const TEAM = [
  { id: 'u-r1', name: 'Riya Menon', email: 'riya@fute.test', role: 'bd', roles: ['bd'], av: 'RM', avc: 'av-bd', managerId: 'u-owner', managerName: 'Prince Thomas' },
  { id: 'u-r2', name: 'Sam Okafor', email: 'sam@fute.test', role: 'recruiter', roles: ['recruiter'], av: 'SO', avc: 'av-ra', managerId: 'u-owner', managerName: 'Prince Thomas' },
  { id: 'u-r3', name: 'Lena Fischer', email: 'lena@fute.test', role: 'bd_lead', roles: ['bd_lead'], av: 'LF', avc: 'av-bd', managerId: 'u-owner', managerName: 'Prince Thomas' },
];

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const be = await startBackend({ user: OWNER, tables: tables() });
  const local = 'http://127.0.0.1:' + be.port;
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 1100 }, colorScheme: 'light' });
  await ctx.addInitScript((u) => { sessionStorage.setItem('fg_token', 'harness'); sessionStorage.setItem('fg_user', JSON.stringify(u)); localStorage.setItem('pace-theme', 'light'); }, OWNER);
  await ctx.route('**', async (r) => { try { const u = r.request().url(); if (u.startsWith(local)) return await r.continue(); if (u.startsWith(API)) { const resp = await r.fetch({ url: local + u.slice(API.length) }); return await r.fulfill({ response: resp }); } return await r.abort(); } catch (e) {} });
  const page = await ctx.newPage();
  page.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 200)));
  await page.goto(local + '/', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => window.STATE && STATE.page === 'dashboard' && !STATE.loading && STATE.nextActions && STATE.nextActions.items, null, { timeout: 15000 });
  await page.evaluate((team) => {
    document.documentElement.setAttribute('data-theme', 'light');
    STATE.users = STATE.users.concat(team);
    STATE._recDash = { _at: Date.now(), scope: 'team', team_size: 3, submissions_week: 4, submissions_month: 11, awaiting_approval: 2, jobs: { total: 12 },
      by_stage: { 'Submitted to BDM': 3, 'Submitted to Client': 4, 'Interview Scheduled': 2, 'Offer': 1, 'Placement': 1 }, upcoming_interviews: [] };
    render();
  }, TEAM);
  await page.waitForTimeout(700);
  const txt = () => page.evaluate(() => document.getElementById('content').innerText);
  const t0 = await txt();
  console.log('manager dashboard: has a "Your team" card heading? ', /(^|\n)Your team\s*(\n|$)/.test(t0), '| "Open team view"?', /Open team view/.test(t0), '| "No one reports"?', /No one reports to you/.test(t0));
  console.log('team of 3 exists in STATE (so the card WOULD have drawn):', await page.evaluate(() => getTeam(STATE.user).length));
  await page.mouse.move(1000, 640); await page.waitForTimeout(150); await page.screenshot({ path: OUT + '1_manager-dashboard_no-your-team-card_1440.png' });
  await page.setViewportSize({ width: 390, height: 1900 }); await page.waitForTimeout(500);
  await page.mouse.move(1000, 640); await page.waitForTimeout(150); await page.screenshot({ path: OUT + '1_manager-dashboard_no-your-team-card_390.png' });
  await page.setViewportSize({ width: 1440, height: 1100 }); await page.waitForTimeout(400);

  // (2) complete a reminder from "Needs you today" and look at both cards straight away
  console.log('before Done  :', (await page.evaluate(() => Array.from(document.querySelectorAll('#content .card')).filter(c => /Needs you today|^\s*Reminders/.test(c.innerText)).map(c => c.innerText.replace(/\s+/g, ' ').slice(0, 170)))).join('  ||  '));
  await page.locator('#content button.na-act', { hasText: 'Done' }).first().click();
  await page.waitForTimeout(150);   // NOT waiting for the server re-read: "immediately"
  console.log('right after  :', (await page.evaluate(() => Array.from(document.querySelectorAll('#content .card')).filter(c => /Needs you today|^\s*Reminders/.test(c.innerText)).map(c => c.innerText.replace(/\s+/g, ' ').slice(0, 170)))).join('  ||  '));
  await page.waitForTimeout(700);
  const na = await page.evaluate(() => { const c = Array.from(document.querySelectorAll('#content .card')).find(c => /Needs you today/.test(c.innerText)); return c ? c.getBoundingClientRect().top + window.scrollY : 0; });
  await page.evaluate(() => { const c = Array.from(document.querySelectorAll('#content .card')).find(c => /Needs you today/.test(c.innerText)); if (c) c.scrollIntoView({ block: 'start' }); });
  await page.waitForTimeout(200);
  await page.mouse.move(1000, 640); await page.waitForTimeout(150); await page.screenshot({ path: OUT + '2_after-completing-a-reminder_1440.png' });
  await page.setViewportSize({ width: 390, height: 1500 }); await page.waitForTimeout(500);
  await page.evaluate(() => { const c = Array.from(document.querySelectorAll('#content .card')).find(c => /Needs you today|Nothing waiting/.test(c.innerText)); if (c) c.scrollIntoView({ block: 'start' }); });
  await page.waitForTimeout(200);
  await page.mouse.move(1000, 640); await page.waitForTimeout(150); await page.screenshot({ path: OUT + '2_after-completing-a-reminder_390.png' });
  await page.setViewportSize({ width: 1440, height: 1100 }); await page.waitForTimeout(300);

  // (3) On Hold job with the apply link switched on
  await page.evaluate(() => goPage('bd_joborders')); await page.waitForTimeout(900);
  await page.locator('#content tr[data-row-id="jo-1"]').click(); await page.waitForTimeout(700);
  console.log('row panel apply line:', await page.evaluate(() => { const p = document.querySelector('#content tr.row-exp'); const m = p && p.innerText.match(/apply page\s*([\s\S]{0,260})/i); return m ? m[1].replace(/\s+/g, ' ').trim() : '(none)'; }));
  await page.mouse.move(1000, 640); await page.waitForTimeout(150); await page.screenshot({ path: OUT + '3_apply-link-on-hold_jobs-row-panel_1440.png' });
  await page.evaluate(() => bdOpenJobOrder('jo-1')); await page.waitForTimeout(1000);
  console.log('job page apply block:', await page.evaluate(() => { const el = Array.from(document.querySelectorAll('#content div')).find(d => /^Apply link/.test((d.innerText || '').trim()) && d.querySelector('button,input,div')); return el ? el.innerText.replace(/\s+/g, ' ').slice(0, 330) : '(none)'; }));
  await page.evaluate(() => { const el = Array.from(document.querySelectorAll('#content div')).find(d => /^Apply link/.test((d.innerText || '').trim()) && d.querySelector('button,input,div')); if (el) el.scrollIntoView({ block: 'center' }); });
  await page.waitForTimeout(200);
  await page.mouse.move(1000, 640); await page.waitForTimeout(150); await page.screenshot({ path: OUT + '3_apply-link-on-hold_job-page_1440.png' });
  await ctx.unrouteAll({ behavior: 'ignoreErrors' }); await browser.close(); be.srv.close();
})().catch(e => { console.error(e); process.exit(1); });
