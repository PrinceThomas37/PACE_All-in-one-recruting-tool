// C-0031 (observatory -> surface) + Job D, end to end: the REAL /next-actions and /next-actions/team
// handlers (observatory's admin change) behind the REAL card. The owner's case: an admin who owns nothing,
// while a BD Lead holds the org's open reminders.
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const { startBackend } = require(process.env.BACKEND || './backend.cjs');
const fx = require('./r071-fixture.cjs');
const API = 'https://fute-lms-backend.onrender.com';
const OWNER = { id: 'u-owner', name: 'Prince Thomas', email: 'prince@fute.test', role: 'admin', roles: ['admin'], org_id: 'org-1' };
let failures = 0; const check = (ok, msg) => { if (!ok) failures++; console.log('  ' + (ok ? 'PASS' : 'FAIL') + '  ' + msg); };
(async () => {
  const t = fx(); t.reminders.forEach(r => { r.user_id = 'u-bd'; });
  t.users.push({ id: 'u-bd', name: 'Spencer Brown', role: 'bd_lead', org_id: 'org-1', deleted_at: null });
  const be = await startBackend({ user: OWNER, tables: t });
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  await ctx.addInitScript((u) => { sessionStorage.setItem('fg_token', 'harness'); sessionStorage.setItem('fg_user', JSON.stringify(u)); }, OWNER);
  const local = 'http://127.0.0.1:' + be.port;
  await ctx.route('**', async (r) => { try { const u = r.request().url(); if (u.startsWith(local)) return await r.continue(); if (u.startsWith(API)) { const resp = await r.fetch({ url: local + u.slice(API.length) }); return await r.fulfill({ response: resp }); } return await r.abort(); } catch (e) {} });
  const page = await ctx.newPage(); page.on('pageerror', e => { failures++; console.log('  [pageerror]', String(e).slice(0, 160)); });
  await page.goto(local + '/', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => window.STATE && STATE.page === 'dashboard' && !STATE.loading && STATE.nextActions && STATE.nextActions.items, null, { timeout: 15000 });
  await page.waitForTimeout(600);
  const card = () => page.evaluate(() => { const c = Array.from(document.querySelectorAll('#content .card')).find(c => /Needs you today|Nothing waiting on you/.test(c.innerText)); return c ? c.innerText.replace(/\s+/g, ' ').trim() : '(none)'; });
  let c = await card();
  console.log('  card:', c);
  check(/Nothing waiting on you/.test(c), 'an admin who owns nothing sees the empty sentence');
  check(/3 open across/.test(c) && /Review/.test(c), 'AND the team count with a Review button (C-0031) — not a dead end');
  await page.locator('#content button', { hasText: 'Review' }).first().click(); await page.waitForTimeout(700);
  const modal = await page.evaluate(() => { const m = document.querySelector('.na-team'); return m ? m.innerText.replace(/\s+/g, ' ').trim() : '(no review drawer)'; });
  console.log('  review:', modal.slice(0, 300));
  check(/Open across your team/.test(modal) && /Ask them/.test(modal) && /Dana Reyes/.test(modal), 'Review opens the list with an "Ask them" on each reminder');
  await page.evaluate(() => naCloseTeam());
  // hidden line on an empty list
  await page.evaluate(() => { STATE.nextActions = Object.assign({}, STATE.nextActions, { items: [], stale_nudges: 4, snoozed: 2, nudge_max_age_days: 45 }); render(); });
  await page.waitForTimeout(300);
  c = await card(); console.log('  card:', c);
  check(/4 gone quiet over 45 days/.test(c) && /2 hidden by you/.test(c), 'the "what is hidden" line is drawn on an empty list too');
  // Job D: stage_suggested + unknown kind
  await page.evaluate(() => { STATE.nextActions = { items: [
      { kind: 'stage_suggested', entity_type: 'candidate', entity_id: 'cd1', title: 'Ravi Kumar', subtitle: 'Iron Horse', reason: 'Interested — currently at "Screening". Worth moving them forward?', job_id: null },
      { kind: 'some_future_kind', entity_type: 'contact', entity_id: 'k1', title: 'Someone', reason: 'x', job_id: null },
      { kind: 'nudge', entity_type: 'contact', entity_id: 'k2', title: 'Quiet Person', reason: 'y', job_id: null } ],
    summary: { total: 3, by_kind: { reply_due: 0, commitment_due: 0, reminder_due: 1, nudge: 1, stage_suggested: 1 } } }; render(); });
  await page.waitForTimeout(300);
  c = await card(); console.log('  card:', c);
  check(/Replied — interested/.test(c), 'a stage_suggested row is labelled "Replied — interested"');
  check(!/Ravi Kumar[^]*No reply yet[^]*Someone/.test(c) && /Needs a look/.test(c), 'an unknown kind says "Needs a look", not "No reply yet"');
  check(/1 interested/.test(c) && /1 reminder\b/.test(c) && !/1 reminders/.test(c), 'the count chips include "1 interested" and say "1 reminder"');
  await ctx.unrouteAll({ behavior: 'ignoreErrors' }); await browser.close(); be.srv.close();
  console.log(failures ? failures + ' FAILED' : 'ALL PASS'); process.exit(failures ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
