const { startBackend } = require('./backend.cjs');
const fx = require('./r071-fixture.cjs');
(async () => {
  const OWNER = { id: 'u-owner', name: 'Prince Thomas', email: 'prince@fute.test', role: 'admin', roles: ['admin'], org_id: 'org-1' };
  const t = fx();
  const today = new Date(Date.now() + 5.5 * 3600e3).toISOString().slice(0, 10);
  console.log('today(IST)=', today, 'UTC=', new Date().toISOString());
  const be = await startBackend({ user: OWNER, tables: t });
  const r = await fetch('http://127.0.0.1:' + be.port + '/next-actions', { headers: { Authorization: 'Bearer x' } });
  const j = await r.json();
  console.log(r.status, JSON.stringify(j).slice(0, 400));
  be.srv.close();
})();
