// Same session, no reopening: does a locally-dismissed reminder come back by itself
// when the dashboard's 3-minute background refresh runs? Clock fast-forwarded.
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const { startBackend } = require('./backend.cjs');
const API = 'https://fute-lms-backend.onrender.com';
const OWNER = { id: 'u-owner', name: 'Prince Thomas', email: 'prince@fute.test', role: 'admin', roles: ['admin'], org_id: 'org-1' };
const fx = require('./r071-fixture.cjs');
(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  for (const how of ['Reminders page Dismiss', 'Email page OOO card Dismiss', 'Dashboard card Send']) {
    const be = await startBackend({ user: OWNER, tables: fx() });
    const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
    await ctx.addInitScript((u) => { sessionStorage.setItem('fg_token', 'harness'); sessionStorage.setItem('fg_user', JSON.stringify(u)); window.open = () => null; }, OWNER);
    const local = 'http://127.0.0.1:' + be.port;
    await ctx.route('**', async (r) => { const u = r.request().url(); if (u.startsWith(local)) return r.continue(); if (u.startsWith(API)) { const resp = await r.fetch({ url: local + u.slice(API.length) }); return r.fulfill({ response: resp }); } return r.abort(); });
    const page = await ctx.newPage();
    await page.clock.install();
    await page.goto(local + '/', { waitUntil: 'domcontentloaded' });
    await page.clock.runFor(2000);
    await page.waitForFunction(() => STATE.page === 'dashboard' && !STATE.loading && STATE.nextActions && STATE.nextActions.items, null, { timeout: 15000 });
    const card = () => page.evaluate(() => { const c = Array.from(document.querySelectorAll('#content .card')).find(c => /^\s*Reminders/.test(c.innerText)); return c ? c.innerText.replace(/\s+/g, ' ').slice(0, 70) : '(none)'; });
    if (how === 'Reminders page Dismiss') { await page.evaluate(() => goPage('reminders')); await page.clock.runFor(500); await page.locator('#content .rem-card button', { hasText: 'Dismiss' }).first().click(); }
    if (how === 'Email page OOO card Dismiss') { await page.evaluate(() => goPage('email')); await page.clock.runFor(800); const n = await page.locator('#content button', { hasText: 'Dismiss' }).count(); console.log('  (Email page shows', n, 'OOO Dismiss button(s))'); await page.locator('#content button', { hasText: 'Dismiss' }).first().click(); }
    if (how === 'Dashboard card Send') { await page.locator('#content button', { hasText: /^\s*Send\s*$/ }).first().click(); }
    await page.clock.runFor(500);
    await page.evaluate(() => goPage('dashboard')); await page.clock.runFor(800);
    const t0 = await card();
    await page.clock.runFor(181000); await page.waitForTimeout(400); await page.clock.runFor(500);
    const t3 = await card();
    console.log(how.padEnd(30), '| right after:', t0, '\n'.padEnd(32), '| 3 min later :', t3);
    await ctx.close(); be.srv.close();
  }
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
