// R-071 — "Once the reminders are complete it doesn't go off from the dashboard."
// Real frontend, real /reminders + /next-actions handlers, fake db shaped like
// production (3 out-of-office-return reminders). Each scenario completes the
// 28 Sep reminder one way, then reads BOTH dashboard cards: right away, and
// after the page is reopened (a returning user: session restored, data reloaded).
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const { startBackend } = require('./backend.cjs');
const OUT = __dirname + '/shots/';
require('fs').mkdirSync(OUT, { recursive: true });
const API = 'https://fute-lms-backend.onrender.com';
const OWNER = { id: 'u-owner', name: 'Prince Thomas', email: 'prince@fute.test', role: 'admin', roles: ['admin'], org_id: 'org-1' };

function fixture() {
  const co = (n) => ({ org_id: 'org-1', name: n, industry: 'Construction', location: 'Dallas, TX' });
  const lead = (id, pos, coName) => ({ id, org_id: 'org-1', position: pos, location: 'Dallas, TX', industry: 'Construction', stage: 'Connected', company_id: 'c-' + id, assigned_to_bd: 'u-owner', created_by: 'u-owner', assigned_to: null, company: co(coName) });
  const person = (id, jid, fn, ln) => ({ id, org_id: 'org-1', job_id: jid, first_name: fn, last_name: ln, email: fn.toLowerCase() + '@example.test', designation: 'Operations Director', linkedin: null, phone: null, email_status: 'out_of_office' });
  const L = [lead('j1', 'Project Manager', 'Acme Builders'), lead('j2', 'Estimator', 'Birch Homes'), lead('j3', 'Superintendent', 'Cobalt Civil')];
  const P = [person('k1', 'j1', 'Dana', 'Reyes'), person('k2', 'j2', 'Omar', 'Hale'), person('k3', 'j3', 'Ines', 'Park')];
  const rem = (id, i, date) => ({ id, org_id: 'org-1', user_id: 'u-owner', job_id: L[i].id, contact_id: P[i].id,
    contact_name: P[i].first_name + ' ' + P[i].last_name, company_name: L[i].company.name, email: P[i].email,
    return_date: date, reminder_time: '09:00', note: P[i].first_name + ' ' + P[i].last_name + ' is back from OOO.',
    status: 'pending', reminder_type: 'ooo_return', created_at: '2026-09-24T13:10:00Z', updated_at: '2026-09-24T13:10:00Z',
    job: L[i], contact: P[i] });
  return {
    users: [{ ...OWNER, deleted_at: null }],
    jobs: L, contacts: P, emails: [],
    reminders: [rem('r1', 0, '2026-09-28'), rem('r2', 1, '2026-10-01'), rem('r3', 2, '2026-10-05')],
  };
}

async function readDashboard(page) {
  return page.evaluate(() => {
    const cards = Array.from(document.querySelectorAll('#content .card'));
    const na = cards.find(c => /Needs you today|Nothing waiting on you/.test(c.innerText));
    const rw = cards.find(c => /^\s*Reminders/.test(c.innerText) && /Go to Reminders|View all|No reminders set/.test(c.innerText));
    return {
      needsYouToday: na ? na.innerText.replace(/\s+/g, ' ').trim().slice(0, 260) : '(card not found)',
      remindersCard: rw ? rw.innerText.replace(/\s+/g, ' ').trim().slice(0, 260) : '(card not found)',
    };
  });
}

async function openApp(browser, be, label) {
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  await ctx.addInitScript((u) => { sessionStorage.setItem('fg_token', 'harness'); sessionStorage.setItem('fg_user', JSON.stringify(u)); window.open = function (u2) { (window.__opened = window.__opened || []).push(String(u2)); return null; }; }, OWNER);
  const local = 'http://127.0.0.1:' + be.port;
  await ctx.route('**', async (r) => {
    const u = r.request().url();
    if (u.startsWith(local)) return r.continue();
    if (u.startsWith(API)) { const resp = await r.fetch({ url: local + u.slice(API.length) }); return r.fulfill({ response: resp }); }
    return r.abort();
  });
  const page = await ctx.newPage();
  page.on('pageerror', e => console.log('   [pageerror]', String(e).slice(0, 160)));
  await page.goto(local + '/', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => window.STATE && STATE.page === 'dashboard' && !STATE.loading && STATE.nextActions && STATE.nextActions.items, null, { timeout: 15000 });
  await page.waitForTimeout(600);
  return { ctx, page };
}
const reminderRow = (be) => { const r = be.fake.tables.reminders.find(x => x.id === 'r1'); return r.status + (r.updated_at !== r.created_at ? ' (updated_at moved)' : ' (updated_at == created_at)'); };

async function scenario(browser, name, act) {
  const be = await startBackend({ user: OWNER, tables: fixture() });
  console.log('\n=== ' + name + ' ===');
  let { ctx, page } = await openApp(browser, be);
  console.log(' before :', JSON.stringify(await readDashboard(page)));
  be.calls.length = 0;
  await act(page);
  await page.waitForTimeout(900);
  const writes = be.calls.filter(c => !c.startsWith('GET '));
  console.log(' requests sent by the action :', writes.length ? writes.join(' | ') : 'NONE');
  console.log(' server row r1 (28 Sep)      :', reminderRow(be));
  await page.evaluate(() => goPage('dashboard')); await page.waitForTimeout(700);
  const after = await readDashboard(page);
  console.log(' dashboard right after       :', JSON.stringify(after));
  await page.screenshot({ path: OUT + name.replace(/\W+/g, '_') + '_after.png', fullPage: false });
  await ctx.close();
  ({ ctx, page } = await openApp(browser, be));
  const reopened = await readDashboard(page);
  console.log(' dashboard after reopening   :', JSON.stringify(reopened));
  await page.screenshot({ path: OUT + name.replace(/\W+/g, '_') + '_reopened.png', fullPage: false });
  await ctx.close(); be.srv.close();
}

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  try {
    await scenario(browser, 'A  Needs-you-today Done', async (page) => {
      await page.locator('#content button.na-act', { hasText: 'Done' }).first().click();
    });
    await scenario(browser, 'B  Dashboard Reminders card Send', async (page) => {
      await page.locator('#content button', { hasText: /^\s*Send\s*$/ }).first().click();
      console.log(' window.open was asked for   :', JSON.stringify(await page.evaluate(() => (window.__opened || []).map(u => u.slice(0, 90)))));
    });
    await scenario(browser, 'C  Reminders page Dismiss', async (page) => {
      await page.evaluate(() => goPage('reminders')); await page.waitForTimeout(600);
      await page.locator('#content .rem-card button', { hasText: 'Dismiss' }).first().click();
    });
    await scenario(browser, 'D  Reminders page Compose + Send', async (page) => {
      await page.evaluate(() => goPage('reminders')); await page.waitForTimeout(600);
      await page.locator('#content .rem-card button', { hasText: 'Compose email' }).first().click();
      await page.waitForTimeout(600);
      await page.evaluate(() => applyReminderTemplate(0)); await page.waitForTimeout(300);
      await page.evaluate(() => sendReminderViaEngine());
    });
    await scenario(browser, 'E  Reminders page Remove (upcoming 1 Oct)', async (page) => {
      await page.evaluate(() => goPage('reminders')); await page.waitForTimeout(600);
      await page.locator('#content tr button', { hasText: 'Remove' }).first().click();
    });
  } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exit(1); });
