#!/usr/bin/env bash
# Deliberately reintroduce each old fault on a COPY of public/ and show that the harness catches it.
SC=/tmp/claude-0/-home-user-PACE-All-in-one-recruting-tool/2683caef-a9ba-5eed-bb57-5c335d09589a/scratchpad
LIVE=/home/user/PACE_All-in-one-recruting-tool
BT=$SC/break-tree
BASE=$SC/surface-r071/base-tree
rm -rf $BT && mkdir -p $BT
for d in routes services models config middleware; do [ -e $LIVE/$d ] && ln -s $LIVE/$d $BT/$d; done
for f in $LIVE/*.js $LIVE/package.json; do ln -s $f $BT/$(basename $f); done
run() {  # $1 label, $2 python patch snippet operating on dict P (path->text)
  rm -rf $BT/public && cp -a $LIVE/public $BT/public
  python3 - "$BT" "$BASE" <<PYEOF
import sys,re
bt,base=sys.argv[1],sys.argv[2]
def rd(p): return open(bt+'/public/'+p,encoding='utf-8').read()
def wr(p,s): open(bt+'/public/'+p,'w',encoding='utf-8').write(s)
$2
PYEOF
  echo "----- BREAK: $1"
  ( cd $SC/repro && PACE_REPO=$BT BACKEND=./backend-t.cjs NODE_PATH=../deps/node_modules node r071-after.cjs 2>&1 | grep -E "^===|FAIL|RESULT|pageerror" | awk '/^===/{h=$0;next} /FAIL|pageerror/{print h " :: " $0} /RESULT/{print $0}' | cut -c1-230 )
}
run "B1 a browser-only dismissReminder defined again (the original fault 1)" "s=rd('js/12-manager-users.js'); s+='\nwindow.dismissReminder=function(rid){STATE.reminders=STATE.reminders.filter(function(r){return r.id!==rid});showToast(\"Reminder removed\",\"info\");render();}\n'; wr('js/12-manager-users.js',s)"
run "B2 naDone re-reads only its own list (fault 4)" "s=rd('js/44-next-actions.js'); s=s.replace('reminderClosed(reminderId);','STATE.nextActions=null;loadNextActions(true);'); wr('js/44-next-actions.js',s)"
run "B3 Compose -> Send flips the local status only (fault 3)" "s=rd('js/03-core-render.js'); s=s.replace('if(rid)reminderClosed(rid);','if(rid)STATE.reminders=(STATE.reminders||[]).map(function(r){return r.id===rid?Object.assign({},r,{status:\"sent\"}):r;});'); wr('js/03-core-render.js',s)"
run "B4 a read in flight when a close lands is ignored, not repeated" "s=rd('js/44-next-actions.js'); s=s.replace('if(force)STATE._naAgain=true;',''); wr('js/44-next-actions.js',s)"
run "B5 the Dashboard card is the OLD one (Send / Send all due, web Gmail) (fault 2)" "wr('js/05-page-dashboard.js', open(base+'/public/js/05-page-dashboard.js',encoding='utf-8').read())"
run "B6 the card ignores compose.can_send and offers the send anyway" "s=rd('js/05-page-dashboard.js'); s=s.replace('var canSend=!!toEmail&&cmp.can_send!==false;','var canSend=!!toEmail;'); wr('js/05-page-dashboard.js',s)"
