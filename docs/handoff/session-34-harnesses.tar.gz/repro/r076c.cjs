// R-076 with a database that knows job_orders' real columns (from migrations/),
// answering an unknown column the way PostgREST does. Compares the public page as
// deployed now (routes/apply.js @ HEAD) with the same file before #222 (8ce7312^).
const Module = require('module'); const { execSync } = require('child_process');
const REPO = '/home/user/PACE_All-in-one-recruting-tool';
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const { startBackend } = require('./backend.cjs');
const API = 'https://fute-lms-backend.onrender.com';
const OWNER = { id: 'u-owner', name: 'Prince Thomas', email: 'prince@fute.test', role: 'admin', roles: ['admin'], org_id: 'org-1' };
const TOKEN = 'a1b2c3d4e5f60718293a4b5c6d7e8f90';
const cols = new Set(require('./job_orders_cols.json').concat(['org_id']));   // org_id comes from 022's loop
function loadFromGit(rev) {           // the old file, compiled as if it sat at routes/apply.js; nothing written
  const src = execSync(`git -C ${REPO} show ${rev}:routes/apply.js`, { encoding: 'utf8' });
  const m = new Module(REPO + '/routes/apply.js', null); m.filename = REPO + '/routes/apply.js';
  m.paths = Module._nodeModulePaths(REPO + '/routes'); m._compile(src, m.filename); return m.exports;
}
const fixture = () => ({
  users: [{ ...OWNER, deleted_at: null }], organizations: [{ id: 'org-1', name: 'Fute Global' }],
  job_orders: [{ id: 'jo-1', org_id: 'org-1', job_code: 'JO-1001', job_title: 'HVAC Technician', client: 'Northwind', status: 'Active',
    city: 'Hartford', state: 'CT', job_type: 'Full-time', job_description: 'Service and repair commercial HVAC systems.',
    bd_manager_id: 'u-owner', created_by: 'u-owner', created_at: '2026-09-20T10:00:00Z', deleted_at: null,
    apply_token: TOKEN, apply_enabled: true, apply_published_at: '2026-09-28T17:27:38Z', apply_count: 0,
    bd_manager: { id: 'u-owner', name: 'Prince Thomas' }, recruiters: [] }],
});
(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  for (const [label, mod] of [['routes/apply.js as deployed now', null], ['routes/apply.js before #222 (8ce7312^)', loadFromGit('8ce7312^')]]) {
    const be = await startBackend({ user: OWNER, tables: fixture(), strictColumns: { job_orders: cols }, applyModule: mod });
    const local = 'http://127.0.0.1:' + be.port;
    const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
    await ctx.addInitScript((u) => { sessionStorage.setItem('fg_token', 'harness'); sessionStorage.setItem('fg_user', JSON.stringify(u)); }, OWNER);
    await ctx.route('**', async (r) => { const u = r.request().url(); if (u.startsWith(local)) return r.continue(); if (u.startsWith(API)) { const resp = await r.fetch({ url: local + u.slice(API.length) }); return r.fulfill({ response: resp }); } return r.abort(); });
    const page = await ctx.newPage();
    await page.goto(local + '/', { waitUntil: 'domcontentloaded' });
    await page.waitForFunction(() => STATE.page === 'dashboard' && !STATE.loading, null, { timeout: 15000 });
    await page.evaluate(() => goPage('bd_joborders')); await page.waitForTimeout(700);
    await page.evaluate(() => bdOpenJobOrder('jo-1')); await page.waitForTimeout(800);
    const pub = async (tag) => { const p = await ctx.newPage(); const r = await p.goto(local + '/apply/' + TOKEN); const h = await p.evaluate(() => (document.querySelector('h1') || {}).innerText); if (tag) await p.screenshot({ path: __dirname + '/shots/' + tag + '.png' }); await p.close(); return 'HTTP ' + r.status() + ' "' + h + '"'; };
    const block = () => page.evaluate(() => { const el = Array.from(document.querySelectorAll('#content div')).find(d => /^Apply link/.test((d.innerText || '').trim()) && d.querySelector('button,input,div')); return el ? el.innerText.replace(/\s+/g, ' ').slice(0, 40) : '?'; });
    console.log('\n=== ' + label + ' ===');
    console.log(' screen: ' + await block() + ' | public: ' + await pub());
    await page.locator('#content button', { hasText: 'Turn off' }).click(); await page.waitForTimeout(600);
    console.log(' Turn off  -> screen: ' + await block() + ' | public: ' + await pub());
    await page.locator('#content button', { hasText: 'Publish apply page' }).click(); await page.waitForTimeout(600);
    console.log(' Publish   -> screen: ' + await block() + ' | db enabled=' + be.fake.tables.job_orders[0].apply_enabled + ' | public: ' + await pub(mod ? 'r076_public_before222' : 'r076_public_now'));
    const post = await fetch(local + '/apply/' + TOKEN, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ full_name: 'Jane Doe', email: 'jane@example.com', filename: 'cv.txt', content_type: 'text/plain', data_base64: Buffer.from('Jane Doe\njane@example.com\nHVAC tech').toString('base64') }) });
    console.log(' an application POSTed to the link -> HTTP ' + post.status + ' ' + (await post.text()).slice(0, 110));
    await ctx.close(); be.srv.close();
  }
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
