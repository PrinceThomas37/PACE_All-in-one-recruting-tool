// Job B (no "Your team" card) and Job C (the apply label agrees with the PUBLIC page), on whatever tree PACE_REPO names.
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const { startBackend } = require(process.env.BACKEND || './backend.cjs');
const fx = require('./r071-fixture.cjs');
const API = 'https://fute-lms-backend.onrender.com';
const OWNER = { id: 'u-owner', name: 'Prince Thomas', email: 'prince@fute.test', role: 'admin', roles: ['admin'], org_id: 'org-1' };
const TOKEN = 'a1b2c3d4e5f60718293a4b5c6d7e8f90';
let failures = 0; const check = (ok, msg) => { if (!ok) failures++; console.log('  ' + (ok ? 'PASS' : 'FAIL') + '  ' + msg); };
(async () => {
  const t = fx();
  t.job_orders = [{ id: 'jo-1', org_id: 'org-1', job_code: 'JO-1', job_title: 'HVAC Technician', client: 'Northwind', status: 'Active', city: 'Hartford', state: 'CT',
    job_description: 'Service HVAC.', bd_manager_id: 'u-owner', created_by: 'u-owner', owner_id: 'u-owner', created_at: '2026-09-20T10:00:00Z', deleted_at: null,
    apply_token: TOKEN, apply_enabled: true, apply_count: 0, recruiters: [] }];
  const be = await startBackend({ user: OWNER, tables: t });
  const local = 'http://127.0.0.1:' + be.port;
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  await ctx.addInitScript((u) => { sessionStorage.setItem('fg_token', 'harness'); sessionStorage.setItem('fg_user', JSON.stringify(u)); }, OWNER);
  await ctx.route('**', async (r) => { try { const u = r.request().url(); if (u.startsWith(local)) return await r.continue(); if (u.startsWith(API)) { const resp = await r.fetch({ url: local + u.slice(API.length) }); return await r.fulfill({ response: resp }); } return await r.abort(); } catch (e) {} });
  const page = await ctx.newPage(); page.on('pageerror', e => { failures++; console.log('  [pageerror]', String(e).slice(0, 160)); });
  await page.goto(local + '/', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => window.STATE && STATE.page === 'dashboard' && !STATE.loading, null, { timeout: 15000 });
  console.log('JOB B — the Dashboard has no "Your team" card');
  for (const withReports of [true, false]) {
    const html = await page.evaluate((withReports) => {
      STATE.viewingUser = null;
      STATE.users = [STATE.users.find(u => u.id === STATE.user.id) || { id: STATE.user.id, name: STATE.user.name, role: 'admin', roles: ['admin'] }].concat(withReports ? [
        { id: 'a', name: 'Riya Menon', role: 'bd', roles: ['bd'], managerId: STATE.user.id }, { id: 'b', name: 'Sam Okafor', role: 'recruiter', roles: ['recruiter'], managerId: STATE.user.id }] : []);
      return renderManagerDashboard(STATE.user);
    }, withReports);
    const text = html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');
    check(!/Open team view/.test(html) && !/No one reports to you yet/.test(text) && !/reporting line\b/.test(text.replace(/Submissions by stage across your reporting line/, '')) && !/direct report/.test(text),
      (withReports ? 'a manager WITH reports' : 'a manager with NO reports') + ': no roster, no "Open team view", no "No one reports to you yet"');
  }
  check(await page.evaluate(() => /Your team's pipeline/.test(renderManagerDashboard(STATE.user))), 'nothing else moved: "Your team\'s pipeline" is still there');
  console.log('JOB C — the apply label agrees with what the public page really does');
  for (const status of ['Active', 'active', 'Open', 'On Hold', 'Filled', 'Closed', '', null]) {
    t.job_orders[0].status = status;
    const code = (await fetch(local + '/apply/' + TOKEN)).status;
    const live = await page.evaluate((s) => bdApplyPageState({ apply_enabled: true, status: s }).live, status);
    check((code === 200) === live, 'status ' + JSON.stringify(status) + ': public page HTTP ' + code + '  vs  label live=' + live);
  }
  check(await page.evaluate(() => bdApplyPageState({ apply_enabled: false, status: 'Active' }).live === false), 'switched off is never "live"');
  await ctx.unrouteAll({ behavior: 'ignoreErrors' }); await browser.close(); be.srv.close();
  console.log(failures ? failures + ' FAILED' : 'ALL PASS'); process.exit(failures ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
