const OWNER = { id: 'u-owner', name: 'Prince Thomas', email: 'prince@fute.test', role: 'admin', roles: ['admin'], org_id: 'org-1' };
function fixture() {
  const co = (n) => ({ org_id: 'org-1', name: n, industry: 'Construction', location: 'Dallas, TX' });
  const lead = (id, pos, coName) => ({ id, org_id: 'org-1', position: pos, location: 'Dallas, TX', industry: 'Construction', stage: 'Connected', company_id: 'c-' + id, assigned_to_bd: 'u-owner', created_by: 'u-owner', assigned_to: null, company: co(coName) });
  const person = (id, jid, fn, ln) => ({ id, org_id: 'org-1', job_id: jid, first_name: fn, last_name: ln, email: fn.toLowerCase() + '@example.test', designation: 'Operations Director', linkedin: null, phone: null, email_status: 'out_of_office' });
  const L = [lead('j1', 'Project Manager', 'Acme Builders'), lead('j2', 'Estimator', 'Birch Homes'), lead('j3', 'Superintendent', 'Cobalt Civil')];
  const P = [person('k1', 'j1', 'Dana', 'Reyes'), person('k2', 'j2', 'Omar', 'Hale'), person('k3', 'j3', 'Ines', 'Park')];
  const rem = (id, i, date) => ({ id, org_id: 'org-1', user_id: 'u-owner', job_id: L[i].id, contact_id: P[i].id,
    contact_name: P[i].first_name + ' ' + P[i].last_name, company_name: L[i].company.name, email: P[i].email,
    return_date: date, reminder_time: '09:00', note: P[i].first_name + ' ' + P[i].last_name + ' is back from OOO.',
    status: 'pending', reminder_type: 'ooo_return', created_at: '2026-09-24T13:10:00Z', updated_at: '2026-09-24T13:10:00Z',
    job: L[i], contact: P[i] });
  return {
    users: [{ ...OWNER, deleted_at: null }],
    jobs: L, contacts: P, emails: [],
    reminders: [rem('r1', 0, '2026-09-28'), rem('r2', 1, '2026-10-01'), rem('r3', 2, '2026-10-05')],
  };
}


module.exports=fixture;
