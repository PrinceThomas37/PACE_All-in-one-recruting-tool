// Does the lead drawer's "Email" button arrive in the composer with the person filled in?
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const { startBackend } = require('./backend.cjs');
const API = 'https://fute-lms-backend.onrender.com';
const OWNER = { id: 'u-owner', name: 'Prince Thomas', email: 'prince@fute.test', role: 'admin', roles: ['admin'], org_id: 'org-1' };
(async () => {
  const be = await startBackend({ user: OWNER, tables: { users: [{ ...OWNER, deleted_at: null }] } });
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  await ctx.addInitScript((u) => { sessionStorage.setItem('fg_token', 'harness'); sessionStorage.setItem('fg_user', JSON.stringify(u)); }, OWNER);
  const local = 'http://127.0.0.1:' + be.port;
  await ctx.route('**', async (r) => {
    const u = r.request().url();
    if (u.startsWith(local)) return r.continue();
    if (u.startsWith(API + '/jobs')) return r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify([{ id: 'j1', position: 'Project Manager', stage: 'Connected', company_id: 'c1', assigned_to_bd: 'u-owner', company: { id: 'c1', name: 'Acme Builders' }, contacts: [{ id: 'k1', job_id: 'j1', first_name: 'Dana', last_name: 'Reyes', email: 'dana@example.test', designation: 'Operations Director', email_status: 'valid' }] }]) });
    if (u.startsWith(API)) { const resp = await r.fetch({ url: local + u.slice(API.length) }); return r.fulfill({ response: resp }); }
    return r.abort();
  });
  const page = await ctx.newPage(); page.on('pageerror', e => console.log('[pageerror]', String(e).slice(0, 160)));
  await page.goto(local + '/', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => STATE.page === 'dashboard' && !STATE.loading && STATE.contacts.length, null, { timeout: 15000 });
  await page.evaluate(() => { goPage('leads'); }); await page.waitForTimeout(500);
  await page.evaluate(() => openJob('j1')); await page.waitForTimeout(700);
  const btn = await page.locator('button', { hasText: /^Email$/ }).count();
  console.log('lead drawer shows an "Email" button on the contact card:', btn > 0);
  await page.locator('button', { hasText: /^Email$/ }).first().click(); await page.waitForTimeout(900);
  const st = await page.evaluate(() => ({ page: STATE.page, tab: STATE.emailTab, composeContactId: STATE.composeContactId, composeContext: STATE.composeContext,
    toast: Array.from(document.querySelectorAll('.toast,[class*=toast]')).map(e => e.innerText).join(' | ').slice(0, 80),
    genTo: (document.querySelector('#content input[type=email], #content input[id*=to], #content input[placeholder*="@"]') || {}).value,
    mentionsDana: /dana@example\.test|Dana Reyes/.test(document.getElementById('content').innerText) }));
  console.log(JSON.stringify(st));
  await page.screenshot({ path: __dirname + '/shots/r073_lead_email_button.png' });
  await browser.close(); be.srv.close();
})().catch(e => { console.error(e); process.exit(1); });
