// Admin's "Needs you today" carrying a reminder that belongs to another user.
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const { startBackend } = require('./backend.cjs');
const API = 'https://fute-lms-backend.onrender.com';
const OWNER = { id: 'u-owner', name: 'Prince Thomas', email: 'prince@fute.test', role: 'admin', roles: ['admin'], org_id: 'org-1' };
const fx = require('./r071-fixture.cjs');
(async () => {
  const t = fx(); t.reminders.forEach(r => { r.user_id = 'u-bd'; }); t.users.push({ id: 'u-bd', name: 'Spencer Brown', role: 'bd', org_id: 'org-1', deleted_at: null });
  const be = await startBackend({ user: OWNER, tables: t });
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  await ctx.addInitScript((u) => { sessionStorage.setItem('fg_token', 'harness'); sessionStorage.setItem('fg_user', JSON.stringify(u)); }, OWNER);
  const local = 'http://127.0.0.1:' + be.port;
  await ctx.route('**', async (r) => { const u = r.request().url(); if (u.startsWith(local)) return r.continue(); if (u.startsWith(API)) { const resp = await r.fetch({ url: local + u.slice(API.length) }); return r.fulfill({ response: resp }); } return r.abort(); });
  const page = await ctx.newPage();
  await page.goto(local + '/', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => STATE.page === 'dashboard' && !STATE.loading && STATE.nextActions && STATE.nextActions.items, null, { timeout: 15000 });
  await page.waitForTimeout(500);
  const na = () => page.evaluate(() => { const c = Array.from(document.querySelectorAll('#content .card')).find(c => /Needs you today|Nothing waiting/.test(c.innerText)); return c ? c.innerText.replace(/\s+/g, ' ').slice(0, 140) : '?'; });
  console.log('admin, reminder owned by Spencer | before:', await na());
  await page.locator('#content button.na-act', { hasText: 'Done' }).first().click(); await page.waitForTimeout(800);
  const toast = await page.evaluate(() => Array.from(document.querySelectorAll('.toast, [class*=toast]')).map(e => e.innerText).join(' | ').slice(0, 200));
  console.log('                                 | after Done:', await na());
  console.log('                                 | toast:', toast, '| server row:', be.fake.tables.reminders[0].status);
  await browser.close(); be.srv.close();
})().catch(e => { console.error(e); process.exit(1); });
