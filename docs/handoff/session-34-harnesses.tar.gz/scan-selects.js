'use strict';
// Every literal select-list / filter column in the backend vs the migration-derived schema.
// Only tables whose CREATE TABLE is in the migrations (else the map is partial => false positives).
const fs = require('fs'), path = require('path');
const { cols, created } = require('./column-map.js');
const ROOT = process.env.SCAN_ROOT || '/home/user/PACE_All-in-one-recruting-tool';
const SKIP = new Set(['node_modules', '.git', 'test', 'docs', 'migrations', 'public', '.claude', 'scripts']);
function walk(d) { let o = []; for (const e of fs.readdirSync(d, { withFileTypes: true })) { if (SKIP.has(e.name)) continue; const p = path.join(d, e.name); if (e.isDirectory()) o = o.concat(walk(p)); else if (e.name.endsWith('.js')) o.push(p); } return o; }
const splitTop = (s) => { const out = []; let d = 0, cur = ''; for (const ch of s) { if (ch === '(') d++; if (ch === ')') d--; if (ch === ',' && d === 0) { out.push(cur); cur = ''; } else cur += ch; } if (cur.trim()) out.push(cur); return out; };

// The whole balanced argument of the first .select( in `win`, with every string literal joined
// (a select list is often written 'a,b,' + 'c,d' across lines — reading only the first literal was
// how this scan first passed VACUOUSLY on the very file it exists to catch).
function selectArg(win) {
  const i = win.search(/\.select\(/);
  if (i < 0) return null;
  let j = i + 8, depth = 1, q = null, lits = [], cur = '';
  for (; j < win.length && depth > 0; j++) {
    const ch = win[j];
    if (q) { if (ch === '\\') { cur += win[++j] || ''; continue; } if (ch === q) { lits.push(cur); cur = ''; q = null; } else cur += ch; continue; }
    if (ch === "'" || ch === '"' || ch === '`') { q = ch; continue; }
    if (ch === '(') depth++;
    if (ch === ')') depth--;
  }
  return lits.length ? lits.join('') : null;
}
const hits = []; let checked = 0, tablesSeen = new Set();
for (const f of walk(ROOT)) {
  const src = fs.readFileSync(f, 'utf8');
  const froms = [...src.matchAll(/\.from\(\s*['"]([a-z_]+)['"]\s*\)/g)];
  froms.forEach((m, i) => {
    const t = m[1];
    if (!created.has(t) || !cols[t] || cols[t].size < 6) return;
    const end = Math.min(froms[i + 1] ? froms[i + 1].index : src.length, m.index + 900);
    const win = src.slice(m.index, end);
    const line = src.slice(0, m.index).split('\n').length;
    const bad = [];
    const sel = selectArg(win);
    if (sel) for (const item of splitTop(sel)) {
      let c = item.trim(); if (!c || c.includes('(') || c === '*') continue;
      c = c.replace(/^[a-z_]+:/i, '').replace(/!.*$/, '').trim();          // alias:col , col!hint
      if (c && !cols[t].has(c)) bad.push(c);
    }
    for (const fm of win.matchAll(/\.(?:eq|neq|is|in|ilike|like|gt|gte|lt|lte|order)\(\s*['"]([a-z_]+)['"]/g)) if (!cols[t].has(fm[1])) bad.push(fm[1]);
    checked++; tablesSeen.add(t);
    if (bad.length) hits.push(`${path.relative(ROOT, f)}:${line}  ${t}  ->  ${[...new Set(bad)].join(', ')}`);
  });
}
console.log(`checked ${checked} from()-chains on ${tablesSeen.size} fully-migrated tables: ${[...tablesSeen].sort().join(' ')}`);
console.log(hits.length ? `\n${hits.length} chains name a column the migrations do not define:\n` + hits.slice(0, 45).join('\n') : '\nNONE');
