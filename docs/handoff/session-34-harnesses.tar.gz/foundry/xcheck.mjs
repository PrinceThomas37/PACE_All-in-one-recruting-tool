import { createRequire } from 'node:module';
import { loadSchema } from '/home/user/PACE_All-in-one-recruting-tool/test/helpers/schema-from-migrations.mjs';
const require = createRequire(import.meta.url);
const { TENANT_TABLES, GLOBAL_TABLES } = require('/home/user/PACE_All-in-one-recruting-tool/models/tables.js');
const s = loadSchema();
const noFold = [], missingOrg = [], globalWithOrg = [];
for (const t of TENANT_TABLES) { if (!s.has(t)) noFold.push(t); else if (!s.columns(t).has('org_id')) missingOrg.push(t); }
for (const t of GLOBAL_TABLES) { if (s.has(t) && s.columns(t).has('org_id')) globalWithOrg.push(t); }
console.log('tenant tables with no fold at all:', noFold.join(',') || 'none');
console.log('tenant tables whose fold lacks org_id:', missingOrg.join(',') || 'none');
console.log('global tables whose fold HAS org_id:', globalWithOrg.join(',') || 'none');
console.log('complete tables:', [...s.created].length, ' tenant-complete:', [...TENANT_TABLES].filter(t=>s.isComplete(t)).length);
