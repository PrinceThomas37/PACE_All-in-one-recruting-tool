// FOUNDRY's deliberate-break runner (scratch; NOT part of the repo).
//
//   node mutate.mjs <spec.mjs> [id-prefix ...]
//
// Keeps a COPY of the repo (mtree/), never touching the live tree. For each
// mutation: restore the touched file from the live tree, apply ONE change (every
// `find` must be present — a mutation that does not apply is reported, never
// silently skipped: that would be a vacuous proof), run the named test(s) inside
// the copy, and require
//   * a NON-ZERO exit AND at least one failing line (a crash that prints no FAIL
//     line is not a catch — CLAUDE.md, ledger's lesson: count FAIL lines), and
//   * when `expect` is given, a failing line that names it.
// `stayGreen` lists tests that must still PASS under the same break (used to show
// that the OLD apply-page suite is blind to R-076).
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

const LIVE = '/home/user/PACE_All-in-one-recruting-tool';
const HERE = path.dirname(new URL(import.meta.url).pathname);
const COPY = path.join(HERE, 'mtree');
const SRC_DIRS = ['routes', 'services', 'models', 'config', 'middleware', 'public', 'migrations', 'test', 'lead-sources', 'scripts'];

export function syncCopy() {
  fs.mkdirSync(COPY, { recursive: true });
  for (const d of SRC_DIRS) {
    fs.rmSync(path.join(COPY, d), { recursive: true, force: true });
    if (fs.existsSync(path.join(LIVE, d))) fs.cpSync(path.join(LIVE, d), path.join(COPY, d), { recursive: true });
  }
  for (const f of fs.readdirSync(LIVE)) {
    if (/\.(js|json|sql)$/.test(f) && fs.statSync(path.join(LIVE, f)).isFile()) fs.copyFileSync(path.join(LIVE, f), path.join(COPY, f));
  }
  const nm = path.join(COPY, 'node_modules');
  if (!fs.existsSync(nm)) fs.symlinkSync(path.join(LIVE, 'node_modules'), nm);
}

function restore(file) {
  const to = path.join(COPY, file);
  fs.mkdirSync(path.dirname(to), { recursive: true });
  if (fs.existsSync(path.join(LIVE, file))) fs.copyFileSync(path.join(LIVE, file), to);
}

export function runTest(test, env) {
  const t0 = Date.now();
  const rel = test.includes('/') ? test : path.join('test', test);
  const r = spawnSync(process.execPath, [path.join(COPY, rel)], {
    cwd: COPY, encoding: 'utf8', timeout: 240000, maxBuffer: 64 * 1024 * 1024,
    env: Object.assign({}, process.env, { PLAYWRIGHT_BROWSERS_PATH: process.env.PLAYWRIGHT_BROWSERS_PATH || '/opt/pw-browsers' }, env || {}),
  });
  const out = (r.stdout || '') + (r.stderr || '');
  const lines = out.split('\n');
  const fails = lines.filter(l => /^\s*(\[FAIL\]|✗|FAIL\b)/.test(l));
  const summary = (out.match(/(?:SUMMARY:\s*)?(\d+)\/(\d+)\s*(?:passed)?/g) || []).slice(-1)[0] || '';
  return { status: r.status, signal: r.signal, out, fails, summary, ms: Date.now() - t0, crashed: r.status !== 0 && !fails.length };
}

const [, , specPath, ...prefixes] = process.argv;
if (specPath) {
  const spec = (await import(pathToFileURL(path.resolve(specPath)).href)).default;
  syncCopy();
  // baseline: every test used must be green in the copy before any mutation counts
  const tests = [...new Set(spec.flatMap(m => (m.tests || []).concat(m.stayGreen || [])))];
  const base = {};
  for (const t of tests) {
    if (spec.setup) spec.setup(COPY);
    const r = runTest(t); base[t] = r;
    console.log(`baseline ${t}: exit=${r.status} ${r.summary}${r.fails.length ? '  FAILS: ' + r.fails.slice(0, 3).join(' | ') : ''}`);
  }
  const notGreen = tests.filter(t => base[t].status !== 0 || base[t].fails.length);
  if (notGreen.length && !process.env.ALLOW_RED_BASELINE) { console.log('BASELINE NOT GREEN for: ' + notGreen.join(', ') + ' — stopping'); process.exit(2); }

  let caught = 0, missed = 0, setup = 0;
  for (const m of spec) {
    if (prefixes.length && !prefixes.some(p => m.id.startsWith(p))) continue;
    restore(m.file);
    (m.restore || []).forEach(restore);
    const fp = path.join(COPY, m.file);
    let src = fs.existsSync(fp) ? fs.readFileSync(fp, 'utf8') : '';
    let ok = true;
    for (const [find, rep, all] of (m.edits || [])) {
      if (!src.includes(find)) { console.log(`[SETUP ] ${m.id} — cannot find the text to mutate in ${m.file}: ${JSON.stringify(find.slice(0, 80))}`); ok = false; break; }
      src = all ? src.split(find).join(rep) : src.replace(find, () => rep);
    }
    if (!ok) { setup++; continue; }
    if (m.write) m.write(COPY);   // extra file plants (e.g. a fake worktree)
    fs.writeFileSync(fp, src);
    let verdict = null, detail = '';
    for (const t of m.tests) {
      const r = runTest(t, m.env);
      const named = r.fails.filter(l => !m.expect || (m.expect instanceof RegExp ? m.expect.test(l) : l.includes(m.expect)));
      if (r.status !== 0 && named.length) { verdict = 'CAUGHT'; detail = `${t}: ${r.summary} — "${named[0].replace(/^\s*(\[FAIL\]|✗)\s*/, '').slice(0, 110)}"`; break; }
      detail += `${t}: exit=${r.status} ${r.summary}${r.crashed ? ' CRASH(no FAIL line) ' + r.out.split('\n').filter(Boolean).slice(-2).join(' ').slice(0, 140) : ''}${r.fails.length ? ' fails=' + r.fails.length + ' but none names ' + JSON.stringify(String(m.expect)) + ' e.g. ' + r.fails[0].slice(0, 90) : ''}; `;
    }
    if (verdict === 'CAUGHT') caught++; else { verdict = 'MISSED'; missed++; }
    let green = '';
    for (const t of (m.stayGreen || [])) {
      const r = runTest(t, m.env);
      const stays = r.status === 0 && !r.fails.length;
      green += ` | old suite ${t} under the same break: ${stays ? 'STAYS GREEN ' + r.summary : 'goes red (exit ' + r.status + ' ' + r.summary + ')'}`;
    }
    console.log(`[${verdict}] ${m.id} ${m.what || ''}  ->  ${detail}${green}`);
    restore(m.file);
  }
  console.log(`\n${caught} caught, ${missed} missed, ${setup} did not apply`);
  process.exit(missed || setup ? 1 : 0);
}
