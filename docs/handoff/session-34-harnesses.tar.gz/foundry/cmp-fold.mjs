import { createRequire } from 'node:module';
import { loadSchema } from '/home/user/PACE_All-in-one-recruting-tool/test/helpers/schema-from-migrations.mjs';
const require = createRequire(import.meta.url);
const ref = require('/tmp/claude-0/-home-user-PACE-All-in-one-recruting-tool/2683caef-a9ba-5eed-bb57-5c335d09589a/scratchpad/column-map.js');
const mine = loadSchema();
let diffs = 0;
for (const t of new Set([...Object.keys(ref.cols), ...Object.keys(mine.cols)])) {
  const a = ref.cols[t] || new Set(), b = mine.cols[t] || new Set();
  const onlyRef = [...a].filter(x => !b.has(x)), onlyMine = [...b].filter(x => !a.has(x));
  if (onlyRef.length || onlyMine.length) { diffs++; console.log(t, 'only-in-reference:', onlyRef.join(','), '| only-in-mine:', onlyMine.join(',')); }
}
console.log('tables:', Object.keys(mine.cols).length, 'diffs:', diffs);
for (const t of ['job_orders','sourcing_candidates','candidates']) console.log(t, mine.columns(t).size, 'owner_id?', mine.columns(t).has('owner_id'), 'complete?', mine.isComplete(t));
console.log('app_settings has org_id?', mine.columns('app_settings').has('org_id'), '| microsoft_tokens has org_id?', mine.columns('microsoft_tokens').has('org_id'));
