-- PREVIEW (read-only). Expect 15 rows: all 'Tagged', submission_id empty.
SELECT cp.pipeline_code, cp.candidate_id, cp.job_order_id, cp.pipeline_status, cp.tagged_at, cp.tagged_by, cp.org_id
  FROM candidate_pipeline cp WHERE cp.deleted_at IS NULL AND cp.submission_id IS NULL ORDER BY cp.tagged_at, cp.id;

-- FIX (one transaction; safe to re-run)
BEGIN;
UPDATE candidate_pipeline cp SET submission_id = s.id, pipeline_status = 'Sourced', updated_at = now()
  FROM submissions s
 WHERE cp.deleted_at IS NULL AND cp.submission_id IS NULL AND s.deleted_at IS NULL
   AND s.candidate_id = cp.candidate_id AND s.job_order_id = cp.job_order_id AND s.org_id = cp.org_id;
UPDATE submissions s SET pipeline_id = cp.id
  FROM candidate_pipeline cp
 WHERE cp.deleted_at IS NULL AND cp.submission_id = s.id AND s.deleted_at IS NULL AND s.pipeline_id IS NULL;
DO $$
DECLARE r RECORD; new_id uuid;
BEGIN
  FOR r IN SELECT cp.* FROM candidate_pipeline cp
            WHERE cp.deleted_at IS NULL AND cp.submission_id IS NULL ORDER BY cp.tagged_at, cp.id
  LOOP
    INSERT INTO submissions (org_id, submission_code, candidate_id, job_order_id, recruiter_id, submitted_by,
                             stage, stage_updated_at, created_at, revision_status,
                             bill_rate, pay_rate, employer_name, availability, notice_period, notes, pipeline_id)
    VALUES (r.org_id, next_id('SB'), r.candidate_id, r.job_order_id, r.tagged_by, r.tagged_by,
            'Sourced', r.tagged_at, r.tagged_at, 'N/A',
            r.bill_rate, r.pay_rate, r.employer_name, r.availability, r.notice_period, r.notes, r.id)
    RETURNING id INTO new_id;
    UPDATE candidate_pipeline SET submission_id = new_id, pipeline_status = 'Sourced', updated_at = now() WHERE id = r.id;
  END LOOP;
END $$;
UPDATE candidate_pipeline SET pipeline_status = 'Sourced' WHERE deleted_at IS NULL AND pipeline_status <> 'Sourced';
COMMIT;

-- CHECK (on the live data expect 0, 0, 0, 0 and 15)
SELECT (SELECT count(*) FROM candidate_pipeline WHERE deleted_at IS NULL AND submission_id IS NULL) AS still_unlinked,
       (SELECT count(*) FROM candidate_pipeline WHERE deleted_at IS NULL AND pipeline_status <> 'Sourced') AS still_saying_a_retired_word,
       (SELECT count(*) FROM candidate_pipeline cp JOIN submissions s ON s.id = cp.submission_id WHERE s.pipeline_id IS DISTINCT FROM cp.id) AS links_that_do_not_agree,
       (SELECT count(*) FROM submissions WHERE stage = 'Sourced' AND submitted_at IS NOT NULL) AS wrongly_stamped_as_submitted,
       (SELECT count(*) FROM submissions WHERE deleted_at IS NULL) AS people_now_on_a_job;
