#!/usr/bin/env bash
# usage: run-in-tree.sh <tree> <label> <suite...>
# Runs each suite inside the given tree (an isolated copy), logs per suite, appends a one-line result.
TREE="$1"; LABEL="$2"; shift 2
SC=/tmp/claude-0/-home-user-PACE-All-in-one-recruting-tool/2683caef-a9ba-5eed-bb57-5c335d09589a/scratchpad/surface-r071
OUT="$SC/$LABEL-results.txt"
: > "$OUT"
cd "$TREE"
for t in "$@"; do
  timeout 900 node "test/$t.mjs" > "$SC/$LABEL-$t.log" 2>&1
  code=$?
  line=$(grep -E "SUMMARY|passed" "$SC/$LABEL-$t.log" | tail -1)
  echo "$t | exit=$code | $line" >> "$OUT"
done
echo "=== DONE" >> "$OUT"
