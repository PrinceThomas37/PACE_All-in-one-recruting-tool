#!/usr/bin/env bash
# Baseline of the suites my changes can touch, on the untouched tree.
cd /home/user/PACE_All-in-one-recruting-tool
OUT=/tmp/claude-0/-home-user-PACE-All-in-one-recruting-tool/2683caef-a9ba-5eed-bb57-5c335d09589a/scratchpad/surface-r071/baseline-results.txt
: > "$OUT"
for t in reminder-clarity-smoke recruiter-dashboard-smoke team-structure-smoke next-action-dismiss-smoke next-action-smoke morning-briefing-card-smoke frontend-smoke nav-icons-smoke page-renders-smoke screen-stability-smoke mobile-layout-smoke theme-contrast-smoke ageing-layout-smoke ui-smoothness-smoke applicants-ui-smoke row-reveal-smoke job-open-details-smoke overlay-opacity-smoke client-digest-ui-smoke mailbox-alerts-ui-smoke ownership-requests-smoke; do
  echo "=== $t" >> "$OUT"
  timeout 900 node "test/$t.mjs" > "/tmp/claude-0/-home-user-PACE-All-in-one-recruting-tool/2683caef-a9ba-5eed-bb57-5c335d09589a/scratchpad/surface-r071/base-$t.log" 2>&1
  echo "exit=$?" >> "$OUT"
  grep -E "SUMMARY|RESULT|passed" "/tmp/claude-0/-home-user-PACE-All-in-one-recruting-tool/2683caef-a9ba-5eed-bb57-5c335d09589a/scratchpad/surface-r071/base-$t.log" | tail -2 >> "$OUT"
done
echo "=== DONE" >> "$OUT"
