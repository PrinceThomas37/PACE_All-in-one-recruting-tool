\pset format unaligned
\pset tuples_only on
WITH o AS (SELECT (SELECT id FROM organizations ORDER BY created_at LIMIT 1) AS a, (SELECT id FROM organizations WHERE slug='other') AS b),
legacy AS (SELECT cp.*, s.stage s_stage, s.submitted_at s_submitted_at, s.created_at s_created, s.stage_updated_at s_upd, s.recruiter_id s_rec, s.submitted_by s_by, s.org_id s_org, s.pipeline_id s_pl, s.submission_code s_code, s.bill_rate s_bill, s.employer_name s_emp, s.notes s_notes, s.deleted_at s_del
             FROM candidate_pipeline cp JOIN submissions s ON s.id = cp.submission_id WHERE cp.pipeline_code ~ '^PL-000(0[1-9]|1[0-5])$')
SELECT 'legacy rows linked: ' || count(*) || ' (want 15)' FROM legacy
UNION ALL SELECT 'all Sourced, none stamped submitted_at: ' || (count(*) FILTER (WHERE s_stage='Sourced' AND s_submitted_at IS NULL)) || ' (want 15)' FROM legacy
UNION ALL SELECT 'dated when tagged (created_at and stage_updated_at = tagged_at): ' || (count(*) FILTER (WHERE s_created = tagged_at AND s_upd = tagged_at)) || ' (want 15)' FROM legacy
UNION ALL SELECT 'owned by whoever tagged them: ' || (count(*) FILTER (WHERE s_rec = tagged_by AND s_by = tagged_by)) || ' (want 15)' FROM legacy
UNION ALL SELECT 'filed under the same company as the tag: ' || (count(*) FILTER (WHERE s_org = org_id)) || ' (want 15)' FROM legacy
UNION ALL SELECT 'linked both ways: ' || (count(*) FILTER (WHERE s_pl = id)) || ' (want 15)' FROM legacy
UNION ALL SELECT 'status word retired: ' || (count(*) FILTER (WHERE pipeline_status = 'Sourced')) || ' (want 15)' FROM legacy
UNION ALL SELECT 'codes SB-00001..SB-00015 in tag order: ' || (SELECT string_agg(s_code, ',' ORDER BY tagged_at) FROM legacy) 
UNION ALL SELECT 'details carried over (rate 80 x2, Acme x1, note x1): ' || (count(*) FILTER (WHERE s_bill='80')) || ',' || (count(*) FILTER (WHERE s_emp='Acme')) || ',' || (count(*) FILTER (WHERE s_notes='from the database')) FROM legacy
UNION ALL SELECT 'E1 pair had a submission: linked, not duplicated, stage untouched: ' || (SELECT count(*) FROM submissions s JOIN candidate_pipeline cp ON cp.submission_id=s.id WHERE cp.pipeline_code='PL-E1' AND s.submission_code='SB-EXIST1' AND s.stage='Screening' AND s.pipeline_id=cp.id) || ' and total live for that person: ' || (SELECT count(*) FROM submissions s JOIN candidates c ON c.id=s.candidate_id WHERE c.full_name='Live Cand 16' AND s.deleted_at IS NULL) || ' (want 1 and 1)'
UNION ALL SELECT 'E2 soft-deleted pipeline row untouched: ' || (SELECT count(*) FROM candidate_pipeline WHERE pipeline_code='PL-E2' AND submission_id IS NULL AND pipeline_status='Tagged' AND deleted_at IS NOT NULL) || ' (want 1)'
UNION ALL SELECT 'E3 no tagger recorded -> submission with no owner, no error: ' || (SELECT count(*) FROM submissions s JOIN candidate_pipeline cp ON cp.submission_id=s.id WHERE cp.pipeline_code='PL-E3' AND s.recruiter_id IS NULL AND s.stage='Sourced') || ' (want 1)'
UNION ALL SELECT 'E4 other company keeps ITS company (not the default): ' || (SELECT count(*) FROM submissions s JOIN candidate_pipeline cp ON cp.submission_id=s.id, o WHERE cp.pipeline_code='PL-E4' AND s.org_id=o.b AND s.org_id<>o.a) || ' (want 1)'
UNION ALL SELECT 'E5 soft-deleted submission does not block a new live one, and stays deleted: ' || (SELECT count(*) FROM submissions WHERE submission_code='SB-GONE5' AND deleted_at IS NOT NULL AND stage='Offer') || ' and a new live Sourced one: ' || (SELECT count(*) FROM submissions s JOIN candidates c ON c.id=s.candidate_id WHERE c.full_name='Live Cand 19' AND s.deleted_at IS NULL AND s.stage='Sourced') || ' (want 1 and 1)'
UNION ALL SELECT 'E6 already linked: word retired, link and stage untouched: ' || (SELECT count(*) FROM candidate_pipeline cp JOIN submissions s ON s.id=cp.submission_id WHERE cp.pipeline_code='PL-E6' AND cp.pipeline_status='Sourced' AND s.submission_code='SB-LINK6' AND s.stage='Submitted to BDM') || ' (want 1)'
UNION ALL SELECT 'SB counter advanced by exactly the rows created: ' || (SELECT last_value FROM id_sequences WHERE prefix='SB') || ' (want 18 = 15 + E3 + E4 + E5)'
UNION ALL SELECT 'still_unlinked: ' || count(*) || ' (want 0)' FROM candidate_pipeline WHERE deleted_at IS NULL AND submission_id IS NULL
UNION ALL SELECT 'still_saying_a_retired_word: ' || count(*) || ' (want 0)' FROM candidate_pipeline WHERE deleted_at IS NULL AND pipeline_status <> 'Sourced'
UNION ALL SELECT 'links_that_do_not_agree: ' || count(*) || ' (want 0)' FROM candidate_pipeline cp JOIN submissions s ON s.id = cp.submission_id WHERE s.pipeline_id IS DISTINCT FROM cp.id
UNION ALL SELECT 'sourced_rows_wrongly_stamped_as_submitted: ' || count(*) || ' (want 0)' FROM submissions WHERE stage = 'Sourced' AND submitted_at IS NOT NULL
UNION ALL SELECT 'people_now_on_a_job: ' || count(*) || ' (want 20 = 2 existing + 18 created)' FROM submissions WHERE deleted_at IS NULL;
