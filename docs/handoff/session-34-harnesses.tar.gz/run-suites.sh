#!/usr/bin/env bash
# Usage: run-suites.sh <outdir> <suite> [<suite> ...]
# Runs each browser suite from the worktree root, one after another, writing
# <outdir>/<suite>.txt and appending "<suite> exit=<code>" to <outdir>/_summary.txt
WT=/home/user/PACE_All-in-one-recruting-tool/.claude/worktrees/agent-aba185e818ec414d2
OUT="$1"; shift
mkdir -p "$OUT"
cd "$WT" || exit 2
for t in "$@"; do
  node "test/$t.mjs" > "$OUT/$t.txt" 2>&1
  code=$?
  last=$(grep -E "SUMMARY|passed|PASS|FAIL" "$OUT/$t.txt" | tail -1)
  echo "$t exit=$code  $last" >> "$OUT/_summary.txt"
done
echo "ALL DONE" >> "$OUT/_summary.txt"
