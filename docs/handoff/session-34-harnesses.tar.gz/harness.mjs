// Scratch harness for guild R-075 / R-077. NOT in test/ (foundry's). It mounts the
// REAL recruiting routers through the REAL mounter (bd_recruiter_routes.js) and the
// REAL models/ layer over an in-memory PostgREST that is deliberately strict in the
// ways the live one is:
//   * partial unique indexes on (candidate_id, job_order_id) WHERE deleted_at IS NULL
//     for submissions and candidate_pipeline  -> 23505
//   * org_id DEFAULTs to the default org when an insert forgets it (the live column
//     default) -> a missing org stamp is VISIBLE as a row filed under the wrong org
//   * malformed uuids in id filters are refused with 22P02 (the live behaviour that
//     makes one bad id sink a whole .in() chunk)
//   * rows are PROJECTED to the route's own select (a column the route did not ask
//     for is simply absent), and the embeds the routes use are resolved
//   * candidate_pipeline.pipeline_status defaults to 'Tagged' (the live default), so
//     any code that lets the default through is caught
import { createRequire } from 'node:module';
import crypto from 'node:crypto';
const require = createRequire(import.meta.url);
const ROOT = process.env.GUILD_ROOT || '/home/user/PACE_All-in-one-recruting-tool';

export const DEFAULT_ORG = '00000000-0000-4000-8000-00000000d0d0';
export const ORG_A = '00000000-0000-4000-8000-0000000000aa';
export const ORG_B = '00000000-0000-4000-8000-0000000000bb';
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export const uid = () => crypto.randomUUID();

const UNIQUE = { submissions: ['candidate_id', 'job_order_id'], candidate_pipeline: ['candidate_id', 'job_order_id'] };
const UUID_COLS = new Set(['id', 'candidate_id', 'job_order_id', 'submission_id', 'pipeline_id', 'org_id', 'recruiter_id', 'user_id', 'submitted_by']);
// alias -> [table, fk column on the row]
const EMBEDS = {
  candidate: ['candidates', 'candidate_id'], job: ['job_orders', 'job_order_id'],
  submission: ['submissions', 'submission_id'], tagger: ['users', 'tagged_by'],
  recruiter: ['users', 'recruiter_id'], submitter: ['users', 'submitted_by'],
};

export function makeDb() {
  const tables = {};
  const T = n => (tables[n] = tables[n] || []);
  const log = { writes: [], calls: [] };
  const hooks = { beforeUpdate: null, failNext: null, failIf: null, updates: 0 };
  let seq = { SB: 0, PL: 0, CN: 0 };

  function splitSelect(cols) {
    // top-level comma split, respecting parentheses
    const parts = []; let depth = 0, cur = '';
    for (const ch of String(cols || '*')) {
      if (ch === '(') depth++; if (ch === ')') depth--;
      if (ch === ',' && depth === 0) { parts.push(cur.trim()); cur = ''; } else cur += ch;
    }
    if (cur.trim()) parts.push(cur.trim());
    return parts;
  }
  function project(table, row, cols) {
    if (!row) return row;
    const parts = splitSelect(cols);
    const out = {};
    for (const p of parts) {
      const m = p.match(/^(\w+):(\w+)(?:!\w+)?\((.*)\)$/);
      if (m) {
        const [, alias, tbl, inner] = m;
        const emb = EMBEDS[alias];
        const fk = emb ? emb[1] : null;
        const target = fk ? T(emb[0]).find(r => r.id === row[fk]) : null;
        out[alias] = target ? project(emb[0], target, inner) : null;
      } else if (p === '*') Object.assign(out, Object.fromEntries(Object.entries(row).filter(([k]) => typeof row[k] !== 'function')));
      else out[p] = row[p] === undefined ? undefined : row[p];
    }
    // undefined keys are "not a column" — drop so a missing column is truly absent
    Object.keys(out).forEach(k => { if (out[k] === undefined) delete out[k]; });
    return JSON.parse(JSON.stringify(out));
  }

  function from(table) {
    const st = { filters: [], op: 'select', payload: null, cols: '*', returning: false, single: false, maybe: false, order: null, limit: null };
    const rows = () => T(table).filter(r => st.filters.every(f => f(r)));
    const uuidErr = (k, v) => (UUID_COLS.has(k) && v != null && !UUID.test(String(v)))
      ? { code: '22P02', message: `invalid input syntax for type uuid: "${v}"` } : null;
    let bad = null;
    const api = {
      select(cols) { st.cols = cols == null ? '*' : cols; if (st.op !== 'select') st.returning = true; return api; },
      eq(k, v) { bad = bad || uuidErr(k, v); st.filters.push(r => r[k] === v); return api; },
      is(k, v) { st.filters.push(r => (r[k] == null) === (v == null)); return api; },
      in(k, vs) { (vs || []).forEach(v => { bad = bad || uuidErr(k, v); }); st.filters.push(r => (vs || []).includes(r[k])); return api; },
      order(k, o) { st.order = [k, o && o.ascending === false ? -1 : 1]; return api; },
      limit(n) { st.limit = n; return api; },
      insert(p) { st.op = 'insert'; st.payload = p; return api; },
      update(p) { st.op = 'update'; st.payload = p; return api; },
      delete() { st.op = 'delete'; return api; },
      single() { st.single = true; return api; },
      maybeSingle() { st.single = true; st.maybe = true; return api; },
      then(res, rej) { return run().then(res, rej); },
    };
    function defaults(r) {
      const now = new Date().toISOString();
      const base = { id: uid(), deleted_at: null, org_id: DEFAULT_ORG, created_at: now };
      if (table === 'submissions') Object.assign(base, { stage: 'Sourced', stage_updated_at: now });
      if (table === 'candidate_pipeline') Object.assign(base, { pipeline_status: 'Tagged', tagged_at: now });
      return Object.assign(base, r);
    }
    async function run() {
      if (bad) return { data: null, error: bad };
      let out;
      if (st.op === 'insert') {
        const list = Array.isArray(st.payload) ? st.payload : [st.payload];
        const made = [];
        for (const p of list) {
          const u = UNIQUE[table];
          if (u && T(table).some(r => !r.deleted_at && u.every(k => r[k] === p[k]))) return { data: null, error: { code: '23505', message: 'duplicate key value violates unique constraint' } };
          if (table === 'submissions' && (!p.candidate_id || !p.job_order_id)) return { data: null, error: { code: '23502', message: 'null value in column violates not-null constraint' } };
          const row = defaults(p); T(table).push(row); made.push(row);
          log.writes.push({ table, op: 'insert', row });
        }
        out = made;
        log.calls.push({ table, op: 'insert', n: made.length });
      } else if (st.op === 'update') {
        hooks.updates++;
        if (hooks.failIf) { const m = hooks.failIf(table, hooks.updates); if (m) return { data: null, error: { code: 'XX000', message: m } }; }
        if (hooks.beforeUpdate) hooks.beforeUpdate(table, st);
        if (hooks.failNext && hooks.failNext.table === table) { const f = hooks.failNext; hooks.failNext = null; return { data: null, error: { code: 'XX000', message: f.message || 'database exploded' } }; }
        out = rows(); out.forEach(r => Object.assign(r, st.payload));
        log.calls.push({ table, op: 'update', n: out.length });
        log.writes.push({ table, op: 'update', patch: st.payload, ids: out.map(r => r.id) });
      } else if (st.op === 'delete') {
        out = rows(); tables[table] = T(table).filter(r => !out.includes(r));
      } else {
        out = rows();
        if (st.order) out = out.slice().sort((a, b) => (a[st.order[0]] > b[st.order[0]] ? 1 : -1) * st.order[1]);
        if (st.limit != null) out = out.slice(0, st.limit);
      }
      if (st.op !== 'select' && !st.returning) return { data: null, error: null };
      const shaped = out.map(r => project(table, r, st.cols));
      if (st.single) {
        if (shaped.length === 1) return { data: shaped[0], error: null };
        if (shaped.length === 0) return st.maybe ? { data: null, error: null } : { data: null, error: { code: 'PGRST116', message: 'no rows' } };
        return { data: null, error: { code: 'PGRST116', message: 'multiple rows' } };
      }
      return { data: shaped, error: null };
    }
    return api;
  }
  const supabase = {
    from,
    async rpc(name, args) {
      if (name === 'next_id') { seq[args.p_prefix] = (seq[args.p_prefix] || 0) + 1; return { data: `${args.p_prefix}-${String(seq[args.p_prefix]).padStart(5, '0')}`, error: null }; }
      return { data: null, error: { message: 'unknown rpc ' + name } };
    },
  };
  return { supabase, tables, T, log, seq, hooks };
}

// A fake app that records registrations IN ORDER, like Express would match them.
export function mountRecruiting(db, opts) {
  const routes = [];
  const app = new Proxy({}, { get: (_, m) => (path, ...fns) => { routes.push({ method: m.toUpperCase(), path, handler: fns[fns.length - 1] }); } });
  const hasRole = (req, ...roles) => {
    const u = req.user; if (!u) return false;
    if (Array.isArray(u.roles) && u.roles.length) return roles.some(r => u.roles.includes(r));
    return roles.includes(u.role);
  };
  const deps = Object.assign({
    supabase: db.supabase, auth: (_r, _s, n) => n(), hasRole, today: () => '2026-09-29',
    orgIdFor: (req) => (req && req.user && req.user.org_id) || DEFAULT_ORG,
  }, opts || {});
  require(ROOT + '/bd_recruiter_routes.js')(app, deps);
  return routes;
}

// Call a registered handler the way Express would: first route (in registration
// order) whose method and pattern match.
export function makeCaller(routes) {
  function match(pattern, path) {
    const pp = pattern.split('/'), xs = path.split('/');
    if (pp.length !== xs.length) return null;
    const params = {};
    for (let i = 0; i < pp.length; i++) {
      if (pp[i].startsWith(':')) params[pp[i].slice(1)] = decodeURIComponent(xs[i]);
      else if (pp[i] !== xs[i]) return null;
    }
    return params;
  }
  return async function call(method, url, { body, user, query } = {}) {
    const [path, qs] = url.split('?');
    const q = Object.assign({}, query || {});
    if (qs) qs.split('&').forEach(kv => { const [k, v] = kv.split('='); q[k] = decodeURIComponent(v || ''); });
    for (const r of routes) {
      if (r.method !== method) continue;
      const params = match(r.path, path);
      if (!params) continue;
      let status = 200, out;
      const res = { status(s) { status = s; return res; }, json(j) { out = j; return res; } };
      const req = { body: body || {}, query: q, params, user, orgId: user && user.org_id };
      await r.handler(req, res);
      return { status, body: out, route: r.method + ' ' + r.path };
    }
    return { status: 404, body: null, route: null };
  };
}

export function person(role, org, name) {
  return { id: uid(), role, roles: [role], org_id: org || ORG_A, name: name || role };
}

export const results = [];
export function step(name, ok, detail = '') {
  results.push(!!ok);
  console.log((ok ? '[PASS] ' : '[FAIL] ') + name + (detail ? ' — ' + detail : ''));
}
export function summary() {
  const failed = results.filter(x => !x).length;
  console.log(`\nSUMMARY: ${results.length - failed}/${results.length} passed`);
  return failed;
}
