'use strict';
// Check every column routes/apply.js names against the migration-derived map.
const { cols } = require('./column-map.js');
const chk = (table, names, label) => {
  const have = cols[table];
  const missing = names.filter(n => !have.has(n));
  console.log(`${missing.length ? 'MISSING' : 'ok     '}  ${label} on ${table}: ${names.length} named` + (missing.length ? `  -> NOT IN MIGRATIONS: ${missing.join(', ')}` : ''));
};

// 1. loadJob select — as it stands today, copied from routes/apply.js
const sel = ('id,org_id,job_code,job_title,city,state,country,remote,job_type,' +
  'job_description,posting_description,client,end_client,client_manager,' +
  'primary_skills,secondary_skills,exp_min,exp_max,' +
  'pay_cur,pay_min,pay_max,status,apply_enabled,apply_token,owner_id,created_by').split(',');
chk('job_orders', sel, 'loadJob select (CURRENT)');
chk('job_orders', sel.map(c => c === 'owner_id' ? 'bd_manager_id' : c), 'loadJob select (with bd_manager_id)');

// 2. the filter + the counter update
chk('job_orders', ['apply_token'], '.eq(apply_token)');
chk('job_orders', ['apply_count'], '.update({apply_count})');

// 3. the sourcing_candidates insert row
const row = ['org_id','provider','external_id','full_name','email','phone','location','current_title',
  'current_employer','skills','experience_years','resume_url','status','dup_candidate_id','created_by','raw'];
chk('sourcing_candidates', row, 'insert row');

// 4. the duplicate lookup
chk('candidates', ['id','org_id','deleted_at','email'], 'dup lookup select/eq/is/ilike');

// 5. fields job.* the rest of the file READS (not selected => always undefined)
const read = ['id','org_id','job_code','job_title','client','end_client','city','state','remote','job_type',
  'exp_min','exp_max','primary_skills','posting_description','job_description','apply_enabled','status',
  'apply_count','created_by','bd_manager_id'];
chk('job_orders', read, 'job.* fields read by handlers');
