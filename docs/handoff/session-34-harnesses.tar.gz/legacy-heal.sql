-- ============================================================================
-- R-075 / D-0057 — put everyone who was only "tagged" onto their job.
--
-- WHY. Before Session 31, adding a person to a job wrote only a
-- candidate_pipeline row (status 'Tagged'). "On a job" now means a submissions
-- row at Sourced (the pipeline row keeps the sourcing details and has no state of
-- its own). On the live database 15 pipeline rows were written before that change,
-- all 'Tagged', none linked to a submission, and `submissions` is empty. This gives
-- each of them the submission they should have had, and retires the word "Tagged".
--
-- SAFE TO RE-RUN: it only ever touches live pipeline rows with no submission, and
-- after one run there are none.  NOT RUN — it writes to live data, so it waits for
-- the owner's go-ahead.
-- ============================================================================

-- ── PREVIEW (read-only — run this on its own first) ─────────────────────────
-- Expect 15 rows on the live data: all 'Tagged', submission_id empty.
SELECT cp.pipeline_code, cp.candidate_id, cp.job_order_id, cp.pipeline_status,
       cp.tagged_at, cp.tagged_by, cp.org_id
  FROM candidate_pipeline cp
 WHERE cp.deleted_at IS NULL AND cp.submission_id IS NULL
 ORDER BY cp.tagged_at, cp.id;

-- ── THE FIX (one transaction: all of it or none of it) ──────────────────────
BEGIN;

-- 1. A live submission already exists for that person on that job (added since
--    Session 31, or by another path): link the two rows, create nothing.
UPDATE candidate_pipeline cp
   SET submission_id = s.id, pipeline_status = 'Sourced', updated_at = now()
  FROM submissions s
 WHERE cp.deleted_at IS NULL AND cp.submission_id IS NULL
   AND s.deleted_at IS NULL
   AND s.candidate_id = cp.candidate_id
   AND s.job_order_id = cp.job_order_id
   AND s.org_id = cp.org_id;

UPDATE submissions s
   SET pipeline_id = cp.id
  FROM candidate_pipeline cp
 WHERE cp.deleted_at IS NULL AND cp.submission_id = s.id
   AND s.deleted_at IS NULL AND s.pipeline_id IS NULL;

-- 2. Everybody else: a submission at Sourced, dated when they were tagged (so
--    "time in stage" measures from the real add, not from today), owned by the
--    person who tagged them, filed under the SAME company as the row it comes
--    from (org_id is NOT NULL with a column default of the default company —
--    never rely on that default here). No submitted_at: adding is not
--    submitting (D-0029). Codes come from next_id('SB'), in tag order.
DO $$
DECLARE
  r      RECORD;
  new_id uuid;
BEGIN
  FOR r IN
    SELECT cp.*
      FROM candidate_pipeline cp
     WHERE cp.deleted_at IS NULL AND cp.submission_id IS NULL
     ORDER BY cp.tagged_at, cp.id
  LOOP
    INSERT INTO submissions (
      org_id, submission_code, candidate_id, job_order_id,
      recruiter_id, submitted_by,
      stage, stage_updated_at, created_at, revision_status,
      bill_rate, pay_rate, employer_name, availability, notice_period, notes,
      pipeline_id)
    VALUES (
      r.org_id, next_id('SB'), r.candidate_id, r.job_order_id,
      r.tagged_by, r.tagged_by,
      'Sourced', r.tagged_at, r.tagged_at, 'N/A',
      r.bill_rate, r.pay_rate, r.employer_name, r.availability, r.notice_period, r.notes,
      r.id)
    RETURNING id INTO new_id;

    UPDATE candidate_pipeline
       SET submission_id = new_id, pipeline_status = 'Sourced', updated_at = now()
     WHERE id = r.id;
  END LOOP;
END $$;

-- 3. The column is inert now (a person's state is their submission's stage).
--    Leave no live row still saying Tagged / Moved to Submission / …
UPDATE candidate_pipeline
   SET pipeline_status = 'Sourced'
 WHERE deleted_at IS NULL AND pipeline_status <> 'Sourced';

COMMIT;

-- ── CHECK (run after; on the live data expect 0, 0, 0, 0 and 15) ────────────
SELECT count(*) AS still_unlinked
  FROM candidate_pipeline WHERE deleted_at IS NULL AND submission_id IS NULL;
SELECT count(*) AS still_saying_a_retired_word
  FROM candidate_pipeline WHERE deleted_at IS NULL AND pipeline_status <> 'Sourced';
SELECT count(*) AS links_that_do_not_agree
  FROM candidate_pipeline cp JOIN submissions s ON s.id = cp.submission_id
 WHERE s.pipeline_id IS DISTINCT FROM cp.id;
SELECT count(*) AS sourced_rows_wrongly_stamped_as_submitted
  FROM submissions WHERE stage = 'Sourced' AND submitted_at IS NOT NULL;
SELECT count(*) AS people_now_on_a_job
  FROM submissions WHERE deleted_at IS NULL;
