// R-077 — change the stage of several candidates at once. One function judges a
// move, whether it is one row or two hundred; the group move reports what it did
// and never lets one bad row spoil the rest.
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
import { makeDb, mountRecruiting, makeCaller, person, step, summary, uid, ORG_A, ORG_B } from './harness.mjs';

const ROOT = process.env.GUILD_ROOT || '/home/user/PACE_All-in-one-recruting-tool';
const subStages = require(ROOT + '/services/submission-stages.js');
const { EVENTS, on } = require(ROOT + '/events.js');

// ── A. THE RULES, CALLABLE ─────────────────────────────────────────────────
{
  const R = (o) => subStages.moveRefusal(Object.assign({ isBDM: false, isRecruiter: true, assigned: true, from: 'Sourced', to: 'Screening', reason: '', details: null }, o));
  const rule = (o) => (R(o) || {}).rule || null;
  const ruleOf = (x) => (x || {}).rule || null;           // null-safe: a removed rule must FAIL by name, not crash the run
  step('a recruiter moves Sourced -> Screening', R({}) === null);
  step('a recruiter may not move INTO Submitted to Client', rule({ to: 'Submitted to Client' }) === 'recruiter_target' && (R({ to: 'Submitted to Client' }) || {}).status === 403);
  step('…nor Offer, Placement, Not Accepted, On Hold, Interview…', ['Offer', 'Placement', 'Not Accepted', 'On Hold', 'Interview Scheduled', 'Joining'].every(t => rule({ to: t, reason: 'x' }) === 'recruiter_target'));
  step('a recruiter may not move somebody who is already with BD', rule({ from: 'Submitted to Client', to: 'Screening' }) === 'with_bd');
  step('…nor from Offer / Placement / Not Accepted', ['Offer', 'Placement', 'Not Accepted'].every(f => rule({ from: f, to: 'Screening' }) === 'with_bd'));
  step('a recruiter submitting to BDM needs a comment', rule({ to: 'Submitted to BDM' }) === 'details' && (R({ to: 'Submitted to BDM' }) || {}).status === 400);
  step('…and is fine with one', R({ to: 'Submitted to BDM', details: { comment: 'strong fit' } }) === null);
  step('…a whitespace comment is no comment', rule({ to: 'Submitted to BDM', details: { comment: '   ' } }) === 'details');
  step('a recruiter not assigned to the job is refused', rule({ assigned: false }) === 'not_assigned');
  step('precedence is the old single-move order: unassigned is reported before the stage', rule({ assigned: false, to: 'Placement' }) === 'not_assigned');
  step('BD (any BD role) may move anywhere', ['Submitted to Client', 'Offer', 'Placement', 'On Hold'].every(t => subStages.moveRefusal({ isBDM: true, isRecruiter: false, from: 'Sourced', to: t, reason: 'x' }) === null));
  step('BD moving to Not Accepted needs a reason', ruleOf(subStages.moveRefusal({ isBDM: true, from: 'Offer', to: 'Not Accepted', reason: '' })) === 'reason');
  step('…and a recruiter\'s Not Accepted is refused for the stage before the reason', rule({ to: 'Not Accepted', reason: '' }) === 'recruiter_target');
  step('a role that is neither BD nor recruiter may not move anybody', ruleOf(subStages.moveRefusal({ isBDM: false, isRecruiter: false, from: 'Sourced', to: 'Screening' })) === 'role');
  step('BD who is also a recruiter is judged as BD (not recruiter-scoped)', subStages.moveRefusal({ isBDM: true, isRecruiter: true, from: 'Offer', to: 'Placement' }) === null);
  step('group move: already at the stage is refused, single move never refuses it', ruleOf(subStages.moveRefusal({ isBDM: true, from: 'Screening', to: 'Screening', bulk: true })) === 'no_change' && subStages.moveRefusal({ isBDM: true, from: 'Screening', to: 'Screening', bulk: false }) === null);
  step('…but changing only the sub-stage is a change', subStages.moveRefusal({ isBDM: true, from: 'Screening', to: 'Screening', fromSubStage: 'Scheduled', subStage: 'Passed', bulk: true }) === null);
  step('group move: recruiter to BDM is refused up front with the one-at-a-time sentence', /one at a time/.test((subStages.moveRefusal({ isBDM: false, isRecruiter: true, assigned: true, from: 'Screening', to: 'Submitted to BDM', bulk: true }) || {}).message || ''));
  const reqOnly = subStages.requestRefusal({ isBDM: false, isRecruiter: true, to: 'Submitted to Client' });
  step('requestRefusal answers the request-level rules only', reqOnly && reqOnly.rule === 'recruiter_target' && subStages.requestRefusal({ isBDM: false, isRecruiter: true, to: 'Screening' }) === null);
  step('the recruiter stages are exactly Sourced, Screening, Submitted to BDM (law 3 as data)', subStages.RECRUITER_STAGES.join('|') === 'Sourced|Screening|Submitted to BDM');
}

// ── world ──────────────────────────────────────────────────────────────────
const db = makeDb();
const routes = mountRecruiting(db);
const call = makeCaller(routes);
const bd = person('bd', ORG_A, 'Bea BD');
const recruiter = person('recruiter', ORG_A, 'Rex Recruiter');
const ra = person('ra', ORG_A, 'Ray RA');
const bdB = person('bd', ORG_B, 'Bob BD (other company)');
db.T('users').push(...[bd, recruiter, ra, bdB].map(u => ({ id: u.id, org_id: u.org_id, name: u.name, deleted_at: null })));
const J1 = uid(), J2 = uid(), JB = uid(), JDEL = uid();
db.T('job_orders').push(
  { id: J1, org_id: ORG_A, job_title: 'HVAC Tech', job_code: 'JO-1', client: 'Acme', status: 'Open', deleted_at: null },
  { id: J2, org_id: ORG_A, job_title: 'Estimator', job_code: 'JO-2', client: 'Acme', status: 'Open', deleted_at: null },
  { id: JDEL, org_id: ORG_A, job_title: 'Deleted job', job_code: 'JO-X', client: 'Acme', status: 'Closed', deleted_at: '2026-09-01T00:00:00Z' },
  { id: JB, org_id: ORG_B, job_title: 'Other co', job_code: 'JO-B', status: 'Open', deleted_at: null });
db.T('recruiter_assignments').push({ id: uid(), org_id: ORG_A, recruiter_id: recruiter.id, job_order_id: J1 });
let n = 0;
const mkCand = (org) => { const c = { id: uid(), org_id: org || ORG_A, full_name: 'Person ' + (++n), email: `p${n}@x.com`, deleted_at: null }; db.T('candidates').push(c); return c; };
const mkSub = (job, stage, extra) => {
  const c = mkCand((extra && extra.org_id) || ORG_A);
  const s = Object.assign({ id: uid(), org_id: ORG_A, candidate_id: c.id, job_order_id: job, recruiter_id: recruiter.id, stage, sub_stage: null, stage_updated_at: '2026-09-01T00:00:00Z', created_at: '2026-09-01T00:00:00Z', deleted_at: null }, extra || {});
  db.T('submissions').push(s); return s;
};
const get = (id) => db.T('submissions').find(s => s.id === id);
const acts = (id) => db.T('submission_activity').filter(a => a.submission_id === id);

const seen = [];
on(EVENTS.SUBMISSION_ADVANCED, (e) => seen.push(e.payload));
const settle = () => new Promise(r => setTimeout(r, 30));

// ── B. THE GROUP MOVE, AS BD ───────────────────────────────────────────────
const S = [1, 2, 3, 4, 5].map(() => mkSub(J1, 'Sourced'));
const SDEL = mkSub(J1, 'Sourced', { deleted_at: '2026-09-02T00:00:00Z' });
const SF = mkSub(JB, 'Sourced', { org_id: ORG_B, recruiter_id: bdB.id });
{
  const ids = [...S.map(s => s.id), SDEL.id, SF.id, 'not-a-uuid', uid(), S[0].id];
  const r = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids, stage: 'Screening', sub_stage: 'In Progress', note: 'phone screen booked' } });
  await settle();
  step('bulk-stage answers 200 with moved / refused / stage', r.status === 200 && Array.isArray(r.body.moved) && Array.isArray(r.body.refused) && r.body.stage === 'Screening', String(r.status) + JSON.stringify(r.body).slice(0, 200));
  step('…the five real rows moved, in the order sent, once each', JSON.stringify(r.body.moved) === JSON.stringify(S.map(s => s.id)));
  step('…each is now at Screening with the sub-stage, and stage_updated_at moved', S.every(s => get(s.id).stage === 'Screening' && get(s.id).sub_stage === 'In Progress' && get(s.id).stage_updated_at !== '2026-09-01T00:00:00Z'));
  step('…a deleted, a foreign, a malformed and an invented id are all REFUSED', r.body.refused.length === 4);
  const sentences = new Set(r.body.refused.map(x => x.reason));
  step('…with the SAME plain sentence, so an id cannot be used to probe what exists', sentences.size === 1 && /could not be found/.test([...sentences][0]), [...sentences].join(' | '));
  step('…the foreign company\'s row was NOT touched', get(SF.id).stage === 'Sourced');
  step('…the deleted row was NOT touched', get(SDEL.id).stage === 'Sourced' && get(SDEL.id).deleted_at);
  step('…one history row per moved person, old -> new, with the note and sub-stage, org-stamped', S.every(s => { const a = acts(s.id); return a.length === 1 && a[0].old_stage === 'Sourced' && a[0].new_stage === 'Screening' && a[0].action === 'stage_change' && a[0].note === '[In Progress] phone screen booked' && a[0].org_id === ORG_A; }));
  step('…and they were written as ONE insert, the moves as ONE update', db.log.calls.filter(c => c.table === 'submission_activity' && c.op === 'insert').length === 1 && db.log.calls.filter(c => c.table === 'submissions' && c.op === 'update').length === 1, JSON.stringify(db.log.calls.filter(c => c.op !== 'select').slice(-4)));
  step('…one SUBMISSION_ADVANCED event per moved person', seen.length === 5 && seen.every(e => e.fromStage === 'Sourced' && e.toStage === 'Screening' && e.actorUserId === bd.id), String(seen.length));
  step('…moved + refused accounts for every distinct id sent', r.body.moved.length + r.body.refused.length === new Set(ids).size);
}

// ── again: nothing to change ───────────────────────────────────────────────
{
  const before = db.log.calls.length, histBefore = db.T('submission_activity').length;
  const r = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: S.map(s => s.id), stage: 'Screening', sub_stage: 'In Progress' } });
  step('moving people who are already there moves nobody, refuses each with a plain sentence', r.status === 200 && r.body.moved.length === 0 && r.body.refused.length === 5 && r.body.refused.every(x => /Already at "Screening"/.test(x.reason)), JSON.stringify(r.body).slice(0, 160));
  step('…and writes no history and no update', db.T('submission_activity').length === histBefore && db.log.calls.length === before);
}

// ── whole-request refusals ─────────────────────────────────────────────────
{
  const many = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: Array.from({ length: 201 }, () => uid()), stage: 'Screening' } });
  step('201 people is refused (cap 200)', many.status === 400 && /200/.test(many.body.error));
  const exact = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: Array.from({ length: 200 }, () => uid()), stage: 'Screening' } });
  step('exactly 200 is accepted (they are simply not found)', exact.status === 200 && exact.body.refused.length === 200);
  const none = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: [], stage: 'Screening' } });
  step('no ids is refused', none.status === 400);
  const notarr = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: 'abc', stage: 'Screening' } });
  step('ids that are not a list are refused', notarr.status === 400);
  const badstage = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: [S[0].id], stage: 'Tagged' } });
  step('"Tagged" is not a stage inside a job — refused with the allowed list', badstage.status === 400 && /Allowed: Sourced, Screening/.test(badstage.body.error) && !/Tagged,/.test(badstage.body.error.split('Allowed:')[1]), badstage.body.error);
  const legacyName = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: [S[0].id], stage: 'Confirmation' } });
  step('a legacy stage name is normalised (Confirmation -> Joining)', legacyName.status === 200 && get(S[0].id).stage === 'Joining' && legacyName.body.stage === 'Joining');
  const ra1 = await call('POST', '/submissions/bulk-stage', { user: ra, body: { ids: [S[1].id], stage: 'Screening' } });
  step('a research analyst may not move anybody (403)', ra1.status === 403 && get(S[1].id).stage === 'Screening');
  const noreason = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: [S[1].id, S[2].id], stage: 'Not Accepted' } });
  step('Not Accepted with no reason refuses the whole request (400) and moves nobody', noreason.status === 400 && /reason/i.test(noreason.body.error) && get(S[1].id).stage === 'Screening');
  const reason = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: [S[1].id, S[2].id], stage: 'Not Accepted', rejection_reason: 'Accepted elsewhere' } });
  step('…with a reason it moves them and stores the reason on each', reason.status === 200 && reason.body.moved.length === 2 && [S[1], S[2]].every(s => get(s.id).stage === 'Not Accepted' && get(s.id).rejection_reason === 'Accepted elsewhere'));
  const rejected = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: [S[3].id], stage: 'Rejected' } });
  step('the legacy name "Rejected" is Not Accepted, so it needs the reason too', rejected.status === 400);
}

// ── approval to the client records who approved ────────────────────────────
{
  const B = [mkSub(J1, 'Submitted to BDM'), mkSub(J1, 'Submitted to BDM')];
  const r = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: B.map(s => s.id), stage: 'Submitted to Client' } });
  step('BD approves several through to the client at once', r.status === 200 && r.body.moved.length === 2 && B.every(s => get(s.id).stage === 'Submitted to Client'));
  step('…each records who approved and when, and the history says bdm_approved', B.every(s => get(s.id).bdm_approved_by === bd.id && get(s.id).bdm_approved_at && acts(s.id).some(a => a.action === 'bdm_approved')));
}

// ── reminders ──────────────────────────────────────────────────────────────
{
  const R = [mkSub(J1, 'Sourced'), mkSub(J1, 'Sourced')];
  const before = db.T('reminders').length;
  const r = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: R.map(s => s.id), stage: 'Screening', reminder_date: '2026-10-05', reminder_note: 'call about the screen' } });
  const made = db.T('reminders').slice(before);
  step('a reminder is set for each person who moved — and only them', r.body.moved.length === 2 && made.length === 2 && made.every(m => m.user_id === bd.id && m.return_date === '2026-10-05' && m.note === 'call about the screen' && m.status === 'pending' && m.org_id === ORG_A));
  const again = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: R.map(s => s.id), stage: 'Screening', reminder_date: '2026-10-05' } });
  step('…people who did not move get no reminder', again.body.moved.length === 0 && db.T('reminders').length === before + 2);
  // a MIXED batch: one moves, one is already there, one is refused for being another company's
  const mixMove = mkSub(J1, 'Sourced'), mixStay = mkSub(J1, 'Screening');
  const mixBefore = db.T('reminders').length, mixHist = db.T('submission_activity').length;
  const mix = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: [mixMove.id, mixStay.id, SF.id], stage: 'Screening', reminder_date: '2026-10-06' } });
  step('in a mixed batch the reminder and the history go to exactly the person who moved', mix.body.moved.length === 1 && mix.body.refused.length === 2 && db.T('reminders').length === mixBefore + 1 && db.T('reminders')[db.T('reminders').length - 1].contact_name === db.T('candidates').find(c => c.id === mixMove.candidate_id).full_name && db.T('submission_activity').length === mixHist + 1);
}

// ── C. THE RECRUITER GATE, PER ROW ─────────────────────────────────────────
{
  const mine = mkSub(J1, 'Sourced'), notMine = mkSub(J2, 'Sourced'), withBd = mkSub(J1, 'Submitted to Client'), also = mkSub(J1, 'Screening');
  const r = await call('POST', '/submissions/bulk-stage', { user: recruiter, body: { ids: [mine.id, notMine.id, withBd.id, also.id], stage: 'Screening', note: 'x' } });
  step('a recruiter\'s group move succeeds for the rows they may touch…', r.status === 200 && get(mine.id).stage === 'Screening' && r.body.moved.includes(mine.id));
  const why = Object.fromEntries(r.body.refused.map(x => [x.id, x.reason]));
  step('…and refuses the unassigned job\'s row: "Not assigned to this job order."', why[notMine.id] === 'Not assigned to this job order.' && get(notMine.id).stage === 'Sourced', why[notMine.id]);
  step('…and the row that is with BD: "with the BD team now"', /with the BD team now/.test(why[withBd.id] || '') && get(withBd.id).stage === 'Submitted to Client', why[withBd.id]);
  step('…and the one already there', /Already at "Screening"/.test(why[also.id] || ''));

  const toClient = await call('POST', '/submissions/bulk-stage', { user: recruiter, body: { ids: [mine.id], stage: 'Submitted to Client' } });
  step('a recruiter cannot group-move anybody to Submitted to Client (403 for the request)', toClient.status === 403 && /up to "Submitted to BDM"/.test(toClient.body.error) && get(mine.id).stage === 'Screening');
  const toOffer = await call('POST', '/submissions/bulk-stage', { user: recruiter, body: { ids: [mine.id], stage: 'Offer' } });
  step('…nor to Offer', toOffer.status === 403 && get(mine.id).stage === 'Screening');
  const toBdm = await call('POST', '/submissions/bulk-stage', { user: recruiter, body: { ids: [mine.id], stage: 'Submitted to BDM' } });
  step('a recruiter cannot group-submit to the BD Manager — each needs its own details (400)', toBdm.status === 400 && /one at a time/.test(toBdm.body.error) && get(mine.id).stage === 'Screening');
  const spoof = await call('POST', '/submissions/bulk-stage', { user: recruiter, body: { ids: [mine.id], stage: 'Submitted to BDM', submission_details: { comment: 'trust me' } } });
  step('…and cannot get round it by sending details with the group move', spoof.status === 400 && get(mine.id).stage === 'Screening');
  const allRefused = await call('POST', '/submissions/bulk-stage', { user: recruiter, body: { ids: [notMine.id, withBd.id], stage: 'Sourced' } });
  step('a group where every row is refused is still a 200 with the reasons', allRefused.status === 200 && allRefused.body.moved.length === 0 && allRefused.body.refused.length === 2);
}

// ── D. THE SINGLE MOVE IS THE SAME FUNCTION ────────────────────────────────
{
  const s1 = mkSub(J1, 'Sourced');
  const ok = await call('PATCH', `/submissions/${s1.id}/stage`, { user: bd, body: { stage: 'Screening', sub_stage: 'Scheduled', note: 'n' } });
  await settle();
  step('PATCH /submissions/:id/stage still answers with the whole updated submission', ok.status === 200 && ok.body.id === s1.id && ok.body.stage === 'Screening' && ok.body.candidate && ok.body.candidate.full_name, JSON.stringify(ok.body).slice(0, 120));
  step('…and writes the history and fires the event', acts(s1.id).length === 1 && seen.some(e => e.submissionId === s1.id));

  const unk = await call('PATCH', `/submissions/${uid()}/stage`, { user: bd, body: { stage: 'Screening' } });
  const foreign = await call('PATCH', `/submissions/${SF.id}/stage`, { user: bd, body: { stage: 'Screening' } });
  const deleted = await call('PATCH', `/submissions/${SDEL.id}/stage`, { user: bd, body: { stage: 'Screening' } });
  step('an unknown, a foreign and a deleted id all read 404 "Submission not found"', [unk, foreign, deleted].every(x => x.status === 404 && x.body.error === 'Submission not found'));
  const bad = await call('PATCH', `/submissions/${s1.id}/stage`, { user: bd, body: { stage: 'Nope' } });
  step('an unknown stage is 400 with the allowed list', bad.status === 400 && /Invalid stage/.test(bad.body.error));

  // parity: the SAME sentence and status from the single move as from the group move
  const mine = mkSub(J1, 'Sourced'), notMine = mkSub(J2, 'Sourced'), withBd = mkSub(J1, 'Offer');
  const parity = [
    ['not assigned', notMine, 'Screening', 403, 'Not assigned to this job order.'],
    ['with BD', withBd, 'Screening', 403, 'This candidate is with the BD team now — only a BD Manager can change this stage.'],
    ['target', mine, 'Placement', 403, 'Recruiters can move candidates up to "Submitted to BDM" — the BD team owns the stages after that.'],
  ];
  for (const [label, sub, stage, code, sentence] of parity) {
    const one = await call('PATCH', `/submissions/${sub.id}/stage`, { user: recruiter, body: { stage } });
    step(`single move refuses "${label}" with ${code} and the exact sentence`, one.status === code && one.body.error === sentence, one.status + ' ' + (one.body && one.body.error));
  }
  const grp = await call('POST', '/submissions/bulk-stage', { user: recruiter, body: { ids: [notMine.id, withBd.id], stage: 'Screening' } });
  const gwhy = Object.fromEntries(grp.body.refused.map(x => [x.id, x.reason]));
  step('…and the group move uses the same words for the same two per-row refusals', gwhy[notMine.id] === parity[0][4] && gwhy[withBd.id] === parity[1][4]);
  const gtarget = await call('POST', '/submissions/bulk-stage', { user: recruiter, body: { ids: [mine.id], stage: 'Placement' } });
  step('…and for the request-level one', gtarget.status === 403 && gtarget.body.error === parity[2][4]);

  const noDetails = await call('PATCH', `/submissions/${mine.id}/stage`, { user: recruiter, body: { stage: 'Submitted to BDM' } });
  step('single: a recruiter submitting to BDM without a comment is 400', noDetails.status === 400 && /comment/.test(noDetails.body.error));
  const withDetails = await call('PATCH', `/submissions/${mine.id}/stage`, { user: recruiter, body: { stage: 'Submitted to BDM', submission_details: { comment: 'strong fit', first_name: 'P' }, note: 'n' } });
  step('single: with a comment it moves and stores the hand-off details', withDetails.status === 200 && get(mine.id).stage === 'Submitted to BDM' && get(mine.id).submission_details.comment === 'strong fit');
  const nr = await call('PATCH', `/submissions/${withBd.id}/stage`, { user: bd, body: { stage: 'Not Accepted' } });
  step('single: Not Accepted without a reason is 400 "Please add the reason."', nr.status === 400 && nr.body.error === 'Please add the reason.');
  const raOne = await call('PATCH', `/submissions/${mine.id}/stage`, { user: ra, body: { stage: 'Offer' } });
  step('single: a research analyst can no longer move a submission to Offer (was allowed; law 3 says BD owns later stages)', raOne.status === 403 && get(mine.id).stage === 'Submitted to BDM', raOne.status + ' ' + (raOne.body && raOne.body.error));
}

// ── E. WHEN THE DATABASE MISBEHAVES ────────────────────────────────────────
{
  const V = [mkSub(J1, 'Sourced'), mkSub(J1, 'Sourced'), mkSub(J1, 'Sourced')];
  // one row is removed by somebody else between the read and the write
  db.hooks.beforeUpdate = (table) => { if (table === 'submissions') { get(V[1].id).deleted_at = '2026-09-29T00:00:00Z'; db.hooks.beforeUpdate = null; } };
  const remBeforeV = db.T('reminders').length;
  const r = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: V.map(s => s.id), stage: 'Screening', reminder_date: '2026-10-07' } });
  step('a row removed mid-move is reported, never counted as moved', r.status === 200 && r.body.moved.length === 2 && r.body.refused.length === 1 && r.body.refused[0].id === V[1].id && /removed from the job/.test(r.body.refused[0].reason), JSON.stringify(r.body));
  step('…and it gets no history row', acts(V[1].id).length === 0 && acts(V[0].id).length === 1);
  step('…and no reminder: a reminder is set only for a person who actually moved', db.T('reminders').length === remBeforeV + 2 && !db.T('reminders').slice(remBeforeV).some(m => m.contact_name === db.T('candidates').find(c => c.id === V[1].candidate_id).full_name));

  const W = [mkSub(J1, 'Sourced'), mkSub(J1, 'Sourced')];
  db.hooks.failNext = { table: 'submissions', message: 'connection reset' };
  const histBefore = db.T('submission_activity').length;
  const f = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: W.map(s => s.id), stage: 'Screening' } });
  step('a failed write does NOT 500 the group: every row is refused with a plain retry sentence', f.status === 200 && f.body.moved.length === 0 && f.body.refused.length === 2 && /nothing was moved/.test(f.body.refused[0].reason), JSON.stringify(f.body).slice(0, 160));
  step('…and nothing moved and no history was written', W.every(s => get(s.id).stage === 'Sourced') && db.T('submission_activity').length === histBefore);
  db.hooks.failNext = { table: 'submissions', message: 'connection reset' };
  const fs1 = await call('PATCH', `/submissions/${W[0].id}/stage`, { user: bd, body: { stage: 'Screening' } });
  step('the single move still answers 500 with the database message, as it always did', fs1.status === 500 && /connection reset/.test(fs1.body.error), fs1.status + ' ' + JSON.stringify(fs1.body));
}

// ── E2. A LONG BATCH IS WRITTEN IN CHUNKS, AND A BAD CHUNK SPOILS NOTHING ──
{
  const L = Array.from({ length: 150 }, () => mkSub(J1, 'Sourced'));
  const startUpdates = db.hooks.updates;
  let seenSubUpdates = 0;
  db.hooks.failIf = (table) => { if (table !== 'submissions') return null; seenSubUpdates++; return seenSubUpdates === 2 ? 'gateway timeout' : null; };
  const r = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: L.map(s => s.id), stage: 'Screening' } });
  db.hooks.failIf = null;
  const okRows = L.filter(s => get(s.id).stage === 'Screening'), badRows = L.filter(s => get(s.id).stage === 'Sourced');
  step('150 people are written in two chunks (100 + 50)', seenSubUpdates === 2 && db.hooks.updates - startUpdates === 2, String(seenSubUpdates));
  step('the second chunk failed: its 50 are refused with the retry sentence, the first 100 are moved', r.status === 200 && r.body.moved.length === 100 && r.body.refused.length === 50 && okRows.length === 100 && badRows.length === 50, JSON.stringify([r.body.moved.length, r.body.refused.length, okRows.length]));
  step('…each refused once, with the write-failed sentence (never also "removed")', r.body.refused.every(x => /nothing was moved/.test(x.reason)) && new Set(r.body.refused.map(x => x.id)).size === 50);
  step('…the moved 100 have history and the failed 50 have none', okRows.every(s => acts(s.id).length === 1) && badRows.every(s => acts(s.id).length === 0));
}

// ── F. WHICH JOBS IS EACH PERSON ON? (the Candidates page's "which job?") ──
{
  const c1 = mkCand(), c2 = mkCand(), cf = mkCand(ORG_B);
  const a = { id: uid(), org_id: ORG_A, candidate_id: c1.id, job_order_id: J1, stage: 'Sourced', recruiter_id: bd.id, deleted_at: null };
  const b = { id: uid(), org_id: ORG_A, candidate_id: c1.id, job_order_id: J2, stage: 'Confirmation', recruiter_id: bd.id, deleted_at: null };
  const d = { id: uid(), org_id: ORG_A, candidate_id: c2.id, job_order_id: J1, stage: 'Screening', recruiter_id: bd.id, deleted_at: null };
  const onDeletedJob = { id: uid(), org_id: ORG_A, candidate_id: c2.id, job_order_id: JDEL, stage: 'Sourced', recruiter_id: bd.id, deleted_at: null };
  const gone = { id: uid(), org_id: ORG_A, candidate_id: c2.id, job_order_id: J2, stage: 'Sourced', recruiter_id: bd.id, deleted_at: '2026-09-01T00:00:00Z' };
  const foreign = { id: uid(), org_id: ORG_B, candidate_id: cf.id, job_order_id: JB, stage: 'Sourced', recruiter_id: bdB.id, deleted_at: null };
  db.T('submissions').push(a, b, d, onDeletedJob, gone, foreign);
  const r = await call('GET', `/submissions?candidate_ids=${c1.id},${c2.id},${cf.id},not-a-uuid`, { user: bd });
  const ids = (r.body.submissions || []).map(s => s.id).sort();
  step('GET /submissions?candidate_ids returns each person\'s live submissions per job', r.status === 200 && JSON.stringify(ids) === JSON.stringify([a.id, b.id, d.id].sort()), JSON.stringify(ids.length));
  step('…with the job\'s code, title and client, and a NORMALISED stage', r.body.submissions.find(s => s.id === b.id).stage === 'Joining' && r.body.submissions.find(s => s.id === a.id).job.job_title === 'HVAC Tech' && r.body.submissions.find(s => s.id === a.id).job.client === 'Acme');
  step('…not another company\'s, not a deleted one, not one on a deleted job order', !ids.includes(foreign.id) && !ids.includes(gone.id) && !ids.includes(onDeletedJob.id));
  step('…and one malformed id in the list did not hide the good ones', ids.length === 3);
  step('…no contact details ride along', r.body.submissions.every(s => !('email' in s) && !('candidate' in s) && (!s.job || !('deleted_at' in s.job))));
  const none = await call('GET', '/submissions', { user: bd });
  const blank = await call('GET', '/submissions?candidate_ids=', { user: bd });
  step('asking about nobody returns NOTHING — never every submission (fail closed)', none.status === 200 && none.body.submissions.length === 0 && blank.body.submissions.length === 0);
  const big = await call('GET', '/submissions?candidate_ids=' + Array.from({ length: 201 }, () => uid()).join(','), { user: bd });
  step('more than 200 people is refused', big.status === 400);
  const raGet = await call('GET', `/submissions?candidate_ids=${c1.id}`, { user: ra });
  step('a research analyst may not read it (403)', raGet.status === 403);
  const chosen = r.body.submissions.filter(s => s.job_order_id === J1).map(s => s.id);
  const mv = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: chosen, stage: 'Screening' } });
  step('…and those ids feed the group move directly ("ask which job", then move)', mv.status === 200 && mv.body.moved.length === 1 && mv.body.refused.length === 1 && /Already at/.test(mv.body.refused[0].reason), JSON.stringify(mv.body));
}

// ── G. REGISTRATION ORDER ──────────────────────────────────────────────────
{
  const idx = (m, p) => routes.findIndex(r => r.method === m && r.path === p);
  step('POST /submissions/bulk-stage is registered above every /submissions/:id… route', idx('POST', '/submissions/bulk-stage') > -1
    && idx('POST', '/submissions/bulk-stage') < idx('PATCH', '/submissions/:id/stage')
    && idx('POST', '/submissions/bulk-stage') < idx('PATCH', '/submissions/:id')
    && idx('POST', '/submissions/bulk-stage') < idx('DELETE', '/submissions/:id'));
  step('GET /submissions is registered above the :id routes too', idx('GET', '/submissions') > -1 && idx('GET', '/submissions') < idx('PATCH', '/submissions/:id/stage'));
  step('POST /pipeline/bulk is registered above every /pipeline/:id… route', idx('POST', '/pipeline/bulk') > -1 && idx('POST', '/pipeline/bulk') < idx('PATCH', '/pipeline/:id') && idx('POST', '/pipeline/bulk') < idx('POST', '/pipeline/:id/promote') && idx('POST', '/pipeline/bulk') < idx('DELETE', '/pipeline/:id'));
  const hit = await call('POST', '/submissions/bulk-stage', { user: bd, body: { ids: [], stage: 'Screening' } });
  step('and the request really reaches the bulk handler (its own 400, not a :id handler)', hit.route === 'POST /submissions/bulk-stage' && hit.status === 400);
}

const failed = summary();
process.exit(failed ? 1 : 0);
