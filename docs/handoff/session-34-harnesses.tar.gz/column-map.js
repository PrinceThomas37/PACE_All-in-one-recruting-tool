'use strict';
// Scratch tool (NOT part of the repo): fold every migration into a per-table
// column set, so a select list can be checked against what the migrations
// actually create. Handles CREATE TABLE bodies, ALTER TABLE ADD/DROP/RENAME
// COLUMN (including comma-separated multi-clause ALTERs), and migration 022's
// DO-loop that adds org_id to a named array of tables.
const fs = require('fs');
const path = require('path');

const DIR = (require.main === module && process.argv[2]) || '/home/user/PACE_All-in-one-recruting-tool/migrations';
const files = fs.readdirSync(DIR).filter(f => f.endsWith('.sql')).sort();

const cols = {};            // table -> Set(column)
const born = {};            // table -> {col -> first migration}
const dropped = [];
const created = new Set();         // [table, col, file]
const add = (t, c, f) => {
  t = t.replace(/^public\./, '').replace(/"/g, '').toLowerCase();
  c = c.replace(/"/g, '').toLowerCase();
  (cols[t] = cols[t] || new Set()).add(c);
  born[t] = born[t] || {};
  if (!born[t][c]) born[t][c] = f;
};
const drop = (t, c, f) => {
  t = t.replace(/^public\./, '').replace(/"/g, '').toLowerCase();
  c = c.replace(/"/g, '').toLowerCase();
  if (cols[t]) cols[t].delete(c);
  dropped.push([t, c, f]);
};

// split on commas that are not inside parentheses
function splitTop(s) {
  const out = []; let depth = 0, cur = '';
  for (const ch of s) {
    if (ch === '(') depth++;
    if (ch === ')') depth--;
    if (ch === ',' && depth === 0) { out.push(cur); cur = ''; } else cur += ch;
  }
  if (cur.trim()) out.push(cur);
  return out;
}

const NOT_COLS = /^(primary|unique|foreign|constraint|check|like|exclude)\b/i;

for (const f of files) {
  let sql = fs.readFileSync(path.join(DIR, f), 'utf8');
  sql = sql.replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/--[^\n]*/g, ' ');

  // 022-style DO loop: ARRAY['a','b',...] followed by ADD COLUMN IF NOT EXISTS org_id
  if (/FOREACH\s+t\s+IN\s+ARRAY/i.test(sql) && /ADD COLUMN IF NOT EXISTS org_id/i.test(sql)) {
    const m = sql.match(/ARRAY\[([\s\S]*?)\]/);
    if (m) (m[1].match(/'([a-z_]+)'/gi) || []).forEach(q => add(q.replace(/'/g, ''), 'org_id', f));
  }

  // CREATE TABLE
  const re = /create\s+table\s+(?:if\s+not\s+exists\s+)?([\w."]+)\s*\(/gi;
  let m;
  while ((m = re.exec(sql))) {
    let i = re.lastIndex, depth = 1, body = '';
    while (i < sql.length && depth > 0) {
      const ch = sql[i++];
      if (ch === '(') depth++;
      if (ch === ')') { depth--; if (depth === 0) break; }
      body += ch;
    }
    for (const item of splitTop(body)) {
      const t = item.trim();
      if (!t || NOT_COLS.test(t)) continue;
      const mm = t.match(/^"?([a-z_][\w]*)"?\s+/i);
      if (mm) add(m[1], mm[1], f);
    }
    created.add(m[1].replace(/^public\./, '').replace(/"/g, '').toLowerCase());
  }

  // ALTER TABLE ... (each statement up to ;)
  const reA = /alter\s+table\s+(?:if\s+exists\s+)?(?:only\s+)?([\w."]+)\s+([\s\S]*?);/gi;
  while ((m = reA.exec(sql))) {
    const table = m[1];
    if (/%I|%s/.test(table)) continue;
    for (const clause of splitTop(m[2])) {
      const c = clause.trim();
      let x;
      if ((x = c.match(/^add\s+(?:column\s+)?(?:if\s+not\s+exists\s+)?"?([a-z_][\w]*)"?\s+/i)) && !/^add\s+(constraint|primary|unique|foreign|check)\b/i.test(c)) add(table, x[1], f);
      else if ((x = c.match(/^drop\s+column\s+(?:if\s+exists\s+)?"?([a-z_][\w]*)"?/i))) drop(table, x[1], f);
      else if ((x = c.match(/^rename\s+column\s+"?([a-z_][\w]*)"?\s+to\s+"?([a-z_][\w]*)"?/i))) { drop(table, x[1], f); add(table, x[2], f); }
    }
  }
}

module.exports = { cols, born, dropped, created };

if (require.main === module) {
  const want = process.argv.slice(3);
  for (const t of want.length ? want : Object.keys(cols).sort()) {
    const s = cols[t];
    console.log(`\n== ${t} (${s ? s.size : 0} columns)`);
    if (s) console.log([...s].sort().join(', '));
  }
  console.log('\nDROPPED / RENAMED-AWAY:', dropped.length ? JSON.stringify(dropped) : 'none');
}
