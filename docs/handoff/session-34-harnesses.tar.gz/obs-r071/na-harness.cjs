// Observatory R-071 harness: the REAL routes/next-actions.js (compiled from
// source, optionally mutated) over dispatch's in-memory fake, driven over HTTP.
// Usage: node na-harness.cjs [mutation]
const REPO = '/home/user/PACE_All-in-one-recruting-tool';
const path = require('path');
const fs = require('fs');
const Module = require('module');
const express = require(REPO + '/node_modules/express');
const { makeFakeSupabase } = require(path.join(__dirname, '..', 'repro', 'fake-supabase.cjs'));

const FILE = path.join(REPO, 'routes', 'next-actions.js');
const MUTATIONS = {
  // M1 — the original bug: admins exempt from the split and from the narrowing.
  admin_exempt: [
    ['const ownThreads = threads.filter(t => ownership.isMine(t, me));', 'const ownThreads = isAdmin ? threads : threads.filter(t => ownership.isMine(t, me));'],
    ['const ownRemRows = (remRows || []).filter(', 'const ownRemRows = isAdmin ? (remRows || []) : (remRows || []).filter('],
    ['const { mine } = ownership.splitByOwner(after.items, req.user.id);', 'const { mine } = isAdmin ? { mine: after.items } : ownership.splitByOwner(after.items, req.user.id);'],
  ],
  // M2 — split kept, narrowing BEFORE ranking removed (split after the cap).
  narrow_after_rank: [
    ['const ownThreads = threads.filter(t => ownership.isMine(t, me));', 'const ownThreads = threads;'],
    ['const ownRemRows = (remRows || []).filter(r => ownership.isMine({ owner_id: r.user_id }, me));', 'const ownRemRows = remRows || [];'],
  ],
  // M3 — the old Done write: scoped to user_id = me, success whatever happened.
  done_silent: [
    ["upd = row.user_id ? upd.eq('user_id', req.user.id) : upd.is('user_id', null);", "upd = upd.eq('user_id', req.user.id);"],
    ['if (!closed || !closed.length) {', 'if (false) {'],
  ],
  // M4 — the count drifts from the review (counts only what is due today).
  count_drift: [
    ['const team = (beneath || []).map(r => ({ owner_id: r.user_id }));', "const team = (beneath || []).filter(r => r.return_date && r.return_date <= today()).map(r => ({ owner_id: r.user_id }));"],
  ],
};

function loadRouter(mutation) {
  let src = fs.readFileSync(FILE, 'utf8');
  for (const [a, b] of (MUTATIONS[mutation] || [])) {
    if (!src.includes(a)) throw new Error('mutation anchor missing: ' + a.slice(0, 60));
    src = src.replace(a, b);
  }
  const m = new Module(FILE, module);
  m.filename = FILE; m.paths = Module._nodeModulePaths(path.dirname(FILE));
  m._compile(src, FILE);
  return m.exports;
}

const DAY = 864e5;
const iso = (d) => new Date(d).toISOString().slice(0, 10);
const TODAY = iso(Date.now()), YDAY = iso(Date.now() - DAY), FUTURE = iso(Date.now() + 5 * DAY);
const ORG = 'org-1';
const U = (id, name, role, manager_id = null) => ({ id, name, role, roles: [role], org_id: ORG, manager_id, deleted_at: null });

function fixture() {
  const users = [
    U('ADM', 'Prince Thomas', 'admin'),           // admin, nobody reports to him
    U('BDL', 'BD Lead 1', 'bd_lead'),             // owns the 3 live reminders
    U('BD1', 'BD One', 'bd', 'BDL'),
    U('MGR', 'Director D', 'director'),
    U('RC', 'Recruiter R', 'recruiter', 'MGR'),
  ];
  const rem = (id, user_id, return_date, extra = {}) => Object.assign({ id, user_id, org_id: ORG, return_date, status: 'pending', note: null, contact_name: 'Person ' + id, company_name: 'Co ' + id, contact_id: null, job_id: null, reminder_type: 'ooo_return', job: null, contact: null }, extra);
  const reminders = [
    rem('r1', 'BDL', YDAY), rem('r2', 'BDL', YDAY), rem('r3', 'BDL', YDAY),   // production shape
    rem('r4', 'ADM', TODAY),                                                  // the admin's own
    rem('r5', null, TODAY),                                                   // ownerless legacy row
    rem('r6', 'BD1', FUTURE),                                                 // open, not due
    rem('r7', 'RC', TODAY),
  ];
  const job = (id, owner, stage = 'Connected') => ({ id, org_id: ORG, position: 'Role ' + id, stage, assigned_to_bd: owner, company: { name: 'Co ' + id } });
  const jobs = [job('j1', 'BDL'), job('j3', null, 'Unassigned')];
  const contact = (id, job_id, replied) => ({ id, org_id: ORG, job_id, first_name: 'C', last_name: id, email: id + '@x.test', replied_at: replied, reply_snippet: 'Yes please send profiles', created_at: YDAY });
  const contacts = [contact('c1', 'j1', new Date(Date.now() - DAY).toISOString()), contact('c3', 'j3', new Date(Date.now() - DAY).toISOString())];
  return { users, reminders, jobs, contacts, submissions: [], conversation_messages: [], emails: [], email_tracking: [], app_settings: [], organizations: [{ id: ORG, plan: 'internal' }] };
}

async function start(mutation, userId, tables) {
  const fake = makeFakeSupabase(tables);
  const who = { current: userId };
  const auth = (req, res, next) => { const u = tables.users.find(x => x.id === who.current); req.user = Object.assign({}, u); req.orgId = ORG; next(); };
  const orgIdFor = (req) => (req && req.user && req.user.org_id) || null;
  const withOrg = (q, req) => { const o = orgIdFor(req); return o ? q.eq('org_id', o) : q; };
  const app = express(); app.use(express.json());
  app.use(loadRouter(mutation)({ supabase: fake, auth, orgIdFor, withOrg, today: () => TODAY }));
  const srv = await new Promise(r => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  const base = 'http://127.0.0.1:' + srv.address().port;
  const call = async (method, p, body) => {
    const r = await fetch(base + p, { method, headers: { 'content-type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
    let j = null; try { j = await r.json(); } catch (_) {}
    return { status: r.status, body: j };
  };
  return { call, who, fake, close: () => srv.close() };
}

async function main() {
  const mutation = process.argv[2] || null;
  let pass = 0, fail = 0;
  const t = (name, ok, info) => { if (ok) { pass++; console.log('  ✓ ' + name); } else { fail++; console.log('  ✗ ' + name + (info ? ' — ' + info : '')); } };
  const tables = fixture();
  const s = await start(mutation, 'ADM', tables);
  try {
    // ── A. Admin, nobody reports to him (the owner's case) ──
    s.who.current = 'ADM';
    const a = await s.call('GET', '/next-actions');
    const owners = (a.body.items || []).map(i => i.owner_id);
    t('A1 admin list carries only his own or ownerless items', a.status === 200 && owners.every(o => o === 'ADM' || o == null), JSON.stringify(owners));
    const remIds = (a.body.items || []).filter(i => i.reminder_id).map(i => i.reminder_id).sort();
    t('A2 his own due reminder and the ownerless one are on it; nobody else\'s', JSON.stringify(remIds) === JSON.stringify(['r4', 'r5']), JSON.stringify(remIds));
    t('A3 a reply on an Unassigned-pool lead still reaches an admin', (a.body.items || []).some(i => i.entity_id === 'c3'));
    const rv = await s.call('GET', '/next-actions/team');
    t('A4 the review covers the org although nobody reports to him (5 open: r1-r3, r6, r7)', rv.status === 200 && rv.body.items.length === 5, rv.status + ' ' + (rv.body.items || []).length);
    t('A5 the count on the list equals the review', a.body.team && a.body.team.total === rv.body.items.length, (a.body.team && a.body.team.total) + ' vs ' + rv.body.items.length);
    t('A6 scope reads org', a.body.scope === 'org', a.body.scope);

    // ── B. Crowding: a tiny limit must still show the admin his own first ──
    const b = await s.call('GET', '/next-actions?limit=2');
    const bIds = (b.body.items || []).map(i => i.reminder_id || i.entity_id);
    t('B1 with limit=2 his own reminder is not pushed off by colleagues\'', bIds.includes('r4'), JSON.stringify(bIds));
    t('B2 "N more" counts only his own overflow (3 own items, 2 shown → 1)', b.body.overflow === 1, String(b.body.overflow));

    // ── C. Every Done on the admin's list succeeds and really closes ──
    const results = [];
    for (const it of (a.body.items || []).filter(i => i.reminder_id)) {
      const d = await s.call('POST', '/next-actions/' + it.reminder_id + '/done');
      results.push(it.reminder_id + ':' + d.status + ':' + tables.reminders.find(r => r.id === it.reminder_id).status);
    }
    t('C1 no Done drawn on his list is refused, and each one closes its row', results.length === 2 && results.every(x => /:200:sent$/.test(x)), JSON.stringify(results));
    const a2 = await s.call('GET', '/next-actions');
    t('C2 closed reminders go off the list on the next load', !(a2.body.items || []).some(i => i.reminder_id), JSON.stringify((a2.body.items || []).map(i => i.reminder_id)));
    const refused = await s.call('POST', '/next-actions/r1/done');
    t('C3 the rule is intact: closing a BD Lead\'s reminder by API is still refused', refused.status === 403 && tables.reminders.find(r => r.id === 'r1').status === 'pending', String(refused.status));

    // ── D. Prompting ──
    const p1 = await s.call('POST', '/next-actions/r1/prompt', {});
    const made = tables.reminders.find(r => r.reminder_type === 'manager_prompt');
    t('D1 the admin can ask the BD Lead (not his report) — a note lands on HER list', p1.status === 201 && made && made.user_id === 'BDL', p1.status + ' ' + JSON.stringify(made && made.user_id));
    t('D2 asking about an ownerless reminder is refused with a sentence', (await s.call('POST', '/next-actions/r5/prompt', {})).status === 400);

    // ── E. A director whose recruiter has one due reminder ──
    s.who.current = 'MGR';
    const e = await s.call('GET', '/next-actions');
    const er = await s.call('GET', '/next-actions/team');
    t('E1 manager list carries nothing of the report\'s', (e.body.items || []).every(i => i.owner_id === 'MGR' || i.owner_id == null) && !(e.body.items || []).some(i => i.reminder_id === 'r7'));
    t('E2 manager count == review == 1 (r7)', e.body.team.total === 1 && er.body.items.length === 1, e.body.team.total + ' vs ' + er.body.items.length);
    t('E3 manager cannot prompt outside the chain', (await s.call('POST', '/next-actions/r2/prompt', {})).status === 403);

    // ── F. The BD Lead sees and closes her own ──
    s.who.current = 'BDL';
    const f = await s.call('GET', '/next-actions');
    const fIds = (f.body.items || []).filter(i => i.reminder_id).map(i => i.reminder_id).sort();
    t('F1 the owner\'s list carries her reminders (and the manager\'s prompt)', ['r1', 'r2', 'r3'].every(id => fIds.includes(id)) && fIds.includes(made && made.id), JSON.stringify(fIds));
    t('F2 her reply-due lead is on her list', (f.body.items || []).some(i => i.entity_id === 'c1'));
    t('F3 her count is her report\'s open (future) reminder, and the review agrees', f.body.team.total === 1 && (await s.call('GET', '/next-actions/team')).body.items.length === 1, String(f.body.team.total));
    const fd = await s.call('POST', '/next-actions/r2/done');
    t('F4 Done by the owner closes it', fd.status === 200 && tables.reminders.find(r => r.id === 'r2').status === 'sent');

    // ── G. Nobody beneath you ──
    s.who.current = 'BD1';
    const g = await s.call('GET', '/next-actions');
    const gr = await s.call('GET', '/next-actions/team');
    t('G1 no reports: no count, empty review', g.body.team.total === 0 && gr.body.items.length === 0 && g.body.scope === 'own');
  } finally { s.close(); }
  console.log((mutation ? 'MUTATION ' + mutation + ': ' : '') + `SUMMARY: ${pass}/${pass + fail} passed`);
  process.exit(fail ? 1 : 0);
}
main().catch(e => { console.error(e); process.exit(2); });
