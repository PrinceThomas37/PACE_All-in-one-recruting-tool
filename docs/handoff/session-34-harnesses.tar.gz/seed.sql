-- Mirrors the live shape (1 job order, 24 candidates, 15 'Tagged' pipeline rows,
-- submissions EMPTY) plus edge cases the live data does not exercise.
DO $$
DECLARE
  orgA uuid; orgB uuid; owner uuid; ownerB uuid; j1 uuid; jb uuid; c uuid; i int;
  cand uuid[] := ARRAY[]::uuid[];
  sub uuid; pl uuid;
BEGIN
  SELECT id INTO orgA FROM organizations ORDER BY created_at LIMIT 1;
  INSERT INTO organizations (name, slug) VALUES ('Other Co', 'other') RETURNING id INTO orgB;
  INSERT INTO users (name, org_id) VALUES ('Owner', orgA) RETURNING id INTO owner;
  INSERT INTO users (name, org_id) VALUES ('Owner B', orgB) RETURNING id INTO ownerB;
  INSERT INTO job_orders (job_title, org_id) VALUES ('Live job', orgA) RETURNING id INTO j1;
  INSERT INTO job_orders (job_title, org_id) VALUES ('Other company job', orgB) RETURNING id INTO jb;

  FOR i IN 1..24 LOOP
    INSERT INTO candidates (full_name, org_id) VALUES ('Live Cand ' || i, orgA) RETURNING id INTO c;
    cand := cand || c;
  END LOOP;

  -- the 15 live rows: all Tagged, ~15:20 UTC on 24 Sep, source Manual, no submission
  FOR i IN 1..15 LOOP
    INSERT INTO candidate_pipeline (pipeline_code, candidate_id, job_order_id, pipeline_status, source, tagged_by, tagged_at, org_id, bill_rate, employer_name, notes)
    VALUES ('PL-' || lpad(i::text, 5, '0'), cand[i], j1, 'Tagged', 'Manual', owner,
            timestamptz '2026-09-24 15:20:00+00' + (i || ' seconds')::interval, orgA,
            CASE WHEN i IN (2, 9) THEN '80' END, CASE WHEN i = 3 THEN 'Acme' END, CASE WHEN i = 4 THEN 'from the database' END);
  END LOOP;

  -- E1: a live submission already exists for the pair (pipeline row unlinked)
  INSERT INTO submissions (submission_code, candidate_id, job_order_id, stage, org_id, recruiter_id)
    VALUES ('SB-EXIST1', cand[16], j1, 'Screening', orgA, owner) RETURNING id INTO sub;
  INSERT INTO candidate_pipeline (pipeline_code, candidate_id, job_order_id, pipeline_status, tagged_by, org_id)
    VALUES ('PL-E1', cand[16], j1, 'Tagged', owner, orgA);

  -- E2: a soft-deleted pipeline row — must be left alone
  INSERT INTO candidate_pipeline (pipeline_code, candidate_id, job_order_id, pipeline_status, tagged_by, org_id, deleted_at)
    VALUES ('PL-E2', cand[17], j1, 'Tagged', owner, orgA, now());

  -- E3: nobody recorded as the tagger
  INSERT INTO candidate_pipeline (pipeline_code, candidate_id, job_order_id, pipeline_status, tagged_by, org_id)
    VALUES ('PL-E3', cand[18], j1, 'Tagged', NULL, orgA);

  -- E4: another company's row — must keep ITS company, not the column default
  INSERT INTO candidates (full_name, org_id) VALUES ('Other Co Cand', orgB) RETURNING id INTO c;
  INSERT INTO candidate_pipeline (pipeline_code, candidate_id, job_order_id, pipeline_status, tagged_by, org_id)
    VALUES ('PL-E4', c, jb, 'Tagged', ownerB, orgB);

  -- E5: a SOFT-DELETED submission exists for the pair (must not block a new live one)
  INSERT INTO submissions (submission_code, candidate_id, job_order_id, stage, org_id, deleted_at)
    VALUES ('SB-GONE5', cand[19], j1, 'Offer', orgA, now());
  INSERT INTO candidate_pipeline (pipeline_code, candidate_id, job_order_id, pipeline_status, tagged_by, org_id)
    VALUES ('PL-E5', cand[19], j1, 'Tagged', owner, orgA);

  -- E6: already linked, still carrying a retired word
  INSERT INTO submissions (submission_code, candidate_id, job_order_id, stage, org_id, recruiter_id)
    VALUES ('SB-LINK6', cand[20], j1, 'Submitted to BDM', orgA, owner) RETURNING id INTO sub;
  INSERT INTO candidate_pipeline (pipeline_code, candidate_id, job_order_id, pipeline_status, tagged_by, org_id, submission_id)
    VALUES ('PL-E6', cand[20], j1, 'Moved to Submission', owner, orgA, sub) RETURNING id INTO pl;
  UPDATE submissions SET pipeline_id = pl WHERE id = sub;
END $$;
