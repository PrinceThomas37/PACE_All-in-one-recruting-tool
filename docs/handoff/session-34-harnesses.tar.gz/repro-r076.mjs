// SCRATCH (not part of the repo): R-076 reproduction + verification harness.
//
// Drives the REAL routes/apply.js (or ROUTE_FILE=<mutant>) over a fake supabase
// that behaves like PostgREST where it matters for this bug:
//   * every column NAMED in a select / filter / insert / update is validated
//     against the schema folded out of migrations/*.sql — an unknown column
//     answers {data:null, error:{code:'42703', ...}} exactly as PostgREST does,
//   * rows are PROJECTED to the route's own select list (a field the route
//     reads but did not select comes back undefined, as it does in production),
//   * failures can be injected into: the job lookup, the app_settings recorder,
//     the storage upload, the staging insert and the counter update.
import { createRequire } from 'node:module';
import http from 'node:http';

const ROOT = '/home/user/PACE_All-in-one-recruting-tool';
const SCRATCH = '/tmp/claude-0/-home-user-PACE-All-in-one-recruting-tool/2683caef-a9ba-5eed-bb57-5c335d09589a/scratchpad';
const require = createRequire(ROOT + '/test/_.mjs');
const express = require('express');
const { cols } = require(SCRATCH + '/column-map.js');
const ROUTE = process.env.ROUTE_FILE || ROOT + '/routes/apply.js';
const QUICK = process.env.QUICK === '1';         // skip the 4s hang scenario

const results = [];
const ok = (name, cond, detail = '') => results.push({ name, ok: !!cond, detail: String(detail) });
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
async function waitFor(fn, ms = 1500) {
  const end = Date.now() + ms;
  while (Date.now() < end) { if (fn()) return true; await sleep(10); }
  return !!fn();
}
let unhandled = 0;
process.on('unhandledRejection', () => { unhandled++; });
process.on('uncaughtException', () => { unhandled++; });

const LIVE = 'a1b2c3d4e5f60718a1b2c3d4e5f60718';
const OFFLINE = 'b1b2c3d4e5f60718a1b2c3d4e5f60718';
const CLOSED = 'c1b2c3d4e5f60718a1b2c3d4e5f60718';
const UNKNOWN = 'f'.repeat(32);
const ORG = 'org-1';
const KNOWN = new Set(['job_orders', 'sourcing_candidates', 'candidates']);

// The REAL job_orders table has bd_manager_id and created_by — and no owner_id.
const liveRow = () => ({
  id: 'jo-1', org_id: ORG, job_code: 'JO-0041', job_title: 'HVAC Service Technician',
  client: 'Northwind Construction LLC', end_client: 'Northwind Construction LLC',
  city: 'New Britain', state: 'CT', remote: 'No', job_type: 'Full-time',
  job_description: 'Great role.', primary_skills: 'HVAC, EPA', exp_min: '3', exp_max: '8',
  status: 'Active', apply_enabled: true, apply_token: LIVE, apply_count: 4,
  bd_manager_id: 'u-bd', created_by: 'u-ra',
});

let S;
function fresh() {
  S = {
    jobs: {
      [LIVE]: liveRow(),
      [OFFLINE]: { id: 'jo-2', org_id: ORG, job_title: 'Estimator', status: 'Active', apply_enabled: false, apply_token: OFFLINE, apply_count: 0 },
      [CLOSED]: { id: 'jo-3', org_id: ORG, job_title: 'Superintendent', status: 'Filled', apply_enabled: true, apply_token: CLOSED, apply_count: 0 },
    },
    inserted: [], uploads: [], upserts: [], upsertAttempts: 0, counterWrites: [], mailboxFor: [], userLookups: [], sent: [], selects: [],
    failJobLookup: null, settingsMode: 'ok', uploadMode: 'ok', insertShouldFail: false, failCounter: false,
  };
}
fresh();

const project = (row, list) => {
  if (!row) return null;
  const want = String(list || '').split(',').map(s => s.trim()).filter(Boolean);
  if (!want.length || want.includes('*')) return { ...row };
  const o = {}; want.forEach(c => { o[c] = row[c] === undefined ? null : row[c]; }); return o;
};

async function run(q) {
  const t = q.table;
  if (q.op === 'select') S.selects.push({ table: t, cols: q.cols, filters: { ...q.filters } });
  const named = [];
  if (q.cols) named.push(...q.cols.split(',').map(s => s.trim()).filter(Boolean));
  named.push(...Object.keys(q.filters));
  if (q.payload && q.op !== 'upsert') named.push(...Object.keys(q.payload));
  if (KNOWN.has(t)) {
    const bad = named.filter(n => n !== '*' && !cols[t].has(n));
    if (bad.length) return { data: null, error: { code: '42703', details: null, hint: null, message: `column ${t}.${bad[0]} does not exist` }, status: 400 };
  }

  if (t === 'job_orders' && q.op === 'select') {
    if (S.failJobLookup && q.filters.apply_token !== undefined) {
      const m = S.failJobLookup;
      if (m === 'reject') throw new Error('socket hang up (token ' + q.filters.apply_token + ')');
      if (m === 'hang') return new Promise(() => {});
      if (m === 'error') return { data: null, error: { code: 'XX000', message: 'connection terminated while looking up ' + q.filters.apply_token, details: 'Failing row contains (Jane Doe, jane@example.com, 555-0100)', hint: 'retry' }, status: 500 };
    }
    const row = q.filters.apply_token !== undefined ? S.jobs[q.filters.apply_token]
      : Object.values(S.jobs).find(j => j.id === q.filters.id);
    return { data: project(row, q.cols), error: null };
  }
  if (t === 'job_orders' && q.op === 'update') {
    S.counterWrites.push(q.payload);
    if (S.failCounter) return { data: null, error: { code: 'XX000', message: 'counter write refused' } };
    const row = Object.values(S.jobs).find(j => j.id === q.filters.id);
    if (row) Object.assign(row, q.payload);
    return { data: null, error: null };
  }
  if (t === 'sourcing_candidates' && q.op === 'insert') {
    if (S.insertShouldFail) return { data: null, error: { code: '23502', message: 'null value in column violates not-null constraint' } };
    S.inserted.push(q.payload);
    return { data: project({ id: 'sc-' + S.inserted.length }, q.cols), error: null };
  }
  if (t === 'organizations') return { data: { name: 'Fute Global' }, error: null };
  if (t === 'users') { S.userLookups.push(q.filters.id); return { data: { email: 'owner@example.com' }, error: null }; }
  if (t === 'app_settings' && q.op === 'upsert') {
    if (S.settingsMode === 'hang') return new Promise(() => {});
    if (S.settingsMode === 'error') return { data: null, error: { message: 'permission denied for table app_settings' } };
    S.upserts.push(q.payload);
    return { data: null, error: null };
  }
  return { data: null, error: null };
}

function fakeSupabase() {
  function from(table) {
    const q = { table, op: 'select', cols: null, filters: {}, payload: null };
    const base = {
      select(c) { q.cols = c; return chain; },
      eq(c, v) { q.filters[c] = v; return chain; },
      ilike(c, v) { q.filters[c] = String(v).toLowerCase(); return chain; },
      is(c, v) { q.filters[c] = v; return chain; },
      update(v) { q.op = 'update'; q.payload = v; return chain; },
      insert(v) { q.op = 'insert'; q.payload = v; return chain; },
      upsert(v) {
        if (table === 'app_settings') S.upsertAttempts++;
        if (table === 'app_settings' && S.settingsMode === 'throw') throw new Error('app_settings unavailable');
        q.op = 'upsert'; q.payload = v; return chain;
      },
      maybeSingle() { return run(q); },
      single() { return run(q); },
      then(res, rej) { return run(q).then(res, rej); },
    };
    const chain = new Proxy(base, { get: (t, k) => (k in t || typeof k === 'symbol') ? t[k] : () => chain });
    return chain;
  }
  return {
    from,
    storage: { from: () => {
      if (S.uploadMode === 'sync-throw') throw new TypeError('storage client is broken');
      return ({ upload: async (p, buf) => {
      if (S.uploadMode === 'reject') throw new TypeError('fetch failed');
      if (S.uploadMode === 'error') return { data: null, error: { message: 'Bucket not found' } };
      S.uploads.push({ path: p, bytes: buf.length }); return { data: { path: p }, error: null };
    } }); } },
  };
}

const servers = [];
async function boot(extra = {}) {
  const app = express();
  app.use(express.json({ limit: '5mb' }));
  app.use(require(ROUTE)({
    supabase: fakeSupabase(), applyLimiter: null,
    recruiterSendingMailbox: async (id) => { S.mailboxFor.push(id); return { id: 'mb-1', platform: 'microsoft' }; },
    sendMailboxNewMessage: async (mb, to, subject) => { S.sent.push({ to, subject }); },
    ...extra,
  }));
  const server = http.createServer(app);
  await new Promise(r => server.listen(0, r));
  servers.push(server);
  return `http://127.0.0.1:${server.address().port}`;
}

const resumeB64 = Buffer.from('Jane Doe\njane@example.com\n555-0100\nHVAC Service Technician at Acme\n11 years experience\nSkills: HVAC, EPA, boilers\n').toString('base64');
const APPLICATION = { full_name: 'Jane Doe', email: 'jane@example.com', phone: '555-0100', filename: 'jane.txt', content_type: 'text/plain', data_base64: resumeB64 };
const get = (base, p) => fetch(base + p);
const post = (base, p, b) => fetch(base + p, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) });
const record = () => { const r = S.upserts.filter(u => u.key === 'apply_last_error').pop(); return r ? JSON.parse(r.value) : null; };

// ════════════════════════════════════════════════════════════════════════════
// 0. The fake must be able to catch the original bug, or nothing below means anything.
// ════════════════════════════════════════════════════════════════════════════
{
  fresh();
  const sb = fakeSupabase();
  const bad = await sb.from('job_orders').select('id,owner_id').eq('apply_token', LIVE).maybeSingle();
  ok('SELF-TEST: the fake answers 42703 for job_orders.owner_id (the real schema has none)',
    bad.error && bad.error.code === '42703' && bad.data === null, JSON.stringify(bad));
  const good = await sb.from('job_orders').select('id,bd_manager_id').eq('apply_token', LIVE).maybeSingle();
  ok('SELF-TEST: the fake PROJECTS rows to the select list', good.data && Object.keys(good.data).join() === 'id,bd_manager_id', JSON.stringify(good));
  const c = await sb.from('candidates').select('id,owner_id').maybeSingle();
  ok('SELF-TEST: owner_id is fine on candidates (that is where it lives)', !c.error);
}

// ════════════════════════════════════════════════════════════════════════════
// 0b. The two pure rules, called directly
// ════════════════════════════════════════════════════════════════════════════
{
  const mod = require(ROUTE);
  ok('exports: queryFailure and describeFailure are callable', typeof mod.queryFailure === 'function' && typeof mod.describeFailure === 'function');
  const qf = mod.queryFailure;
  ok('queryFailure: undefined (timed out) -> timeout, naming the bound', (qf(undefined, 4000) || {}).code === 'timeout' && /4000ms/.test((qf(undefined, 4000) || {}).message));
  ok('queryFailure: null (the promise rejected) -> rejected', (qf(null) || {}).code === 'rejected');
  ok('queryFailure: a result carrying an error -> that error', (qf({ data: null, error: { code: '42703', message: 'x' } }) || {}).code === '42703');
  ok('queryFailure: a CLEAN MISS ({data:null,error:null}) -> null', qf({ data: null, error: null }) === null);
  ok('queryFailure: a hit -> null', qf({ data: { id: 1 }, error: null }) === null);
  const d = mod.describeFailure('w', { code: '42703', message: 'column job_orders.owner_id does not exist', details: 'Failing row contains (jane@example.com)', hint: 'h' }, new Date('2026-09-29T12:00:00Z'));
  ok('describeFailure: exactly {at, code, message, where}', Object.keys(d).sort().join() === 'at,code,message,where');
  ok('describeFailure: at comes from the injected clock', d.at === '2026-09-29T12:00:00.000Z');
  ok('describeFailure: a readable message survives the scrub untouched', d.message === 'column job_orders.owner_id does not exist', d.message);
  ok('describeFailure: details are dropped', !/jane@example/.test(JSON.stringify(d)));
  const dt = mod.describeFailure('w', { message: 'z'.repeat(290) + LIVE });
  ok('describeFailure: a token straddling the length cut leaves no readable half', !dt.message.includes(LIVE.slice(0, 8)) && dt.message.length <= 300, dt.message.slice(280));
  ok('describeFailure: a token in the CODE is scrubbed too', !mod.describeFailure('w', { code: LIVE, message: 'm' }).code.includes(LIVE.slice(0, 8)));
  ok('describeFailure: a string / nullish error is safe', mod.describeFailure('w', 'boom').message === 'boom' && mod.describeFailure('w', undefined).code === 'unknown');
  ok('describeFailure: an Error with a name uses it (TypeError); a plain Error is "unknown"', mod.describeFailure('w', new TypeError('t')).code === 'TypeError' && mod.describeFailure('w', new Error('t')).code === 'unknown');
  ok('describeFailure: message is capped at 300', mod.describeFailure('w', { message: 'y'.repeat(1000) }).message.length === 300);
}

// ════════════════════════════════════════════════════════════════════════════
// 1. THE BUG: a published, active job must serve its page and take an application
// ════════════════════════════════════════════════════════════════════════════
{
  fresh();
  const base = await boot();
  const g = await get(base, '/apply/' + LIVE);
  const html = await g.text();
  ok('R-076: a published, active job serves its page (200)', g.status === 200, 'got ' + g.status);
  ok('R-076: ...and the page names the role', html.includes('HVAC Service Technician'));

  const p = await post(base, '/apply/' + LIVE, APPLICATION);
  const j = await p.json().catch(() => ({}));
  ok('R-076: an application to it is accepted (201, received)', p.status === 201 && j.received === true, p.status + ' ' + JSON.stringify(j).slice(0, 90));
  ok('R-076: exactly one staging row was written', S.inserted.length === 1, 'wrote ' + S.inserted.length);
  ok('R-076: the row carries the job order\'s org', S.inserted[0] && S.inserted[0].org_id === ORG);
  // The badge: the job had 4 applicants, so this application makes 5. Before this
  // fix the handler read job.apply_count from a select that never asked for it.
  const w = S.counterWrites[S.counterWrites.length - 1];
  ok('badge: the applicant counter goes 4 -> 5 (not "1")', w && w.apply_count === 5, JSON.stringify(w));
}

// ════════════════════════════════════════════════════════════════════════════
// 2. The owner of the job is bd_manager_id, then created_by (D-0035)
// ════════════════════════════════════════════════════════════════════════════
{
  fresh();
  const base = await boot();
  await post(base, '/apply/' + LIVE, APPLICATION);
  await waitFor(() => S.sent.length >= 2);
  ok('owner: the sending mailbox is resolved for bd_manager_id', S.mailboxFor[0] === 'u-bd', JSON.stringify(S.mailboxFor));
  ok('owner: the recruiter nudge looks up that same person', S.userLookups[0] === 'u-bd', JSON.stringify(S.userLookups));
  ok('owner: both emails go out (receipt + nudge)', S.sent.length === 2, 'sent ' + S.sent.length);

  fresh(); S.jobs[LIVE].bd_manager_id = null;
  const b2 = await boot();
  await post(b2, '/apply/' + LIVE, APPLICATION);
  await waitFor(() => S.mailboxFor.length >= 1);
  ok('owner: with no bd_manager_id it falls back to created_by', S.mailboxFor[0] === 'u-ra', JSON.stringify(S.mailboxFor));

  fresh(); S.jobs[LIVE].bd_manager_id = null; S.jobs[LIVE].created_by = null;
  const b3 = await boot();
  const r3 = await post(b3, '/apply/' + LIVE, APPLICATION);
  await sleep(150);
  ok('owner: with neither, the application is STILL accepted', r3.status === 201, 'got ' + r3.status);
  ok('owner: ...and no mailbox is resolved, no email is sent', S.mailboxFor.length === 0 && S.sent.length === 0);
}

// ════════════════════════════════════════════════════════════════════════════
// 3. A MISS and a FAILURE look identical to the public — and only a failure is recorded
// ════════════════════════════════════════════════════════════════════════════
let goneHtml, goneJson;
{
  fresh();
  const base = await boot();

  const m = await get(base, '/apply/not-a-token');
  ok('malformed token: 404', m.status === 404);
  ok('malformed token: never reaches the database', S.selects.length === 0, 'selects=' + S.selects.length);
  ok('malformed token: nothing recorded', S.upserts.length === 0);

  const u = await get(base, '/apply/' + UNKNOWN);
  goneHtml = await u.text();
  const up = await post(base, '/apply/' + UNKNOWN, APPLICATION);
  goneJson = await up.text();
  await sleep(60);
  ok('unknown token: 404 (GET and POST)', u.status === 404 && up.status === 404);
  ok('unknown token is a CLEAN MISS: nothing is recorded (no false alarms)', S.upserts.length === 0, JSON.stringify(S.upserts));

  const off = await get(base, '/apply/' + OFFLINE);
  const cls = await get(base, '/apply/' + CLOSED);
  const offT = await off.text(), clsT = await cls.text();
  await sleep(60);
  ok('unpublished / closed: byte-identical to unknown', offT === goneHtml && clsT === goneHtml);
  ok('unpublished / closed: nothing recorded', S.upserts.length === 0);

  // ---- the failure: the select itself fails
  S.failJobLookup = 'error';
  const f = await get(base, '/apply/' + LIVE);
  const fT = await f.text();
  const fp = await post(base, '/apply/' + LIVE, APPLICATION);
  const fpT = await fp.text();
  await waitFor(() => record() !== null);
  ok('failed lookup: the public answer is 404 like any miss', f.status === 404 && fp.status === 404, f.status + '/' + fp.status);
  ok('failed lookup: GET is BYTE-IDENTICAL to an unknown token', fT === goneHtml);
  ok('failed lookup: POST is BYTE-IDENTICAL to an unknown token', fpT === goneJson, fpT);
  const rec = record();
  ok('failed lookup: it IS recorded under apply_last_error', !!rec, JSON.stringify(S.upserts.map(x => x.key)));
  ok('record: exactly {at, code, message, where}', rec && Object.keys(rec).sort().join() === 'at,code,message,where', rec && Object.keys(rec).join());
  ok('record: code is the database\'s own code', rec && rec.code === 'XX000', rec && rec.code);
  ok('record: where says which query', rec && rec.where === 'job lookup', rec && rec.where);
  ok('record: message says what happened', rec && /connection terminated/.test(rec.message), rec && rec.message);
  ok('record: at is a fresh ISO time', rec && Math.abs(Date.now() - Date.parse(rec.at)) < 60000, rec && rec.at);
  const raw = S.upserts.filter(x => x.key === 'apply_last_error').map(x => x.value).join('|');
  ok('record: the TOKEN IS NEVER WRITTEN (even though the error text echoed it)', raw.length > 0 && !raw.includes(LIVE), raw);
  ok('record: `details` (which echo the failing row: name, email, phone) are NOT stored', !/jane@example|555-0100|Failing row/.test(raw), raw);
  ok('record: upsert shape matches its siblings (key/value/updated_at)', S.upserts[0] && 'updated_at' in S.upserts[0] && typeof S.upserts[0].value === 'string');

  // ---- the query THROWS instead of answering
  S.upserts.length = 0; S.failJobLookup = 'reject';
  const rj = await get(base, '/apply/' + LIVE);
  ok('rejected lookup: byte-identical public answer', (await rj.text()) === goneHtml && rj.status === 404);
  await waitFor(() => record() !== null);
  ok('rejected lookup: recorded as code "rejected"', record() && record().code === 'rejected', JSON.stringify(record()));
  ok('rejected lookup: token still not in the record', !S.upserts.map(x => x.value).join('').includes(LIVE));

  // ---- the query TIMES OUT (4s)
  if (!QUICK) {
    S.upserts.length = 0; S.failJobLookup = 'hang';
    const t0 = Date.now();
    const hg = await get(base, '/apply/' + LIVE);
    const hT = await hg.text();
    ok('timed-out lookup: byte-identical public answer', hT === goneHtml && hg.status === 404);
    await waitFor(() => record() !== null);
    ok('timed-out lookup: recorded as code "timeout"', record() && record().code === 'timeout', JSON.stringify(record()));
    ok('timed-out lookup: answered no later than the 4s bound (+slack)', Date.now() - t0 < 5500, (Date.now() - t0) + 'ms');
  }
}

// ════════════════════════════════════════════════════════════════════════════
// 4. RECORDING MUST NEVER BE THE REASON A REQUEST FAILS OR SLOWS
// ════════════════════════════════════════════════════════════════════════════
{
  fresh(); S.failJobLookup = 'error'; S.settingsMode = 'hang';
  const base = await boot();
  const t0 = Date.now();
  const r = await get(base, '/apply/' + LIVE);
  const took = Date.now() - t0;
  ok('recorder HANGS: the applicant\'s answer is not held up by it', took < 900 && (await r.text()) === goneHtml, took + 'ms');

  // A burst of failing requests during an outage must not become a burst of writes.
  fresh(); S.failJobLookup = 'error'; S.settingsMode = 'hang';
  const bb = await boot();
  await Promise.all([1, 2, 3, 4, 5].map(() => get(bb, '/apply/' + LIVE).then(x => x.text())));
  ok('recorder: a burst of 5 failing requests starts ONE write, not five', S.upsertAttempts === 1, 'attempts=' + S.upsertAttempts);
  await sleep(1700);   // the hung write is abandoned at 1.5s, which releases the guard
  await get(bb, '/apply/' + LIVE).then(x => x.text());
  ok('recorder: ...and the guard RELEASES once that write is abandoned', S.upsertAttempts === 2, 'attempts=' + S.upsertAttempts);

  fresh(); S.failJobLookup = 'error'; S.settingsMode = 'throw';
  const b2 = await boot();
  const r2 = await get(b2, '/apply/' + LIVE);
  ok('recorder THROWS synchronously: identical answer, no crash', r2.status === 404 && (await r2.text()) === goneHtml);

  fresh(); S.failJobLookup = 'error'; S.settingsMode = 'error';
  const b3 = await boot();
  const r3 = await get(b3, '/apply/' + LIVE);
  ok('recorder is REFUSED (permission denied): identical answer', r3.status === 404 && (await r3.text()) === goneHtml);

  // ctx with no way to record at all (a bare fake)
  fresh(); S.failJobLookup = 'error';
  const b4 = await boot({ supabase: { from: () => { throw new Error('no such table'); } } });
  const r4 = await get(b4, '/apply/' + LIVE);
  ok('supabase itself throws on every call: still a clean 404, no crash', r4.status === 404);
}

// ════════════════════════════════════════════════════════════════════════════
// 5. THE OTHER SILENT FAILURES ON THE SAME ROUTE
// ════════════════════════════════════════════════════════════════════════════
{
  fresh(); S.insertShouldFail = true;
  const base = await boot();
  const r = await post(base, '/apply/' + LIVE, APPLICATION);
  const j = await r.json();
  await waitFor(() => record() !== null);
  ok('insert fails: still reported honestly (received:false)', j.received === false && !j.html);
  ok('insert fails: recorded, where=application insert', record() && record().where === 'application insert', JSON.stringify(record()));

  fresh(); S.uploadMode = 'reject';
  const b2 = await boot();
  const r2 = await post(b2, '/apply/' + LIVE, APPLICATION);
  await waitFor(() => record() !== null);
  ok('upload THROWS: NOT reported as saved (was treated as success)', r2.status === 503 && S.inserted.length === 0, 'status ' + r2.status + ', rows ' + S.inserted.length);
  ok('upload THROWS: recorded, where=resume upload', record() && record().where === 'resume upload', JSON.stringify(record()));

  fresh(); S.uploadMode = 'error';
  const b3 = await boot();
  const r3 = await post(b3, '/apply/' + LIVE, APPLICATION);
  await waitFor(() => record() !== null);
  ok('upload REFUSED (bucket error): 503, nothing staged, recorded', r3.status === 503 && S.inserted.length === 0 && record() && record().where === 'resume upload');

  fresh(); S.failCounter = true;
  const b4 = await boot();
  const r4 = await post(b4, '/apply/' + LIVE, APPLICATION);
  await waitFor(() => record() !== null);
  ok('counter fails: the APPLICATION is still accepted', r4.status === 201 && S.inserted.length === 1);
  ok('counter fails: recorded, where=apply_count update', record() && record().where === 'apply_count update', JSON.stringify(record()));
}

// ---- the two OUTER catches: an unexpected exception is a bug, not a closed role
{
  fresh(); S.jobs[LIVE].city = { toString() { throw new Error('render exploded'); } };
  const base = await boot();
  const g = await get(base, '/apply/' + LIVE);
  ok('GET render throws: same answer as any miss', g.status === 404 && (await g.text()) === goneHtml);
  await waitFor(() => record() !== null);
  ok('GET render throws: recorded, where=GET /apply/:token', record() && record().where === 'GET /apply/:token' && /render exploded/.test(record().message), JSON.stringify(record()));

  fresh(); S.uploadMode = 'sync-throw';
  const b2 = await boot();
  const p = await post(b2, '/apply/' + LIVE, APPLICATION);
  const j = await p.json();
  await waitFor(() => record() !== null);
  ok('POST throws unexpectedly: applicant told honestly (received:false)', j.received === false && !j.html);
  ok('POST throws unexpectedly: recorded, where=POST /apply/:token, code=TypeError', record() && record().where === 'POST /apply/:token' && record().code === 'TypeError', JSON.stringify(record()));
}

for (const s of servers) s.close();
await sleep(50);
ok('no unhandled rejections / uncaught exceptions anywhere in the run', unhandled === 0, 'count=' + unhandled);

const failed = results.filter(r => !r.ok);
for (const r of results) console.log(`${r.ok ? '✓' : '✗'} ${r.name}${!r.ok && r.detail ? '  — ' + r.detail.slice(0, 220) : ''}`);
console.log(`\n${results.length - failed.length}/${results.length} passed  (route: ${ROUTE.replace(ROOT + '/', '')})`);
process.exit(failed.length ? 1 : 0);
