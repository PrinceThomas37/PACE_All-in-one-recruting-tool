// R-075 / D-0057 — every way of putting a person on a job writes the SAME rows.
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
import { makeDb, mountRecruiting, makeCaller, person, step, summary, uid, DEFAULT_ORG, ORG_A, ORG_B } from './harness.mjs';

const db = makeDb();
const routes = mountRecruiting(db);
const call = makeCaller(routes);

const bd = person('bd', ORG_A, 'Bea BD');
const recruiter = person('recruiter', ORG_A, 'Rex Recruiter');
const ra = person('ra', ORG_A, 'Ray RA');
const bdB = person('bd', ORG_B, 'Bob BD (other company)');
db.T('users').push(...[bd, recruiter, ra, bdB].map(u => ({ id: u.id, org_id: u.org_id, name: u.name, deleted_at: null })));

const J1 = uid(), J2 = uid(), JB = uid();
db.T('job_orders').push(
  { id: J1, org_id: ORG_A, job_title: 'HVAC Tech', job_code: 'JO-1', status: 'Open', bd_manager_id: bd.id, deleted_at: null },
  { id: J2, org_id: ORG_A, job_title: 'Estimator', job_code: 'JO-2', status: 'Open', bd_manager_id: bd.id, deleted_at: null },
  { id: JB, org_id: ORG_B, job_title: 'Other co job', job_code: 'JO-B', status: 'Open', bd_manager_id: bdB.id, deleted_at: null });
db.T('recruiter_assignments').push({ id: uid(), org_id: ORG_A, recruiter_id: recruiter.id, job_order_id: J1 });

const cand = (name, extra) => {
  const c = Object.assign({ id: uid(), org_id: ORG_A, full_name: name, current_employer: 'Acme', bill_rate: '80', availability: '2 weeks', work_authorization: 'US Citizen', source: 'Manual', deleted_at: null }, extra || {});
  db.T('candidates').push(c); return c;
};
const C = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'].map(n => cand('Cand ' + n));
const CB = cand('Foreign cand', { org_id: ORG_B });

const subsOn = (jid) => db.T('submissions').filter(s => s.job_order_id === jid && !s.deleted_at);
const plOn = (jid) => db.T('candidate_pipeline').filter(p => p.job_order_id === jid && !p.deleted_at);
const LEGACY_WORDS = ['Tagged', 'Contacted', 'Interested', 'Shortlisted', 'Moved to Submission', 'Not Interested', 'Rejected'];

// ── 1. THE CANDIDATES PAGE / JOB PAGE TAG (POST /pipeline) ─────────────────
{
  const r = await call('POST', '/pipeline', { user: bd, body: { candidate_id: C[0].id, job_order_id: J1 } });
  const sub = subsOn(J1).find(s => s.candidate_id === C[0].id);
  const pl = plOn(J1).find(p => p.candidate_id === C[0].id);
  step('POST /pipeline answers 201', r.status === 201, String(r.status) + ' ' + JSON.stringify(r.body).slice(0, 120));
  step('…a submission exists at Sourced', sub && sub.stage === 'Sourced');
  step('…with NO submitted_at (D-0029: adding is not submitting)', sub && !sub.submitted_at);
  step('…with a submission code', sub && /^SB-\d+$/.test(sub.submission_code || ''));
  step('…filed under the CALLER\'s company, not the column default', sub && sub.org_id === ORG_A && pl && pl.org_id === ORG_A);
  step('…owned by the person who added them', sub && sub.recruiter_id === bd.id && sub.submitted_by === bd.id);
  step('…the pipeline row is written as Sourced, never the column default "Tagged"', pl && pl.pipeline_status === 'Sourced', pl && pl.pipeline_status);
  step('…both rows link to each other', sub && pl && sub.pipeline_id === pl.id && pl.submission_id === sub.id);
  step('…the sourcing details are snapshotted onto both', sub && pl && sub.employer_name === 'Acme' && pl.employer_name === 'Acme' && pl.work_auth_snap === 'US Citizen');
  const act = db.T('submission_activity').find(a => a.submission_id === (sub && sub.id));
  step('…the job\'s history starts at Sourced (created: null -> Sourced), org-stamped', act && act.action === 'created' && act.old_stage == null && act.new_stage === 'Sourced' && act.org_id === ORG_A);
  step('…no history row uses the retired word "Tagged"', !db.T('submission_activity').some(a => a.new_stage === 'Tagged' || a.old_stage === 'Tagged'));
  step('…the response carries stage "Sourced" and no legacy status', r.body && r.body.stage === 'Sourced' && r.body.pipeline_status === 'Sourced');
}

// ── 2. ADDING THE SAME PERSON AGAIN IS "ALREADY", AND COSTS NO CODES ───────
{
  const before = { sb: db.seq.SB, pl: db.seq.PL, subs: subsOn(J1).length, pls: plOn(J1).length };
  const r = await call('POST', '/pipeline', { user: bd, body: { candidate_id: C[0].id, job_order_id: J1 } });
  step('adding somebody already on the job answers 409 already_on_job', r.status === 409 && r.body.code === 'already_on_job', JSON.stringify(r.body));
  step('…the message no longer says "tagged"', !/tagged/i.test(r.body.error));
  step('…no duplicate rows, no codes burned', subsOn(J1).length === before.subs && plOn(J1).length === before.pls && db.seq.SB === before.sb && db.seq.PL === before.pl);
}

// ── 3. MANY AT ONCE (POST /pipeline/bulk) — same writer, honest counts ─────
{
  const r = await call('POST', '/pipeline/bulk', { user: bd, body: { job_order_id: J1, candidate_ids: [C[0].id, C[1].id, C[2].id, 'not-a-uuid', CB.id, uid()] } });
  step('bulk counts added / already / not found', r.status === 200 && r.body.added === 2 && r.body.already === 1 && r.body.not_found === 3 && r.body.failed === 0, JSON.stringify(r.body));
  step('…one malformed id did not sink the good ones in its chunk', [C[1], C[2]].every(c => subsOn(J1).some(s => s.candidate_id === c.id)));
  step('…another company\'s candidate is never added', !db.T('submissions').some(s => s.candidate_id === CB.id) && !db.T('candidate_pipeline').some(p => p.candidate_id === CB.id));
  const two = subsOn(J1).filter(s => [C[1].id, C[2].id].includes(s.candidate_id));
  step('…each added person has the same shape as a single add', two.every(s => s.stage === 'Sourced' && !s.submitted_at && s.org_id === ORG_A && /^SB-/.test(s.submission_code)
    && plOn(J1).some(p => p.candidate_id === s.candidate_id && p.submission_id === s.id && p.pipeline_status === 'Sourced')));
  step('…and each has a created-at-Sourced history row', two.every(s => db.T('submission_activity').some(a => a.submission_id === s.id && a.action === 'created')));
  const bad = await call('POST', '/pipeline/bulk', { user: bd, body: { job_order_id: J1, candidate_ids: [] } });
  step('an empty list is refused', bad.status === 400);
  const big = await call('POST', '/pipeline/bulk', { user: bd, body: { job_order_id: J1, candidate_ids: Array.from({ length: 501 }, () => uid()) } });
  step('more than 500 is refused', big.status === 400);
}

// ── 4. THE 15 LEGACY ROWS: a tag with no submission is HEALED by adding again ─
{
  const legacy = { id: uid(), org_id: ORG_A, candidate_id: C[3].id, job_order_id: J1, pipeline_code: 'PL-LEGACY', pipeline_status: 'Tagged', submission_id: null, tagged_by: bd.id, tagged_at: '2026-09-24T15:20:00Z', deleted_at: null, employer_name: 'Old Employer' };
  db.T('candidate_pipeline').push(legacy);
  const g = await call('GET', `/job-orders/${J1}/pipeline`, { user: bd });
  const row = g.body.find(p => p.id === legacy.id);
  step('an un-healed legacy row is listed at stage Sourced — never "Tagged"', row && row.stage === 'Sourced' && row.pipeline_status === 'Sourced', row && JSON.stringify([row.stage, row.pipeline_status]));
  step('…and NO row in the list carries any word of the retired vocabulary', g.body.every(p => !LEGACY_WORDS.includes(p.pipeline_status) && !LEGACY_WORDS.includes(p.stage)));
  const r = await call('POST', '/pipeline', { user: bd, body: { candidate_id: C[3].id, job_order_id: J1 } });
  const sub = subsOn(J1).find(s => s.candidate_id === C[3].id);
  step('re-adding a legacy tag answers 409 (they were already on the job)…', r.status === 409 && r.body.healed === true, JSON.stringify(r.body));
  step('…but HEALS it: a Sourced submission now exists, linked both ways', sub && sub.stage === 'Sourced' && !sub.submitted_at && legacy.submission_id === sub.id && sub.pipeline_id === legacy.id);
  step('…and the legacy status word is retired in storage', legacy.pipeline_status === 'Sourced');
  step('…the existing details were not overwritten', legacy.employer_name === 'Old Employer');
}

// ── 5. THE DIRECT ADD (POST /submissions) — no longer its own writer ───────
{
  const r = await call('POST', '/submissions', { user: bd, body: { candidate_id: C[4].id, job_order_id: J1, bill_rate: '95', notes: 'via api' } });
  const sub = subsOn(J1).find(s => s.candidate_id === C[4].id);
  const pl = plOn(J1).find(p => p.candidate_id === C[4].id);
  step('POST /submissions answers 201 with the submission', r.status === 201 && r.body && r.body.id === (sub && sub.id), String(r.status));
  step('…at Sourced with NO submitted_at (it used to stamp one)', sub && sub.stage === 'Sourced' && !sub.submitted_at);
  step('…the pipeline row says Sourced, not "Moved to Submission"', pl && pl.pipeline_status === 'Sourced' && pl.submission_id === sub.id);
  step('…the typed rate is on BOTH rows (they start out agreeing)', sub.bill_rate === '95' && pl.bill_rate === '95' && sub.notes === 'via api' && pl.notes === 'via api');
  const again = await call('POST', '/submissions', { user: bd, body: { candidate_id: C[4].id, job_order_id: J1 } });
  step('…adding them again answers 409', again.status === 409);
  const foreignRec = await call('POST', '/submissions', { user: bd, body: { candidate_id: C[5].id, job_order_id: J1, recruiter_id: bdB.id } });
  step('naming a recruiter from ANOTHER company is refused, and nothing is written', foreignRec.status === 400 && !db.T('submissions').some(s => s.candidate_id === C[5].id));
  const ownRec = await call('POST', '/submissions', { user: bd, body: { candidate_id: C[5].id, job_order_id: J1, recruiter_id: recruiter.id } });
  step('naming a recruiter in your own company sets whose candidate it is', ownRec.status === 201 && subsOn(J1).find(s => s.candidate_id === C[5].id).recruiter_id === recruiter.id && subsOn(J1).find(s => s.candidate_id === C[5].id).submitted_by === bd.id);
}

// ── 6. THE SOURCING / APPLICANT IMPORT WITH A JOB ──────────────────────────
{
  const staged = (name) => { const s = { id: uid(), org_id: ORG_A, provider: 'apply', status: 'new', full_name: name, email: null, phone: null, raw: null }; db.T('sourcing_candidates').push(s); return s; };
  const s1 = staged('Applied Person');
  const r = await call('POST', `/sourcing/staged/${s1.id}/import`, { user: bd, body: { job_order_id: J1 } });
  const cand1 = db.T('candidates').find(c => c.full_name === 'Applied Person');
  const sub = cand1 && subsOn(J1).find(s => s.candidate_id === cand1.id);
  const pl = cand1 && plOn(J1).find(p => p.candidate_id === cand1.id);
  step('importing an applicant onto a job answers 201', r.status === 201, String(r.status) + ' ' + JSON.stringify(r.body).slice(0, 100));
  step('…they are on the job at Sourced, no submitted_at, org-stamped', sub && sub.stage === 'Sourced' && !sub.submitted_at && sub.org_id === ORG_A);
  step('…the pipeline row is org-stamped (it used to file under the default company), Sourced, and linked', pl && pl.org_id === ORG_A && pl.pipeline_status === 'Sourced' && pl.submission_id === sub.id && sub.pipeline_id === pl.id);
  step('…the candidate\'s source reads as a word, not the provider id', cand1 && cand1.source === 'Applicant');
  step('…no job_link_failed on a clean import', !r.body.job_link_failed);

  const s2 = staged('Foreign Job Person');
  const r2 = await call('POST', `/sourcing/staged/${s2.id}/import`, { user: bd, body: { job_order_id: JB } });
  const c2 = db.T('candidates').find(c => c.full_name === 'Foreign Job Person');
  step('importing onto ANOTHER company\'s job saves the person but reports the failed link', r2.status === 201 && c2 && r2.body.job_link_failed, JSON.stringify(r2.body.job_link_failed));
  step('…and writes NOTHING against the foreign job', !db.T('submissions').some(s => s.job_order_id === JB) && !db.T('candidate_pipeline').some(p => p.job_order_id === JB));

  const s3 = staged('No Job Person');
  const r3 = await call('POST', `/sourcing/staged/${s3.id}/import`, { user: bd, body: {} });
  step('importing with no job creates no membership', r3.status === 201 && !db.T('submissions').some(s => s.candidate_id === (db.T('candidates').find(c => c.full_name === 'No Job Person') || {}).id));

  const s4 = staged('Selected Person'), s5 = staged('Selected Person Two');
  const r4 = await call('POST', '/sourcing/import-selected', { user: bd, body: { ids: [s4.id, s5.id], job_order_id: J1 } });
  step('import-selected puts everybody on the job through the same writer', r4.status === 200 && r4.body.imported === 2 && r4.body.not_added_to_job === 0
    && ['Selected Person', 'Selected Person Two'].every(n => { const c = db.T('candidates').find(x => x.full_name === n); return c && subsOn(J1).some(s => s.candidate_id === c.id && s.stage === 'Sourced'); }), JSON.stringify(r4.body));
  const s6 = staged('Selected Foreign');
  const r5 = await call('POST', '/sourcing/import-selected', { user: bd, body: { ids: [s6.id], job_order_id: JB } });
  step('import-selected onto a foreign job counts what did not land', r5.body.imported === 1 && r5.body.not_added_to_job === 1, JSON.stringify(r5.body));
}

// ── 7. "PROMOTE" IS NO LONGER A WAY IN AT ANY STAGE ────────────────────────
{
  const legacy = { id: uid(), org_id: ORG_A, candidate_id: C[6].id, job_order_id: J1, pipeline_code: 'PL-L2', pipeline_status: 'Tagged', submission_id: null, tagged_by: bd.id, tagged_at: '2026-09-24T15:21:00Z', deleted_at: null };
  db.T('candidate_pipeline').push(legacy);
  const beforeSubs = subsOn(J1).length;
  const evil = await call('POST', `/pipeline/${legacy.id}/promote`, { user: recruiter, body: { stage: 'Placement' } });
  step('a recruiter cannot promote straight to Placement (the old side door)', evil.status === 400 && subsOn(J1).length === beforeSubs, String(evil.status) + ' ' + JSON.stringify(evil.body));
  const evil2 = await call('POST', `/pipeline/${legacy.id}/promote`, { user: bd, body: { stage: 'Submitted to BDM' } });
  step('…nor can anybody create a submission at "Submitted to BDM" this way', evil2.status === 400 && subsOn(J1).length === beforeSubs);
  const ok = await call('POST', `/pipeline/${legacy.id}/promote`, { user: recruiter, body: { stage: 'Sourced' } });
  const sub = subsOn(J1).find(s => s.candidate_id === C[6].id);
  step('promote with stage Sourced just makes sure they are on the job (201, created)', ok.status === 201 && sub && sub.stage === 'Sourced' && !sub.submitted_at && ok.body.submission && ok.body.submission.id === sub.id && ok.body.pipeline_id === legacy.id, JSON.stringify(ok.body).slice(0, 140));
  const twice = await call('POST', `/pipeline/${legacy.id}/promote`, { user: recruiter, body: {} });
  step('…and again is idempotent (200, already:true) — no stage is ever inferred', twice.status === 200 && twice.body.already === true && subsOn(J1).filter(s => s.candidate_id === C[6].id).length === 1 && sub.stage === 'Sourced');
}

// ── 8. THE SECOND VOCABULARY HAS NO DOOR LEFT ──────────────────────────────
{
  const p = plOn(J1)[0];
  const st = await call('PATCH', `/pipeline/${p.id}/status`, { user: bd, body: { status: 'Interested' } });
  step('PATCH /pipeline/:id/status is retired (410) and writes nothing', st.status === 410 && p.pipeline_status !== 'Interested');
  const ed = await call('PATCH', `/pipeline/${p.id}`, { user: bd, body: { pipeline_status: 'Shortlisted' } });
  step('PATCH /pipeline/:id refuses pipeline_status instead of silently ignoring it', ed.status === 400 && ed.body.code === 'no_pipeline_status' && p.pipeline_status !== 'Shortlisted');
  const ok = await call('PATCH', `/pipeline/${p.id}`, { user: bd, body: { notes: 'called him', bill_rate: '101' } });
  step('…but editing the sourcing details still works, and answers with a stage', ok.status === 200 && ok.body.notes === 'called him' && ok.body.stage === 'Sourced', String(ok.status));
  step('no live pipeline row anywhere holds a word of the retired vocabulary except rows written before this change', plOn(J1).every(x => x.pipeline_status === 'Sourced' || x.id === undefined));
}

// ── 9. WHO MAY ADD ─────────────────────────────────────────────────────────
{
  const noRole = await call('POST', '/pipeline', { user: ra, body: { candidate_id: C[7].id, job_order_id: J1 } });
  step('a research analyst (neither BD nor recruiter) may not add', noRole.status === 403);
  const unassigned = await call('POST', '/pipeline', { user: recruiter, body: { candidate_id: C[7].id, job_order_id: J2 } });
  step('a recruiter may not add to a job they are not assigned to', unassigned.status === 403 && !subsOn(J2).length);
  const assigned = await call('POST', '/pipeline', { user: recruiter, body: { candidate_id: C[7].id, job_order_id: J1 } });
  step('…but may add to one they are assigned to', assigned.status === 201);
  const foreign = await call('POST', '/pipeline', { user: bdB, body: { candidate_id: C[0].id, job_order_id: J1 } });
  step('another company cannot add to this company\'s job (404, not 403)', foreign.status === 404);
  const foreign2 = await call('POST', '/pipeline', { user: bd, body: { candidate_id: CB.id, job_order_id: J1 } });
  step('nor add another company\'s candidate (404)', foreign2.status === 404);
  // Each check on its own, so neither can hide behind the other:
  const ownCandForeignJob = await call('POST', '/pipeline', { user: bdB, body: { candidate_id: CB.id, job_order_id: J1 } });
  step('another company cannot add ITS OWN candidate to this company\'s job: 404, not a 500, nothing written', ownCandForeignJob.status === 404 && !db.T('submissions').some(s => s.candidate_id === CB.id), String(ownCandForeignJob.status));
  const ownJobForeignCand = await call('POST', '/pipeline', { user: bd, body: { candidate_id: C[0].id, job_order_id: JB } });
  step('and this company cannot add its candidate to another company\'s job (404)', ownJobForeignCand.status === 404 && !subsOn(JB).length && !plOn(JB).length);
  const directForeign = await call('POST', '/submissions', { user: bdB, body: { candidate_id: CB.id, job_order_id: J1 } });
  step('the direct add has the same wall (404)', directForeign.status === 404);
  const bulkForeign = await call('POST', '/pipeline/bulk', { user: bdB, body: { candidate_ids: [CB.id], job_order_id: J1 } });
  step('…and so does the bulk add (404, nothing written)', bulkForeign.status === 404 && !db.T('submissions').some(s => s.candidate_id === CB.id));
}

// ── 10. THE CANDIDATE PAGE'S PER-JOB READ ──────────────────────────────────
{
  const legacy = { id: uid(), org_id: ORG_A, candidate_id: C[3].id, job_order_id: J2, pipeline_code: 'PL-L3', pipeline_status: 'Tagged', submission_id: null, tagged_by: bd.id, tagged_at: '2026-09-24T15:22:00Z', deleted_at: null };
  db.T('candidate_pipeline').push(legacy);
  const h = await call('GET', `/candidates/${C[3].id}/history`, { user: bd });
  step('GET /candidates/:id/history — every pipeline entry carries a stage, none says "Tagged"', h.status === 200 && h.body.pipeline.length >= 2 && h.body.pipeline.every(p => p.stage === 'Sourced' && !LEGACY_WORDS.includes(p.pipeline_status)), JSON.stringify(h.body.pipeline && h.body.pipeline.map(p => [p.stage, p.pipeline_status])));
}

// ── 10b. THE TEAM ACTIVITY FEED SPEAKS THE OWNER'S WORDS ───────────────────
{
  // History written before this change: the add was logged as 'tagged' (new_stage
  // 'Tagged'), and a promotion carried the retired stage 'Tagged' as its old_stage.
  db.T('submission_activity').push(
    { id: uid(), org_id: ORG_A, submission_id: null, job_order_id: J1, recruiter_id: bd.id, action: 'tagged', old_stage: null, new_stage: 'Tagged', note: null, created_at: '2026-09-24T15:20:00Z' },
    { id: uid(), org_id: ORG_A, submission_id: subsOn(J1)[0].id, job_order_id: J1, recruiter_id: bd.id, action: 'promoted', old_stage: 'Tagged', new_stage: 'Submitted to BDM', note: null, created_at: '2026-09-24T16:00:00Z' });
  const f = await call('GET', '/team/activity', { user: bd });
  const details = (f.body && f.body.activity || []).map(a => a.detail);
  step('the team activity feed loads', f.status === 200 && details.length >= 3, String(f.status) + ' ' + details.length);
  step('the team feed never says "Tagged" and never calls an add "a submission"', details.length > 0 && !details.some(d => /tagged/i.test(d) || /added a submission/i.test(d)), [...new Set(details)].join(' | '));
  step('…a new add and an old "tagged" row both read "Added to a job"', details.filter(d => d === 'Added to a job').length >= 2);
  step('…a legacy "promoted" row reads by where the person went, not where it started', details.includes('Moved to Submitted to BDM') && !details.some(d => /Tagged/.test(d)));
}

// ── 11. THE HELPER REFUSES WHAT IT WAS NOT HANDED CORRECTLY ────────────────
{
  const core = require((process.env.GUILD_ROOT || '/home/user/PACE_All-in-one-recruting-tool') + '/services/recruiting-core.js')({
    supabase: db.supabase, hasRole: () => true, today: () => 'x',
    orgIdFor: (req) => req.user.org_id,
  });
  const req = { user: bd, orgId: ORG_A };
  let msg = null;
  try { await core.addCandidateToJob(req, { id: C[0].id, org_id: ORG_A }, { id: JB, org_id: ORG_B }); } catch (e) { msg = e.message; }
  step('addCandidateToJob refuses a job order row from another company', /not in your company/.test(msg || ''), msg);
  msg = null;
  try { await core.addCandidateToJob(req, { id: CB.id, org_id: ORG_B }, { id: J1, org_id: ORG_A }); } catch (e) { msg = e.message; }
  step('…and a candidate row from another company', /not in your company/.test(msg || ''), msg);
  msg = null;
  try { await core.addCandidateToJob(req, null, { id: J1 }); } catch (e) { msg = e.message; }
  step('…and a call with no candidate at all', /needs a candidate/.test(msg || ''), msg);
}

// ── 12. NOTHING ANYWHERE STILL WRITES THE OLD WORDS ────────────────────────
{
  const stray = db.log.writes.filter(w => w.table === 'candidate_pipeline' && w.op === 'insert' && w.row.pipeline_status !== 'Sourced');
  step('across every add above, no pipeline row was ever inserted with a status other than Sourced', stray.length === 0, stray.map(w => w.row.pipeline_status).join(','));
  const subStamp = db.log.writes.filter(w => w.table === 'submissions' && w.op === 'insert' && w.row.submitted_at);
  step('…and no submission was ever inserted with a submitted_at', subStamp.length === 0);
  const wrongOrg = db.T('submissions').concat(db.T('candidate_pipeline')).filter(r => r.org_id === DEFAULT_ORG);
  step('…and nothing was filed under the default company by accident', wrongOrg.length === 0, String(wrongOrg.length));
}

const failed = summary();
process.exit(failed ? 1 : 0);
