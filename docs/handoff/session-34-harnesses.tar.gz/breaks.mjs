// Deliberate-break verification (CLAUDE.md: "a guard is not trusted until you have
// reintroduced the bug and watched it fail"). Runs on a COPY of the code so the
// live tree is never touched. For each mutation: restore the copy, apply ONE
// change, run the scenario that guards it, and require a FAIL line that names the
// rule. A mutation that leaves the scenario green means the guard is vacuous.
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const LIVE = '/home/user/PACE_All-in-one-recruting-tool';
const HERE = path.dirname(new URL(import.meta.url).pathname);
const COPY = path.join(HERE, 'copy');
const FILES = ['services/applicants.js', 'services/recruiting-core.js', 'services/submission-stages.js',
  'routes/recruiting/pipeline.js', 'routes/recruiting/submissions.js', 'routes/recruiting/sourcing.js',
  'routes/recruiting/candidates.js', 'routes/recruiting/analytics.js', 'bd_recruiter_routes.js'];

function restore() { for (const f of FILES) fs.copyFileSync(path.join(LIVE, f), path.join(COPY, f)); }
function run(scenario) {
  const r = spawnSync('node', [path.join(HERE, `scenario-${scenario}.mjs`)], { env: Object.assign({}, process.env, { GUILD_ROOT: COPY }), encoding: 'utf8', timeout: 120000 });
  const out = (r.stdout || '') + (r.stderr || '');
  return { out, fails: out.split('\n').filter(l => l.startsWith('[FAIL]')), crashed: r.status !== 0 && !/SUMMARY/.test(out), summary: (out.match(/SUMMARY: .*/) || [''])[0] };
}

const M = (id, scenario, file, edits, expect, what) => ({ id, scenario, file, edits: Array.isArray(edits[0]) ? edits : [edits], expect, what });
const MUTATIONS = [
  // ── R-075 ────────────────────────────────────────────────────────────────
  M('M1', 'membership', 'services/applicants.js', ["    stage: ENTRY_STAGE,\n    revision_status:", "    stage: ENTRY_STAGE,\n    submitted_at: new Date().toISOString(),\n    revision_status:"], 'NO submitted_at', 'adding stamps submitted_at again (D-0029)'),
  M('M2', 'membership', 'services/applicants.js', ["    pipeline_status: ENTRY_STAGE,\n    work_auth_snap", "    pipeline_status: 'Tagged',\n    work_auth_snap"], 'never the column default', 'the pipeline row is written "Tagged" again (D-0057)'),
  M('M3', 'membership', 'services/recruiting-core.js', ["await scoped.from('candidate_pipeline').insert(prow)", "await supabase.from('candidate_pipeline').insert(prow)"], "CALLER's company", 'the pipeline insert forgets its org stamp (the old import bug)'),
  M('M4', 'membership', 'services/recruiting-core.js', [["let sub = pre ? (pre.submission || null) : await findMemberSubmission(scoped, cand.id, jobOrder.id);", "let sub = null;"], ["let pl = pre ? (pre.pipeline || null) : await findMemberPipeline(scoped, cand.id, jobOrder.id);", "let pl = null;"]], 'answers 409 already_on_job', 'the helper stops looking for existing membership first'),
  M('M5', 'membership', 'services/recruiting-core.js', ["if (pl.submission_id !== sub.id) {", "if (false) {"], 'HEALS it', 'the heal of a half-membership is removed'),
  M('M6', 'membership', 'services/recruiting-core.js', ["if (org && ((cand.org_id && cand.org_id !== org) || (jobOrder.org_id && jobOrder.org_id !== org))) {", "if (false) {"], 'refuses a job order row from another company', 'the helper stops checking the rows it is handed'),
  M('M7', 'membership', 'routes/recruiting/sourcing.js', [["      if (!opts.jobOrder) {", "      if (false) {"], ["addCandidateToJob(req, cand, opts.jobOrder, { recruiterId: userId })", "addCandidateToJob(req, cand, { id: opts.job_order_id }, { recruiterId: userId })"]], 'writes NOTHING against the foreign job', 'the import trusts the job id it was given (writes across companies)'),
  M('M8', 'membership', 'routes/recruiting/pipeline.js', ["if (asked !== ENTRY_STAGE) {", "if (false) {"], 'cannot promote straight to Placement', 'promote accepts any stage again'),
  M('M9', 'membership', 'routes/recruiting/pipeline.js', ["if (b.pipeline_status !== undefined) {", "if (false) {"], 'refuses pipeline_status', 'PATCH /pipeline/:id silently ignores pipeline_status'),
  M('M10', 'membership', 'routes/recruiting/pipeline.js', ["res.status(410).json({", "res.status(200).json({"], 'is retired (410)', 'the retired status route answers as if it worked'),
  M('M11', 'membership', 'routes/recruiting/pipeline.js', ["res.json((data || []).map(pipelineView));", "res.json(data || []);"], 'legacy row is listed at stage Sourced', 'the roster stops deriving stage (a legacy row reads "Tagged")'),
  M('M12', 'membership', 'services/recruiting-core.js', ["await logSubmissionActivity(sub.id, jobOrder.id, recruiterId, 'created', null, subStages.ENTRY_STAGE, o.note || null, req);", ""], 'history starts at Sourced', 'the add writes no history'),
  M('M13', 'membership', 'services/recruiting-core.js', ["for (const id of chunk) {\n        try {", "for (const id of []) {\n        try {"], 'one malformed id did not sink', 'readByIds loses its per-id fallback'),
  M('M14', 'membership', 'routes/recruiting/submissions.js', ["        if (!u) return res.status(400).json({ error: 'That recruiter is not in your company.' });", ""], 'recruiter from ANOTHER company', 'a foreign recruiter id is accepted'),
  M('M15', 'membership', 'services/recruiting-core.js', ["if (sub.pipeline_id !== pl.id) {", "if (false) {"], 'both rows link to each other', 'the submission never links back to its pipeline row'),
  M('M16', 'membership', 'services/recruiting-core.js', ["row.submission_code = await nextId('SB');", ""], 'with a submission code', 'the submission is written without its SB- code'),
  M('M17', 'membership', 'routes/recruiting/candidates.js', ["const pipeline = (pipelineRaw || []).map(pipelineView);", "const pipeline = (pipelineRaw || []);"], 'every pipeline entry carries a stage', 'the candidate history stops carrying stage'),
  // ── R-077 ────────────────────────────────────────────────────────────────
  M('B1', 'bulkstage', 'services/submission-stages.js', ["test: c => !c.isBDM && !c.isRecruiter,", "test: c => false,"], 'a research analyst may not move anybody', 'the role gate is removed'),
  M('B2', 'bulkstage', 'services/submission-stages.js', ["test: c => c.recruiterScoped && !RECRUITER_STAGES.includes(c.to),", "test: c => false,"], 'may not move INTO Submitted to Client', 'LAW 3: a recruiter may move anybody anywhere'),
  M('B3', 'bulkstage', 'services/submission-stages.js', ["test: c => c.recruiterScoped && !RECRUITER_STAGES.includes(c.from),", "test: c => false,"], 'already with BD', 'a recruiter may move somebody BD already owns'),
  M('B4', 'bulkstage', 'services/submission-stages.js', ["test: c => c.recruiterScoped && !c.assigned,", "test: c => false,"], 'not assigned to the job is refused', 'an unassigned recruiter may move people'),
  M('B5', 'bulkstage', 'services/submission-stages.js', ["test: c => c.recruiterScoped && c.to === TO_BDM && !(c.details && String(c.details.comment || '').trim()),", "test: c => false,"], 'submitting to BDM needs a comment', 'the hand-off comment is no longer required'),
  M('B6', 'bulkstage', 'services/submission-stages.js', ["test: c => c.to === NOT_ACCEPTED && !String(c.reason || '').trim(),", "test: c => false,"], 'Not Accepted with no reason', 'Not Accepted no longer needs its reason'),
  M('B7', 'bulkstage', 'services/submission-stages.js', ["test: c => !!c.bulk && c.from === c.to && (c.fromSubStage || null) === (c.subStage || null),", "test: c => false,"], 'already at the stage is refused', 'people already there are "moved" again'),
  M('B8', 'bulkstage', 'routes/recruiting/submissions.js', ["      if (early) return res.status(early.status).json({ error: early.message });", ""], 'cannot group-move anybody to Submitted to Client', 'the group move stops refusing the whole request up front'),
  M('B9', 'bulkstage', 'routes/recruiting/submissions.js', ["if (ids.length > BULK_STAGE_MAX) {", "if (false) {"], '201 people is refused', 'the 200 cap is removed'),
  M('B10', 'bulkstage', 'routes/recruiting/submissions.js', ["db.forRequest(req).from('submissions')\n        .select(MOVE_SELECT).in('id', chunk)", "supabase.from('submissions')\n        .select(MOVE_SELECT).in('id', chunk)"], 'SAME plain sentence', 'the group move reads rows outside the caller\'s company (an id can probe what exists)'),
  M('B11', 'bulkstage', 'routes/recruiting/submissions.js', ["plan.filter(s => !doneIds.has(s.id) && !failedSet.has(s.id))", "plan.filter(s => !doneIds.has(s.id))"], 'each refused once', 'a failed chunk is refused twice with the wrong sentence'),
  M('B12', 'bulkstage', 'routes/recruiting/submissions.js', ["await logSubmissionActivities(moved.map(s => ({", "await logSubmissionActivities([].map(s => ({"], 'one history row per moved person', 'a group move writes no history (R-002 would under-count)'),
  M('B13', 'bulkstage', 'routes/recruiting/submissions.js', ["      updates.bdm_approved_by = req.user.id;\n", ""], 'each records who approved', 'BD approval stops recording who approved'),
  M('B14', 'bulkstage', 'routes/recruiting/submissions.js', ["await scoped.from('reminders').insert(moved.map(s => {", "await scoped.from('reminders').insert(plan.map(s => {"], 'a reminder is set only for a person who actually moved', 'reminders are written for people who did not move'),
  M('B15', 'bulkstage', 'routes/recruiting/submissions.js', ["for (let i = 0; i < planIds.length; i += 100) {", "for (let i = 0; i < planIds.length; i += 1000) {"], 'written in two chunks', 'the write is no longer chunked'),
  M('B16', 'bulkstage', 'routes/recruiting/submissions.js', ["      if (!isBDM(req) && !isRecruiter(req)) return res.status(403).json({ error: 'Not permitted.' });\n      const ids = [...new Set(String(req.query.candidate_ids", "      const ids = [...new Set(String(req.query.candidate_ids"], 'research analyst may not read it', 'GET /submissions loses its role gate'),
  M('B17', 'bulkstage', 'routes/recruiting/submissions.js', ["        .filter(r => !(r.job && r.job.deleted_at))", "        .filter(r => true)"], 'not one on a deleted job order', 'GET /submissions lists submissions on deleted jobs'),
  M('B18', 'bulkstage', 'routes/recruiting/submissions.js', ["const early = subStages.requestRefusal({\n        isBDM: isBDM(req), isRecruiter: isRecruiter(req), to,\n        reason: b.rejection_reason, details: null, bulk: true,\n      });", "const early = null;"], 'Not Accepted with no reason refuses the whole request', 'the request-level refusal is removed'),
  M('B19', 'bulkstage', 'routes/recruiting/submissions.js', ["const note = [b.sub_stage ? ('[' + b.sub_stage + ']') : '', b.note || ''].filter(Boolean).join(' ') || null;", "const note = null;"], 'with the note and sub-stage', 'the history loses the note and sub-stage'),
  M('B20', 'bulkstage', 'routes/recruiting/submissions.js', [["        details: bulk ? null : b.submission_details,", "        details: b.submission_details,"], ["reason: b.rejection_reason, details: null, bulk: true,", "reason: b.rejection_reason, details: b.submission_details, bulk: true,"]], 'cannot get round it by sending details', 'a recruiter can group-submit to BDM by sending one set of details'),
  M('B21', 'bulkstage', 'routes/recruiting/submissions.js', ["reason: b.rejection_reason, details: null, bulk: true,", "reason: b.rejection_reason, details: b.submission_details, bulk: true,"], 'cannot get round it by sending details', 'the request-level details check trusts details a group move cannot carry'),
  M('B22', 'bulkstage', 'routes/recruiting/submissions.js', ["      const to = normalizeStage(b.stage);\n      if (!STAGES.includes(to)) return res.status(400).json({ error: `Invalid stage. Allowed: ${STAGES.join(', ')}` });\n      const asked", "      const to = b.stage;\n      if (!STAGES.includes(to)) return res.status(400).json({ error: `Invalid stage. Allowed: ${STAGES.join(', ')}` });\n      const asked"], 'legacy stage name is normalised', 'the group move stops accepting legacy stage names'),
  M('B23', 'bulkstage', 'routes/recruiting/submissions.js', ["    moved.forEach(s => emit(EVENTS.SUBMISSION_ADVANCED, {", "    [].forEach(s => emit(EVENTS.SUBMISSION_ADVANCED, {"], 'one SUBMISSION_ADVANCED event per moved person', 'a group move fires no events'),
  M('B24', 'bulkstage', 'routes/recruiting/submissions.js', ["const updates = { stage: to, stage_updated_at: now, sub_stage: b.sub_stage || null };", "const updates = { stage: to, sub_stage: b.sub_stage || null };"], 'stage_updated_at moved', 'time-in-stage stops resetting on a move'),
  M('B25', 'bulkstage', 'routes/recruiting/submissions.js', ["if (to === subStages.NOT_ACCEPTED) updates.rejection_reason = String(b.rejection_reason).trim();", ""], 'stores the reason on each', 'the rejection reason is not stored'),
  M('B26', 'bulkstage', 'routes/recruiting/submissions.js', ["return Object.assign({}, r, { stage: normalizeStage(r.stage), job });", "return Object.assign({}, r, { job });"], 'NORMALISED stage', 'GET /submissions returns raw legacy stage names'),
  M('B27', 'bulkstage', 'routes/recruiting/submissions.js', ["const { data: sub, error: subErr } = await db.forRequest(req).from('submissions')\n        .select(MOVE_SELECT).eq('id', req.params.id)", "const { data: sub, error: subErr } = await supabase.from('submissions')\n        .select(MOVE_SELECT).eq('id', req.params.id)"], 'unknown, a foreign and a deleted id all read 404', 'the single move reads outside the caller\'s company'),
  M('M18', 'membership', 'routes/recruiting/pipeline.js', ["if (!(await recruiterCanTouchJob(req, b.job_order_id))) return res.status(403).json({ error: 'Not assigned to this job order.' });", "", true], 'may not add to a job they are not assigned to', 'a recruiter may add to any job'),
  M('M19', 'membership', 'routes/recruiting/pipeline.js', ["if (!isBDM(req) && !isRecruiter(req)) return res.status(403).json({ error: 'Not permitted.' });", "", true], 'research analyst (neither BD nor recruiter) may not add', 'the role gate on adding is removed'),
  M('M20', 'membership', 'services/recruiting-core.js', ["const { data } = await db.forRequest(req).from('job_orders')\n      .select('id,org_id,job_title,job_code,status,bd_manager_id')", "const { data } = await supabase.from('job_orders')\n      .select('id,org_id,job_title,job_code,status,bd_manager_id')"], "another company cannot add ITS OWN candidate", 'loadJobOrderFor reads outside the caller\'s company'),
  M('M21', 'membership', 'services/recruiting-core.js', ["const { data } = await db.forRequest(req).from('candidates')\n      .select(MEMBER_CAND_COLS)", "const { data } = await supabase.from('candidates')\n      .select(MEMBER_CAND_COLS)"], "nor add another company's candidate", 'loadCandidateFor reads outside the caller\'s company'),
  M('M22', 'membership', 'routes/recruiting/analytics.js', ["let detail = (r.action === 'created' || r.action === 'tagged') ? 'Added to a job' :", "let detail = (r.action === 'created') ? 'Added a submission' : r.action === 'tagged' ? 'Tagged to a job' :"], 'never says "Tagged"', 'the team feed says "Added a submission" / "Tagged to a job" again'),
];

// baseline on the copy: both scenarios must be green before any mutation counts
restore();
const base = { membership: run('membership'), bulkstage: run('bulkstage') };
for (const k of Object.keys(base)) console.log(`baseline ${k} on the copy: ${base[k].summary}${base[k].fails.length ? '  FAILS: ' + base[k].fails.join(' | ') : ''}`);
if (Object.values(base).some(b => b.fails.length || b.crashed)) { console.log('BASELINE NOT GREEN — stopping'); process.exit(2); }

let vacuous = 0, caught = 0;
for (const m of MUTATIONS) {
  restore();
  const fp = path.join(COPY, m.file);
  let src = fs.readFileSync(fp, 'utf8');
  let ok = true;
  for (const [find, replace, all] of m.edits) {
    if (!src.includes(find)) { console.log(`[SETUP ] ${m.id} — cannot find the text to mutate in ${m.file}: ${JSON.stringify(find.slice(0, 70))}`); ok = false; break; }
    src = all ? src.split(find).join(replace) : src.replace(find, replace);
  }
  if (!ok) { vacuous++; continue; }
  fs.writeFileSync(fp, src);
  const r = run(m.scenario);
  const named = r.fails.filter(l => l.includes(m.expect));
  if (named.length) { caught++; console.log(`[CAUGHT] ${m.id} ${m.what}  ->  ${r.fails.length} failing, e.g. "${named[0].replace('[FAIL] ', '').slice(0, 90)}"`); }
  else { vacuous++; console.log(`[MISSED] ${m.id} ${m.what}  ->  ${r.crashed ? 'CRASHED' : r.fails.length + ' failing'} but none names "${m.expect}"${r.fails.length ? ' — got: ' + r.fails.slice(0, 2).join(' | ').slice(0, 200) : ''}`); }
}
restore();
console.log(`\n${caught}/${MUTATIONS.length} deliberate breaks caught; ${vacuous} missed`);
process.exit(vacuous ? 1 : 0);
