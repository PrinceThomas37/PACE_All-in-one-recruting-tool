#!/usr/bin/env bash
# Baseline run of the browser suites that guard the render engine (before any change).
cd /home/user/PACE_All-in-one-recruting-tool/.claude/worktrees/agent-ae2c02811285b1958
run() {
  echo "=== $1"
  timeout 600 node "test/$1.mjs" 2>&1 | tail -4
}
run mobile-layout-smoke
run theme-contrast-smoke
run ui-smoothness-smoke
run page-renders-smoke
run frontend-smoke
run nav-icons-smoke
run modal-mobile-smoke
run mailbox-page-smoke
run pending-preview-smoke
echo "=== DONE"
