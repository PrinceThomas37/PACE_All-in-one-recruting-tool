'use strict';
// For every column in the apply select list: is it ALSO selected/written by name in some other
// route that is known to work in production? (independent of the migrations)
const fs = require('fs'), path = require('path');
const ROOT = '/home/user/PACE_All-in-one-recruting-tool';
const want = ('id,org_id,job_code,job_title,city,state,country,remote,job_type,job_description,posting_description,client,end_client,client_manager,primary_skills,secondary_skills,exp_min,exp_max,pay_cur,pay_min,pay_max,status,apply_enabled,apply_token,apply_count,bd_manager_id,created_by').split(',');
function walk(d){let o=[];for(const e of fs.readdirSync(d,{withFileTypes:true})){if(['node_modules','.git','test','docs','migrations','public'].includes(e.name))continue;const p=path.join(d,e.name);if(e.isDirectory())o=o.concat(walk(p));else if(e.name.endsWith('.js'))o.push(p);}return o;}
const files = walk(ROOT).filter(f => !f.endsWith('routes/apply.js'));
// collect quoted select strings that follow from('job_orders')
const seen = {};
for (const f of files) {
  const src = fs.readFileSync(f,'utf8');
  const re = /from\(\s*['"]job_orders['"]\s*\)[\s\S]{0,400}?\.select\(\s*(['"`])([^'"`]*)\1/g;
  let m;
  while ((m = re.exec(src))) {
    m[2].split(',').map(s=>s.trim()).forEach(c => { if (c) (seen[c] = seen[c] || new Set()).add(path.relative(ROOT,f)); });
  }
  // writes: .update({ a:..., b:... }) / insert
}
for (const c of want) console.log((seen[c] ? 'also selected by ' + [...seen[c]].slice(0,3).join(', ') : 'NOT selected elsewhere by name').padEnd(70), c);
